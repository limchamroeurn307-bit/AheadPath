import unittest
import tempfile
from pathlib import Path
from datetime import date, timedelta

from app import TOPICS, app, build_ai_curriculum_roadmap, build_roadmap, init_db

SAMPLE_SYLLABUS = """INTRODUCTION TO NETWORK SECURITY — SAMPLE COURSE OUTLINE
Course description: This course introduces students to network security concepts, protocols, common threats, and basic defensive controls.
Learning outcomes:
- Explain IP addressing, TCP and UDP, common ports, and DNS.
- Describe common security threats, vulnerabilities, and defensive controls.
- Inspect basic network traffic using a packet analysis tool.
- Explain the purpose of firewalls, access control, and secure communication.
Indicative weekly topics:
Week 1: Computer networks, IP addresses, subnetting, and the TCP/IP model.
Week 2: Transport layer, TCP handshake, UDP datagrams, and port numbers.
Week 3: DNS, HTTP, HTTPS, and TLS.
Week 4: Threats, vulnerabilities, confidentiality, integrity, and availability.
Week 5: Firewall rules and network access control.
Week 6: Network monitoring and packet analysis with Wireshark.
"""


class PlannerTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        app.config.update(TESTING=True, DATABASE=str(Path(self.tempdir.name) / "test.db"))
        init_db()
        self.client = app.test_client()

    def tearDown(self):
        self.tempdir.cleanup()

    def create_account(self, username="teststudent"):
        response = self.client.post("/api/auth/register", json={"username": username, "password": "safe-test-password"})
        self.assertEqual(response.status_code, 201, response.get_data(as_text=True))
        return response.get_json()

    def make_plan(self, hours=4, days=28):
        return build_roadmap({
            "course_title": "Introduction to Network Security",
            "goal": "network_security",
            "syllabus_text": SAMPLE_SYLLABUS,
            "start_date": (date.today() + timedelta(days=days)).isoformat(),
            "hours_per_week": hours,
            "skills": {"computer": "new", "linux": "new", "networking": "new", "programming": "new", "web": "new", "security": "new"},
            "use_ai": False,
        })


    def test_ai_curriculum_keeps_every_module_and_its_full_lecture_pack(self):
        curriculum = {
            "summary": "A complete syllabus-based course.",
            "course_overview": "The units build from concepts to applications.",
            "learning_outcomes": ["Explain the subject concepts", "Apply the concepts to a case"],
            "official_prerequisites": [],
            "uncertainty_notes": [],
            "coverage_map": [
                {"syllabus_item": "Unit 1 topic A", "module_title": "Unit 1: Topic A"},
                {"syllabus_item": "Unit 2 topic B", "module_title": "Unit 2: Topic B"},
            ],
            "modules": [
                {
                    "id": "syllabus_module_01", "title": "Unit 1: Topic A", "category": "Core concepts",
                    "description": "A specific introduction to topic A.", "objectives": ["Explain A"],
                    "source_topics": ["Unit 1 topic A"], "planned_hours": 1.0,
                    "unit_label": "Unit 1", "practice": "Review the concept.",
                    "resource_title": "Lecture notes", "resource_url": "#",
                    "why": "Mapped from the syllabus.", "level": "University lecture",
                    "custom_lesson": {
                        "title": "Topic A lecture", "intro": "A long lecture introduction from the syllabus.",
                        "sections": [{"heading": "Concept A", "body": "An extended detailed explanation of concept A."}],
                        "takeaways": ["Explain A"], "quizQuestions": []
                    }
                },
                {
                    "id": "syllabus_module_02", "title": "Unit 2: Topic B", "category": "Applications",
                    "description": "A specific introduction to topic B.", "objectives": ["Apply B"],
                    "source_topics": ["Unit 2 topic B"], "planned_hours": 1.0,
                    "unit_label": "Unit 2", "practice": "Review the concept.",
                    "resource_title": "Lecture notes", "resource_url": "#",
                    "why": "Mapped from the syllabus.", "level": "University lecture",
                    "custom_lesson": {
                        "title": "Topic B lecture", "intro": "A long lecture introduction from the syllabus.",
                        "sections": [{"heading": "Concept B", "body": "An extended detailed explanation of concept B."}],
                        "takeaways": ["Apply B"], "quizQuestions": []
                    }
                },
            ],
        }
        plan = build_ai_curriculum_roadmap({
            "course_title": "Course from syllabus", "start_date": (date.today() + timedelta(days=7)).isoformat(),
            "hours_per_week": 1,
        }, SAMPLE_SYLLABUS, curriculum)
        tasks = [task for week in plan["weeks"] for task in week["tasks"]]
        self.assertEqual(len(tasks), 2)
        self.assertEqual({task["module_id"] for task in tasks}, {"syllabus_module_01", "syllabus_module_02"})
        self.assertTrue(all(task["custom_lesson"]["title"] for task in tasks))
        self.assertEqual(len(plan["syllabus_coverage"]), 2)
        self.assertEqual(plan["planned_topic_count"], 2)

    def test_roadmap_is_generated(self):
        plan = self.make_plan()
        self.assertEqual(plan["course_title"], "Introduction to Network Security")
        self.assertGreater(plan["planned_topic_count"], 0)
        self.assertGreater(sum(len(week["tasks"]) for week in plan["weeks"]), 0)

    def test_schedule_respects_weekly_budget(self):
        plan = self.make_plan(hours=3, days=21)
        self.assertLessEqual(plan["planned_hours"], plan["total_budget_hours"] + 1e-9)
        for week in plan["weeks"]:
            self.assertLessEqual(week["hours"], plan["hours_per_week"] + 1e-9)

    def test_short_timeline_still_returns_a_plan(self):
        plan = self.make_plan(hours=1, days=3)
        self.assertEqual(plan["weeks_count"], 1)
        self.assertGreater(len(plan["weeks"][0]["tasks"]), 0)

    def test_low_text_is_rejected(self):
        with self.assertRaises(ValueError):
            build_roadmap({"syllabus_text": "too short"})

    def test_task_ids_are_unique_and_hours_match_week_totals(self):
        plan = self.make_plan(hours=3, days=21)
        tasks = [task for week in plan["weeks"] for task in week["tasks"]]
        task_ids = [task["task_id"] for task in tasks]
        self.assertEqual(len(task_ids), len(set(task_ids)))
        self.assertAlmostEqual(plan["planned_hours"], sum(week["hours"] for week in plan["weeks"]))

    def test_prerequisites_appear_before_topics_that_depend_on_them(self):
        plan = self.make_plan(hours=8, days=56)
        tasks = [task for week in plan["weeks"] for task in week["tasks"]]
        first_position = {}
        for position, task in enumerate(tasks):
            first_position.setdefault(task["module_id"], position)
        for topic_id, topic in TOPICS.items():
            if topic_id not in first_position:
                continue
            for prerequisite in topic["prerequisites"]:
                if prerequisite in first_position:
                    self.assertLess(first_position[prerequisite], first_position[topic_id],
                                    f"{prerequisite} should come before {topic_id}")

    def test_health_endpoint_responds(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["ok"])

    def test_generate_endpoint_returns_a_course(self):
        self.create_account()
        response = self.client.post("/api/generate", json={
            "course_title": "Network Security Starter",
            "goal": "network_security",
            "syllabus_text": SAMPLE_SYLLABUS,
            "start_date": (date.today() + timedelta(days=21)).isoformat(),
            "hours_per_week": 4,
            "skills": {"computer": "new", "linux": "new", "networking": "new", "programming": "new", "web": "new", "security": "new"},
        })
        self.assertEqual(response.status_code, 201, response.get_data(as_text=True))
        data = response.get_json()
        self.assertGreater(sum(len(week["tasks"]) for week in data["plan"]["weeks"]), 0)
        self.assertIn("course_title", data["plan"])

    def test_generate_endpoint_rejects_empty_syllabus(self):
        self.create_account()
        response = self.client.post("/api/generate", json={"syllabus_text": "too short"})
        self.assertEqual(response.status_code, 400)
        self.assertIn("error", response.get_json())

    def test_multiple_courses_are_saved_in_the_account_library(self):
        self.create_account()
        for title in ("Networking 101", "Linux Foundations"):
            response = self.client.post("/api/generate", json={
                "course_title": title,
                "goal": "network_security",
                "syllabus_text": SAMPLE_SYLLABUS,
                "start_date": (date.today() + timedelta(days=21)).isoformat(),
                "hours_per_week": 4,
                "skills": {"computer": "new", "linux": "new", "networking": "new", "programming": "new", "web": "new", "security": "new"},
            })
            self.assertEqual(response.status_code, 201, response.get_data(as_text=True))
        library = self.client.get("/api/courses")
        self.assertEqual(library.status_code, 200)
        self.assertEqual({course["title"] for course in library.get_json()["courses"]}, {"Networking 101", "Linux Foundations"})

    def test_courses_are_private_to_their_account(self):
        self.create_account("studentone")
        response = self.client.post("/api/generate", json={
            "course_title": "Private Course", "goal": "network_security", "syllabus_text": SAMPLE_SYLLABUS,
            "start_date": (date.today() + timedelta(days=21)).isoformat(), "hours_per_week": 4,
            "skills": {"networking": "new", "security": "new"},
        })
        self.assertEqual(response.status_code, 201)
        course_id = response.get_json()["course_id"]
        self.client.post("/api/auth/logout")
        self.create_account("studenttwo")
        self.assertEqual(self.client.get(f"/api/courses/{course_id}").status_code, 404)


if __name__ == "__main__":
    unittest.main()
