# AheadPath

AheadPath turns a university syllabus into a saved course with a week-by-week schedule, lecture slides, full written notes, lesson quizzes, and a course-level final test.

## Cloud AI with the Gemini API

AheadPath uses Google's Gemini Developer API to read the syllabus and generate university-style teaching materials. You do **not** need to download a language model or install Ollama. The default model is `gemini-3.8-flash`.

Google currently offers free input and output token usage for eligible Gemini API models/projects, including the default Flash model. The free tier has rate limits and availability restrictions; it is not unlimited. Check the current [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing), [models](https://ai.google.dev/gemini-api/docs/models), and [rate limits](https://ai.google.dev/gemini-api/docs/rate-limits) before relying on it. Free-tier content may be used by Google to improve its products, so do not upload confidential, personal, or restricted course material unless you are comfortable with Google's current API terms.

The API key stays on the AheadPath server in the `.env` file. It is never placed in frontend JavaScript or sent to students' browsers.

The AI generates:

- A course outline organized around the syllabus weeks, units, topics, subtopics, and learning outcomes.
- Separate detailed university-style lectures for every generated module.
- Explanations, key terms, worked examples, illustrative case studies, misconceptions, takeaways, and syllabus-specific assessment questions.
- A syllabus coverage map linking original course topics to lessons.
- A diagnostic check and course final assessment based on the generated content.

Generated courses are saved in the AheadPath SQLite database under the student's account. Review the coverage map and generated material against the official syllabus; AI can make mistakes and cannot guarantee a perfect match.

## 1. Get a Gemini API key

1. Open [Google AI Studio API Keys](https://aistudio.google.com/app/apikey).
2. Sign in with your Google account. AI Studio will let you create an API key for a project.
3. Create a key and copy it. Keep it private; do not paste it into the website, source code, or a message to anyone.
4. Check the [available regions](https://ai.google.dev/gemini-api/docs/available-regions) and your project's [usage dashboard](https://aistudio.google.com/).

## 2. Install and run AheadPath on Windows

1. Extract the ZIP file and open the `AheadPath` folder.
2. Open PowerShell in that folder.
3. Create a Python environment and install the project packages:

   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   Copy-Item .env.example .env
   ```

4. Open the `.env` file with Notepad or VS Code. Add your key after `GEMINI_API_KEY=`:

   ```dotenv
   AI_PROVIDER=gemini
   GEMINI_API_KEY=PASTE_YOUR_GOOGLE_AI_STUDIO_KEY_HERE
   GEMINI_MODEL=gemini-3.8-flash
   HOST=0.0.0.0
   PORT=5000
   COOKIE_SECURE=false
   ```

   Do not add quotation marks unless your key actually contains them. Do not share the `.env` file. It is excluded from Git by `.gitignore`.

5. Start AheadPath:

   ```powershell
   python app.py
   ```

6. Open <http://127.0.0.1:5000>, register or sign in, paste/upload the syllabus, and generate the course. The page checks that the Gemini SDK and API key are configured. The key, model access, and free-tier quota are verified when the first generation request is sent.

If PowerShell blocks virtual-environment activation, run this once in the current PowerShell window and activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

## 3. Run on macOS or Linux

From the project folder:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set `GEMINI_API_KEY`, then start AheadPath:

```bash
python app.py
```

Open <http://127.0.0.1:5000>.

## 4. Let other devices use AheadPath on the same Wi-Fi

The computer running AheadPath is the host. It must stay switched on, and both it and the other devices must be connected to the same Wi-Fi/network.

1. Start AheadPath with `python app.py`.
2. On Windows, open Command Prompt and run `ipconfig`.
3. Find the host computer's active Wi-Fi IPv4 address, for example `192.168.1.25`.
4. On another phone, tablet, or computer connected to the same Wi-Fi, open `http://192.168.1.25:5000` (replace the example IP with the host's actual address).
5. If it cannot connect, allow Python or TCP port `5000` through the host computer's private-network firewall.

Other devices do not need their own Gemini API keys. Their browsers connect to the AheadPath server, and the server uses its configured key to call Gemini. Keep port `5000` limited to trusted networks unless you deploy behind HTTPS with appropriate security controls. Never expose the API key or put it in client-side code.

## 5. Course-generation behavior

When full generation is enabled, AheadPath sends the syllabus text to Gemini and requests a complete outline, then a separate lecture for each module. Lecture materials are checked for required structure and depth. Incomplete packs are rejected rather than silently saved as finished university lessons. Requests are generated sequentially to reduce pressure on the free-tier request limits.

A large syllabus with many modules can use many requests: one for the outline and at least one for each module, with retries when a response is incomplete. Keep all weeks, topics, and learning outcomes if shortening the syllabus; remove repeated administrative text first. The app does not silently convert a failed full generation into a saved course labelled as complete.

## Troubleshooting

- **Gemini API key not configured:** Open `.env`, set `GEMINI_API_KEY=...`, save the file, and restart AheadPath.
- **Gemini SDK is missing:** Activate the virtual environment and run `pip install -r requirements.txt` again.
- **Invalid API key:** Create a new key in [Google AI Studio](https://aistudio.google.com/app/apikey), update `.env`, and restart the app.
- **429 / quota / rate limit:** Check AI Studio > Usage. Wait for the quota window to reset, reduce the number of modules, or make the syllabus shorter without removing course topics. Free-tier quotas are model- and project-dependent and can change.
- **Model not found or unavailable:** Confirm `GEMINI_MODEL` exactly matches a model available to your project. The default is `gemini-3.8-flash`.
- **Permission or region error:** Confirm the Gemini API and AI Studio are available for your region/account, and that the key belongs to the intended project.
- **Lecture completeness check fails:** Retry with fewer clearly-labelled modules or use a model with better output capacity if available to your project. Do not remove syllabus learning outcomes or substantive topics.
- **Port 5000 is already in use:** Change `PORT=5001` in `.env`, restart AheadPath, and use port `5001` in the browser URL.
- **Existing courses are missing:** Course data is stored in `instance/aheadpath.db`. Copy this file from the old project folder into the new project's `instance` folder while AheadPath is stopped. Do not overwrite it with a blank database.

## Project structure

```text
AheadPath/
├── app.py
├── requirements.txt
├── .env.example
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   ├── styles.css
│   ├── readability.css
│   └── course.css
└── tests/
    ├── test_planner.py
    └── test_frontend_contract.py
```

## Tests

After installing the project dependencies, run:

```bash
python -m unittest discover -s tests -v
```

The frontend contract tests do not require Flask. Backend tests require the project packages. Automated tests do not make live Gemini API requests or consume API quota.
