"""Dependency-free checks for the AheadPath page and course-player contract."""
from html.parser import HTMLParser
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "templates" / "index.html"
JS_PATH = ROOT / "static" / "app.js"
APP_PATH = ROOT / "app.py"


class IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])


class FrontendContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = HTML_PATH.read_text(encoding="utf-8")
        cls.js = JS_PATH.read_text(encoding="utf-8")
        cls.backend = APP_PATH.read_text(encoding="utf-8")
        parser = IdParser()
        parser.feed(cls.html)
        cls.html_ids = parser.ids

    def test_template_ids_are_unique(self):
        duplicates = sorted({value for value in self.html_ids if self.html_ids.count(value) > 1})
        self.assertEqual(duplicates, [])

    def test_static_javascript_selectors_exist_in_template(self):
        selectors = set(re.findall(r"\$\('#([A-Za-z][\w-]*)'", self.js))
        missing = sorted(selectors - set(self.html_ids))
        self.assertEqual(missing, [])

    def test_lesson_page_is_lecture_first_and_hides_old_step_sequence(self):
        self.assertIn('class="lesson-time-plan hidden"', self.html)
        for element_id in ["previewActivity", "coreIdeasActivity", "workedExampleActivity", "handsOnActivity", "recallActivity"]:
            self.assertRegex(self.html, rf'<section id="{element_id}"[^>]*class="[^"]*hidden')
        self.assertIn('id="lessonSyllabusAlignment"', self.html)
        self.assertIn('id="lessonKeyTerms"', self.html)
        self.assertIn('id="lessonWorkedExampleDetails"', self.html)
        self.assertIn('id="lessonCaseStudy"', self.html)
        self.assertIn('id="lessonMisconceptions"', self.html)
        self.assertIn("function renderLectureParagraphs(value)", self.js)

    def test_slide_deck_is_primary_and_full_text_can_be_saved(self):
        required_ids = {
            "lessonLecture", "lessonLectureBody", "lessonIntro", "lessonSections",
            "audioStatus", "saveLectureNotesButton",
        }
        self.assertTrue(required_ids.issubset(set(self.html_ids)))
        self.assertIn('<details id="lessonLecture"', self.html)
        self.assertLess(self.html.index('id="lessonSlideDeck"'), self.html.index('class="audio-controls lesson-audio-controls"'))
        self.assertLess(self.html.index('id="lessonSlideDeck"'), self.html.index('id="lessonTimePlan"'))
        self.assertIn("function saveLectureNotes()", self.js)
        self.assertIn("aheadpath-${slug}-notes.txt", self.js)
        self.assertIn("merged.sections = Array.isArray(merged.sections) && merged.sections.length", self.js)
        self.assertIn("chunk.element.classList.add('is-speaking')", self.js)


    def test_audio_can_pause_resume_and_select_a_narrator(self):
        required_ids = {"playAudioBtn", "pauseAudioBtn", "restartAudioBtn", "voiceSelect", "audioStatus"}
        self.assertTrue(required_ids.issubset(set(self.html_ids)))
        self.assertIn("function pauseLessonAudio()", self.js)
        self.assertIn("window.speechSynthesis.pause()", self.js)
        self.assertIn("window.speechSynthesis.resume()", self.js)
        self.assertIn("function restartLessonAudio()", self.js)
        self.assertIn("function chooseNarratorVoice()", self.js)
        self.assertIn("utterance.pitch = 1.08", self.js)

    def test_lesson_knowledge_check_has_four_questions_and_feedback(self):
        self.assertIn("function getLessonCheckQuestions(task, lesson)", self.js)
        self.assertIn("LESSON_CHECK_BANK", self.js)
        self.assertIn("questions.length >= 4", self.js)
        self.assertIn("Correct answer:", self.js)
        self.assertIn("const passMark = Math.ceil(activeLessonCheckQuestions.length * 0.75)", self.js)
        self.assertIn("Check all answers", self.html)

    def test_course_player_and_final_test_controls_exist(self):
        required_ids = {
            "learningPlayer", "lessonSections", "lessonPractice", "lessonQuizForm",
            "checkLessonAnswerButton", "nextLessonButton", "courseOutlineList",
            "launchFinalAssessmentButton", "finalAssessmentForm",
            "submitFinalAssessmentButton", "retakeFinalAssessmentButton",
        }
        self.assertTrue(required_ids.issubset(set(self.html_ids)))
        self.assertIn("Pass the knowledge check to continue", self.js)
        self.assertIn("function allStudyActivitiesDone()", self.js)
        self.assertIn("Complete every lesson to unlock the test.", self.html)

    def test_passing_the_knowledge_check_unlocks_next_lesson(self):
        self.assertIn("function allStudyActivitiesDone()", self.js)
        self.assertIn("return Boolean(lessonAnswerCorrect || activeStudyState?.completed?.knowledgeCheck)", self.js)
        self.assertIn("if (!activeTaskId || !allStudyActivitiesDone()) return false", self.js)
        self.assertIn("Pass the knowledge check before continuing.", self.js)
        self.assertNotIn("Complete all activities to unlock the next lesson.", self.html)
        self.assertNotIn("STEP 1 ·", self.html)
        self.assertNotIn("STEP 2 ·", self.html)

    def test_ai_curriculum_is_built_from_the_complete_syllabus(self):
        self.assertIn("def try_ai_course_curriculum(", self.backend)
        self.assertIn("build_ai_curriculum_roadmap", self.backend)
        self.assertIn("FULL SYLLABUS SOURCE", self.backend)
        self.assertIn("custom_lesson", self.backend)
        self.assertIn("syllabus_coverage", self.backend)
        self.assertIn("diagnostic_questions", self.backend)
        self.assertIn("source_topics", self.js)
        self.assertIn("common_misconceptions", self.js)

    def test_gemini_generation_retries_and_reports_api_errors(self):
        self.assertIn("class GeminiClient:", self.backend)
        self.assertIn("self.client.models.generate_content", self.backend)
        self.assertIn("def _friendly_gemini_error(", self.backend)
        self.assertIn("GEMINI_API_KEY", self.backend)
        self.assertIn("free-tier request quota or rate limit", self.backend)
        self.assertIn("def _request_json_from_ai(", self.backend)
        self.assertIn("max_output_tokens=14000", self.backend)
        self.assertIn("Your previous response was incomplete or invalid", self.backend)
        self.assertIn("QUALITY-CONTROL RETRY", self.backend)
        self.assertIn("generated_modules = [generate_module(index, module) for index, module in indexed_modules]", self.backend)
        self.assertIn("No course was saved.", self.backend)
        self.assertNotIn("OPENAI_API_KEY", self.backend)
        self.assertNotIn("OLLAMA_BASE_URL", self.backend)

    def test_gemini_api_is_the_default_and_ui_reports_readiness(self):
        self.assertIn('AI_PROVIDER = os.getenv("AI_PROVIDER", "gemini")', self.backend)
        self.assertIn('GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")', self.backend)
        self.assertIn('"ai_message": status["message"]', self.backend)
        self.assertIn("Gemini API is configured", self.js)
        self.assertIn("Gemini API ready", self.js)
        self.assertIn("Gemini API", self.html)
        self.assertNotIn("Ollama", self.html)


    def test_syllabus_generated_slides_use_generated_examples_and_cases(self):
        self.assertIn("const isSyllabusLecture = Boolean(task.custom_lesson)", self.js)
        self.assertIn("const worked = lesson.worked_example || {}", self.js)
        self.assertIn("const caseStudy = lesson.case_study || {}", self.js)
        self.assertIn("caseStudy.analysis", self.js)
        self.assertIn("const generatedExample = lesson.worked_example || {}", self.js)
        self.assertIn("const generatedCase = lesson.case_study || {}", self.js)

    def test_syllabus_diagnostic_and_final_test_are_course_specific(self):
        self.assertIn("plan?.diagnostic_questions", self.js)
        self.assertIn("function selectFinalAssessmentQuestions()", self.js)
        self.assertIn("activeFinalAssessmentQuestions = selectFinalAssessmentQuestions()", self.js)
        self.assertIn("Take one question from each module first", self.js)

    def test_every_curated_topic_has_a_builtin_lesson(self):
        topic_ids = set(re.findall(r'^    "([a-z_]+)": \{\n        "id": "\1"', self.backend, re.M))
        lessons_block = self.js.split("const LESSONS = {", 1)[1].split("const FINAL_ASSESSMENT = [", 1)[0]
        lesson_ids = set(re.findall(r"^    ([a-z_]+): \{", lessons_block, re.M))
        self.assertTrue(topic_ids.issubset(lesson_ids), f"Missing built-in lessons: {sorted(topic_ids - lesson_ids)}")

    def test_final_assessment_has_eight_unique_questions_and_pass_mark(self):
        block = self.js.split("const FINAL_ASSESSMENT = [", 1)[1].split("\n  ];", 1)[0]
        question_ids = re.findall(r"\bid: '(f\d+)'", block)
        self.assertEqual(len(question_ids), 8)
        self.assertEqual(len(set(question_ids)), 8)
        self.assertEqual(len(re.findall(r"\banswer: \d", block)), 8)
        self.assertIn("passed: score >= Math.ceil(activeFinalAssessmentQuestions.length * 0.75)", self.js)
        self.assertIn("if (!tasks.length || !tasks.every(task => completedTasks[task.task_id]))", self.js)

    def test_lesson_generates_navigable_lecture_slides_with_topic_details(self):
        required_ids = {
            "lessonSlideDeck", "lectureSlideCanvas", "slideTitle", "slideLead", "slidePoints",
            "slideCallout", "slideCounter", "slideProgressFill", "previousSlideButton",
            "nextSlideButton", "slideDots", "downloadSlidesButton",
        }
        self.assertTrue(required_ids.issubset(set(self.html_ids)))
        self.assertIn("function buildLectureSlides(task, lesson, workshop)", self.js)
        self.assertIn("const LESSON_SLIDE_DETAILS = {", self.js)
        self.assertIn("function renderLectureSlide(index", self.js)
        self.assertIn("function downloadLectureSlides()", self.js)
        self.assertIn("onStart: () => renderLectureSlide(index, { fromSpeech: true })", self.js)
        self.assertIn("activeSpeechChunkIndex = wasFinished ? 0 : activeSlideIndex", self.js)
        self.assertIn("deck.addEventListener", self.js) if "deck.addEventListener" in self.js else self.assertIn("data-slide-go", self.js)
        self.assertIn('link.download = `aheadpath-${slug}-slides.html`', self.js)

    def test_preview_page_matches_the_live_slide_player_contract(self):
        preview_path = ROOT / "preview_test.html"
        preview = preview_path.read_text(encoding="utf-8")
        parser = IdParser()
        parser.feed(preview)
        duplicate_ids = sorted({value for value in parser.ids if parser.ids.count(value) > 1})
        self.assertEqual(duplicate_ids, [])
        self.assertIn('id="lessonSlideDeck"', preview)
        self.assertIn('id="downloadSlidesButton"', preview)
        self.assertNotIn("Where are you starting from?", preview)
        self.assertNotIn("{{ url_for", preview)

    def test_starting_point_form_is_removed_from_course_setup(self):
        self.assertNotIn("Where are you starting from?", self.html)
        self.assertIn('id="skillCompatibilityFields"', self.html)
        self.assertIn("$('#readinessSection').classList.add('hidden')", self.js)

    def test_starting_skills_are_syllabus_matched(self):
        self.assertIn('function updateRelevantSkillFields()', self.js)
        self.assertIn('data-skill-field="security"', self.html)
        self.assertIn("DIAGNOSTIC_QUESTION_BANK.filter(question => question.topics.some(id => detectedIds.includes(id)))", self.js)
        self.assertIn('skillsHelp', self.html)

    def test_gemini_ai_hosting_supports_shared_lan_url(self):
        root = Path(__file__).resolve().parents[1]
        backend = (root / 'app.py').read_text()
        readme = (root / 'README.md').read_text()
        self.assertIn('host=os.getenv("HOST", "0.0.0.0")', backend)
        self.assertIn('same Wi-Fi', readme)
        self.assertIn('Other devices do not need their own Gemini API keys.', readme)
        self.assertIn('Gemini API', readme)
        self.assertFalse((root / 'render.yaml').exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
