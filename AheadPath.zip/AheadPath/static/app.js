(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const SAMPLE_SYLLABUS = `INTRODUCTION TO NETWORK SECURITY — SAMPLE COURSE OUTLINE

Course description:
This course introduces students to network security concepts, protocols, common threats, and basic defensive controls. Students will explore how devices communicate and how organizations monitor and protect network traffic.

Learning outcomes:
- Explain IP addressing, TCP and UDP, common ports, and DNS.
- Describe common security threats, vulnerabilities, and defensive controls.
- Inspect basic network traffic using a packet analysis tool.
- Explain the purpose of firewalls, access control, and secure communication.

Indicative weekly topics:
Week 1: Computer networks, IP addresses, subnetting, and the TCP/IP model.
Week 2: Transport layer, TCP handshake, UDP datagrams, and port numbers.
Week 3: DNS, HTTP, HTTPS, and TLS.
Week 4: Threats, vulnerabilities, confidentiality, integrity, and availability.
Week 5: Firewall rules and network access control.
Week 6: Network monitoring and packet analysis with Wireshark.
Week 7: Basic incident investigation and security reporting.

Prerequisites:
Basic computer literacy is recommended. Previous professional cybersecurity experience is not required.

Assessments:
Short quizzes, a supervised packet-analysis lab, and a final practical exercise.`;

  const DIAGNOSTIC_QUESTION_BANK = [
    { id: 'q-computer', topics: ['computer_basics'], skill: 'computer', question: 'What does an operating system mainly do?', options: ['Manages hardware and running applications', 'Only stores passwords', 'Only connects to websites', 'Encrypts every file automatically'], answer: 0, explanation: 'An operating system manages hardware, applications, files, users, and system resources.' },
    { id: 'q-linux', topics: ['linux'], skill: 'linux', question: 'Which Linux command lists files in the current directory?', options: ['pwd', 'mkdir', 'ls', 'whoami'], answer: 2, explanation: 'ls lists directory contents. pwd prints the current directory, mkdir creates a directory, and whoami shows the current user.' },
    { id: 'q-networking', topics: ['networking'], skill: 'networking', question: 'What does an IP address help identify?', options: ['A network interface or destination', 'The user’s password', 'Whether data is encrypted', 'The exact contents of a file'], answer: 0, explanation: 'IP addresses identify network interfaces and help deliver packets to the right destination.' },
    { id: 'q-tcpudp', topics: ['tcp_udp'], skill: 'networking', question: 'Which protocol provides a reliable, ordered byte stream?', options: ['UDP', 'TCP', 'DNS', 'ARP'], answer: 1, explanation: 'TCP provides reliable, ordered delivery. UDP sends datagrams without built-in delivery or ordering guarantees.' },
    { id: 'q-dnshttp', topics: ['dns_http'], skill: 'web', question: 'What does DNS primarily help a computer do?', options: ['Encrypt all network traffic', 'Find records such as the IP address for a domain', 'Block suspicious connections', 'Assign file permissions'], answer: 1, explanation: 'DNS resolves domain names to records, commonly IP addresses. It is not itself a firewall or general encryption system.' },
    { id: 'q-programming', topics: ['programming'], skill: 'programming', question: 'What does an if statement usually do?', options: ['Runs code when a condition is met', 'Repeats code forever', 'Creates a network connection automatically', 'Saves data permanently'], answer: 0, explanation: 'An if statement conditionally runs a block of code based on a condition.' },
    { id: 'q-security', topics: ['security_fundamentals'], skill: 'security', question: 'Which security goal protects information from unauthorized disclosure?', options: ['Availability', 'Confidentiality', 'Routing', 'Compression'], answer: 1, explanation: 'Confidentiality protects information from unauthorized disclosure. Integrity concerns improper changes; availability concerns access when needed.' },
    { id: 'q-firewall', topics: ['firewalls'], skill: 'security', question: 'What is a firewall mainly used for?', options: ['Filtering network traffic according to rules', 'Making all software bug-free', 'Replacing user authentication', 'Automatically encrypting every file'], answer: 0, explanation: 'Firewalls allow or block traffic based on configured rules. They are one layer of defense, not a replacement for other controls.' },
    { id: 'q-packets', topics: ['packet_analysis'], skill: 'networking', question: 'What can a packet capture help an analyst inspect?', options: ['Network traffic metadata and protocols', 'A user’s thoughts', 'Every encrypted message in readable form', 'Only files stored on disk'], answer: 0, explanation: 'Packet captures can reveal addresses, ports, protocols, timing, and any unencrypted payload that is available to the capture.' },
    { id: 'q-crypto', topics: ['cryptography'], skill: 'security', question: 'What is the main purpose of encryption?', options: ['Make data unreadable to parties without the needed key', 'Guarantee software has no bugs', 'Make networks faster in every case', 'Replace backups'], answer: 0, explanation: 'Encryption protects confidentiality by making data unreadable without the appropriate key, when used correctly.' },
    { id: 'q-websec', topics: ['web_security'], skill: 'web', question: 'Where should beginners practice web security testing?', options: ['Any public website', 'An account they do not own', 'An authorized training lab', 'A random campus system'], answer: 2, explanation: 'Use intentionally vulnerable labs or systems where you have explicit permission to test.' },
    { id: 'q-logs', topics: ['logs_siem', 'incident_response'], skill: 'security', question: 'An alert reports an unusual login. What should an analyst do first?', options: ['Delete the logs', 'Treat the alert as proven compromise', 'Review related events and context', 'Ignore it immediately'], answer: 2, explanation: 'An alert is a starting point. Review relevant logs and context before deciding whether an incident occurred.' },
    { id: 'q-ctf', topics: ['ctf_basics'], skill: 'security', question: 'What is the safest place to practice a CTF challenge?', options: ['A random public server', 'The challenge environment provided or authorized by the organizer', 'A stranger’s account', 'Any network reachable from campus'], answer: 1, explanation: 'Stay inside the challenge environment and the scope explicitly authorized by the organizer.' }
  ];

  const FALLBACK_DIAGNOSTIC_QUESTIONS = DIAGNOSTIC_QUESTION_BANK.filter(q => ['q-networking', 'q-linux', 'q-programming', 'q-dnshttp'].includes(q.id));
  let activeDiagnosticQuiz = [...FALLBACK_DIAGNOSTIC_QUESTIONS];

  // Short, built-in lessons make the roadmap usable as a course, not just a list of links.
  // External resources are optional extensions; students can learn inside AheadPath first.
  const LESSONS = {
    computer_basics: {
      title: 'Computer and operating-system basics',
      intro: 'An operating system manages the computer’s hardware and gives applications a place to run. Security work becomes easier when you understand files, processes, users, and permissions.',
      sections: [
        { heading: 'Files and directories', body: 'Files store information. Directories organize files into a structure so you can find and manage them.' },
        { heading: 'Processes and users', body: 'A process is a running program. The operating system uses user accounts and permissions to control what processes and people can do.' },
        { heading: 'Why it matters for security', body: 'Unnecessary permissions can let an account or program access more than it needs. Start by asking which user owns a resource and who is allowed to read, change, or run it.' }
      ],
      takeaways: ['The operating system manages hardware and running programs.', 'Permissions control access to files and resources.', 'Use only the access needed for a task.'],
      quiz: { question: 'What do file permissions mainly control?', options: ['The color of a file icon', 'Who can read, change, or execute a file', 'The file’s internet speed', 'Which website owns the computer'], answer: 1, explanation: 'File permissions determine which users can perform actions such as reading, writing, or executing a file.' }
    },
    linux: {
      title: 'Linux command-line fundamentals',
      intro: 'The command line lets you operate a computer by typing commands. Cybersecurity tools often run in a terminal, so learn to read commands carefully before running them.',
      sections: [
        { heading: 'Know where you are', body: 'Use pwd to print the current directory and ls to list its contents. Use cd to move to another directory.' },
        { heading: 'Read before you run', body: 'Commands such as cat display a text file, mkdir creates a directory, and grep searches text. Options and paths change what a command does.' },
        { heading: 'Use permissions carefully', body: 'Commands that run with elevated privileges can change important parts of a system. Understand a command first, and practice in a folder or virtual machine you control.' }
      ],
      takeaways: ['pwd shows the current directory.', 'ls lists directory contents.', 'Never run a command with elevated privileges without understanding its effect.'],
      quiz: { question: 'Which command lists files in the current directory on a typical Linux system?', options: ['pwd', 'mkdir', 'ls', 'whoami'], answer: 2, explanation: 'ls lists directory contents. pwd prints the current directory, mkdir creates a directory, and whoami prints the current user.' }
    },
    networking: {
      title: 'Networking fundamentals',
      intro: 'A network lets devices exchange data. To investigate security, you need a basic picture of how a device identifies a destination and how data travels between hosts.',
      sections: [
        { heading: 'Hosts and IP addresses', body: 'An IP address identifies a network interface for communication. Packets use source and destination IP addresses so networks can route them.' },
        { heading: 'Routers and packets', body: 'A router forwards packets between networks based on routing information. A packet may pass through several networks before reaching its destination.' },
        { heading: 'Addresses are not ports', body: 'The IP address identifies the network destination; a transport port helps the operating system direct traffic to an application or service on that host.' }
      ],
      takeaways: ['IP addresses identify network interfaces.', 'Routers forward packets between networks.', 'IP addresses and transport ports serve different purposes.'],
      quiz: { question: 'What is the main role of an IP address in a network packet?', options: ['Identify a network destination', 'Encrypt the packet contents', 'Prove the sender is trustworthy', 'Choose the user’s password'], answer: 0, explanation: 'IP addresses help identify the source and destination for packet delivery; they do not inherently encrypt data or prove trust.' }
    },
    tcp_udp: {
      title: 'TCP, UDP, and ports',
      intro: 'TCP and UDP are transport protocols. Both use port numbers, but they provide different communication behaviors for applications.',
      sections: [
        { heading: 'TCP: reliable ordered stream', body: 'TCP establishes a connection and uses sequence numbers, acknowledgements, and retransmission mechanisms to provide reliable, ordered delivery while the connection works.' },
        { heading: 'UDP: independent datagrams', body: 'UDP sends datagrams without a TCP-style handshake or built-in delivery and ordering guarantees. Applications may add their own reliability when required.' },
        { heading: 'Ports identify services', body: 'A source port and destination port help identify the communicating application endpoints. Common examples include TCP port 443 for HTTPS over TCP and UDP port 53 for many DNS queries.' }
      ],
      takeaways: ['TCP provides a reliable, ordered byte stream.', 'UDP provides datagrams without built-in delivery guarantees.', 'Neither TCP nor UDP automatically encrypts data.'],
      quiz: { question: 'A file download needs reliable, ordered data delivery. Which transport protocol directly provides that service?', options: ['UDP', 'TCP', 'DNS', 'ARP'], answer: 1, explanation: 'TCP provides a reliable, ordered byte stream. UDP does not guarantee delivery or order, and DNS and ARP are not transport protocols.' }
    },
    dns_http: {
      title: 'DNS, HTTP, and HTTPS',
      intro: 'When you visit a website, your device needs to locate the service and exchange requests and responses. DNS and HTTP-family protocols play different roles in that process.',
      sections: [
        { heading: 'DNS finds names', body: 'DNS lets clients look up records associated with domain names, commonly including IP addresses. A DNS lookup does not itself load the webpage.' },
        { heading: 'HTTP exchanges web data', body: 'HTTP defines how clients send requests and servers return responses. A response includes a status code and may include webpage content or data.' },
        { heading: 'HTTPS protects the connection', body: 'HTTPS uses TLS to provide protections such as confidentiality and server authentication. It does not guarantee that the website is free from vulnerabilities.' }
      ],
      takeaways: ['DNS resolves names to records.', 'HTTP defines web requests and responses.', 'HTTPS protects the connection using TLS.'],
      quiz: { question: 'What is the main security benefit of HTTPS compared with plain HTTP?', options: ['It guarantees the site has no bugs', 'It removes the need for DNS', 'It protects the connection using TLS', 'It makes every request anonymous'], answer: 2, explanation: 'HTTPS uses TLS to protect data in transit and authenticate the server. It cannot guarantee the site has no bugs or make every request anonymous.' }
    },
    programming: {
      title: 'Programming and scripting basics',
      intro: 'Programming lets you describe steps a computer should perform. Small scripts help security students automate repetitive tasks and inspect data.',
      sections: [
        { heading: 'Variables and conditions', body: 'A variable stores a value. A condition lets a program choose what to do based on a result, such as whether a number is greater than zero.' },
        { heading: 'Loops and functions', body: 'A loop repeats work. A function groups reusable instructions behind a name, which makes programs easier to test and maintain.' },
        { heading: 'Read code in small steps', body: 'Follow the input, the operations, and the output. For a security script, also ask what data it reads, what it changes, and what happens when input is unexpected.' }
      ],
      takeaways: ['Variables store values.', 'Conditions make decisions; loops repeat work.', 'Functions organize reusable instructions.'],
      quiz: { question: 'What does an if statement normally do?', options: ['Runs code when a condition is met', 'Repeats code forever by default', 'Creates a database automatically', 'Encrypts every variable'], answer: 0, explanation: 'An if statement lets a program run a block of code when a condition evaluates as true.' }
    },
    security_fundamentals: {
      title: 'Security fundamentals',
      intro: 'Security is about reducing risk to information and systems. A useful starting point is understanding what must be protected, what could go wrong, and which controls help.',
      sections: [
        { heading: 'The CIA triad', body: 'Confidentiality limits disclosure to authorized parties. Integrity protects against improper changes. Availability means systems and data remain accessible when needed.' },
        { heading: 'Threats and vulnerabilities', body: 'A threat is something that could cause harm. A vulnerability is a weakness that could be exploited. Risk depends on the likelihood and impact of a harmful event.' },
        { heading: 'Layer your defenses', body: 'Defense in depth uses multiple controls, such as authentication, patching, backups, monitoring, and network filtering, so one failure does not expose everything.' }
      ],
      takeaways: ['Confidentiality, integrity, and availability are distinct security goals.', 'Threats and vulnerabilities are not the same thing.', 'Multiple complementary controls can reduce risk.'],
      quiz: { question: 'Which security goal focuses on preventing unauthorized disclosure of information?', options: ['Availability', 'Confidentiality', 'Integrity', 'Routing'], answer: 1, explanation: 'Confidentiality protects information from unauthorized disclosure. Integrity concerns improper changes, while availability concerns access when needed.' }
    },
    firewalls: {
      title: 'Firewalls and access control',
      intro: 'A firewall applies rules to network traffic. It can reduce exposure by allowing expected communications and blocking traffic that does not meet the policy.',
      sections: [
        { heading: 'Read a rule', body: 'A rule may consider source, destination, protocol, port, direction, and action. Read all conditions before deciding what traffic it permits.' },
        { heading: 'Use least privilege', body: 'Allow only the traffic a service needs. A broad rule may be convenient, but it can expose unnecessary services or systems.' },
        { heading: 'A firewall is one layer', body: 'Firewalls do not replace secure software, authentication, patching, monitoring, or endpoint protection. Investigate both allowed and blocked traffic in context.' }
      ],
      takeaways: ['Rules evaluate traffic against specified conditions.', 'Least privilege means allowing only what is needed.', 'Firewall rules are one part of a wider defense.'],
      quiz: { question: 'What does the principle of least privilege mean when configuring a firewall?', options: ['Allow every port for convenience', 'Allow only traffic needed for the task', 'Disable logging to save space', 'Trust all traffic from the internet'], answer: 1, explanation: 'Least privilege minimizes unnecessary access by allowing only the communication required for a service or task.' }
    },
    packet_analysis: {
      title: 'Packet analysis with Wireshark',
      intro: 'A packet analyzer captures and displays network traffic so you can examine protocols and metadata. Good analysis separates what the capture shows from what you suspect it means.',
      sections: [
        { heading: 'Start with metadata', body: 'Inspect timestamps, source and destination addresses, protocols, and ports. This provides context before you investigate deeper.' },
        { heading: 'Use display filters', body: 'Filters such as tcp, udp, or dns narrow the visible packets. A filter changes what you view; it does not change the captured traffic.' },
        { heading: 'Avoid jumping to conclusions', body: 'A single packet or failed response rarely proves an attack. Compare related events, understand the network context, and record your evidence.' }
      ],
      takeaways: ['Start with addresses, ports, protocol, and time.', 'Display filters help focus an investigation.', 'Traffic evidence needs context before it supports a conclusion.'],
      quiz: { question: 'What does the Wireshark display filter `tcp` do?', options: ['Deletes non-TCP packets from the capture', 'Shows TCP packets in the packet list', 'Encrypts the selected traffic', 'Proves TCP traffic is safe'], answer: 1, explanation: 'A display filter narrows the packets shown in the interface; it does not delete packets, encrypt traffic, or certify safety.' }
    },
    cryptography: {
      title: 'Encryption and cryptography basics',
      intro: 'Cryptography provides tools for protecting information and checking authenticity. Encryption, hashing, and digital signatures solve different problems.',
      sections: [
        { heading: 'Encryption protects confidentiality', body: 'Encryption transforms readable data into ciphertext using a key. Authorized parties with the right key can recover the original data.' },
        { heading: 'Hashing checks data', body: 'A cryptographic hash maps input to a fixed-size digest. Hashing is not the same as encryption; it is not designed to be reversed to retrieve the original message.' },
        { heading: 'Digital signatures support authenticity', body: 'Digital signatures can help verify that data was signed by the holder of a private key and was not changed after signing, when used and validated correctly.' }
      ],
      takeaways: ['Encryption protects confidentiality.', 'A hash is a digest, not an encrypted message.', 'Digital signatures help verify origin and integrity.'],
      quiz: { question: 'Which technique is designed to produce a digest for checking data integrity, rather than to recover the original data?', options: ['Hashing', 'Decryption', 'Compression', 'Routing'], answer: 0, explanation: 'A cryptographic hash produces a fixed-size digest and is not designed to be reversed like decryption.' }
    },
    web_security: {
      title: 'Web security foundations',
      intro: 'Web applications receive input, authenticate users, manage sessions, and handle data. Each of these steps can introduce security risks if it is not designed carefully.',
      sections: [
        { heading: 'Treat input as untrusted', body: 'Validate input and use safe APIs such as parameterized database queries. Never assume that data from a form, URL, or API is safe because it came from a user interface.' },
        { heading: 'Authentication and sessions', body: 'Authentication checks identity. Session management keeps track of an authenticated interaction. Weak passwords, exposed session tokens, or poor session handling can undermine access controls.' },
        { heading: 'Practice safely', body: 'Learn web vulnerabilities in intentionally vulnerable labs or systems where you have explicit permission. Never test real accounts or websites without authorization.' }
      ],
      takeaways: ['Validate input and use safe database APIs.', 'Authentication and session management are different concerns.', 'Only test systems you own or are authorized to assess.'],
      quiz: { question: 'Where should a beginner practice exploiting intentionally vulnerable web applications?', options: ['A random public website', 'A friend’s account without asking', 'An authorized training lab', 'A university system without permission'], answer: 2, explanation: 'Use a controlled training lab or a system with explicit authorization. Permission is required before testing real systems.' }
    },
    logs_siem: {
      title: 'Logs and SIEM fundamentals',
      intro: 'Systems create logs that record events. Security teams use these records to investigate what happened, when it happened, and which systems or accounts were involved.',
      sections: [
        { heading: 'Read the event fields', body: 'Useful fields can include timestamp, username, source address, event type, result, and host. Exact fields depend on the system producing the log.' },
        { heading: 'What a SIEM does', body: 'A Security Information and Event Management system collects and correlates events from multiple sources, then helps analysts search and investigate patterns.' },
        { heading: 'An alert is a lead', body: 'An alert deserves investigation but is not automatically proof of compromise. Compare it with surrounding events, known activity, and additional evidence.' }
      ],
      takeaways: ['Timestamps and identity fields help build a timeline.', 'A SIEM combines and searches events from many sources.', 'Validate alerts with context and additional evidence.'],
      quiz: { question: 'A SIEM raises an alert for an unusual login. What should an analyst do first?', options: ['Immediately delete the account logs', 'Treat the alert as proven compromise', 'Review related events and context', 'Ignore it because alerts are always false'], answer: 2, explanation: 'An alert is a starting point. Review related activity and context before deciding whether it indicates an incident.' }
    },
    incident_response: {
      title: 'Incident response basics',
      intro: 'Incident response is a structured way to handle suspected security events. A repeatable process helps teams limit harm while preserving information needed to understand what happened.',
      sections: [
        { heading: 'Identify and assess', body: 'Collect available evidence and determine which systems, accounts, and information may be affected. Keep notes about the timeline and the basis for decisions.' },
        { heading: 'Contain and investigate', body: 'Containment limits further harm, such as isolating an affected device under an approved procedure. Preserve relevant logs and evidence for investigation.' },
        { heading: 'Recover and learn', body: 'Restore systems safely, verify that controls work, and record lessons that can reduce the chance or impact of a repeat incident.' }
      ],
      takeaways: ['Follow a documented response process.', 'Containment limits harm; recovery returns systems to operation.', 'Preserve evidence and document decisions.'],
      quiz: { question: 'Why should an incident responder preserve relevant logs?', options: ['To make the incident look larger', 'To support investigation and reconstruct what happened', 'To guarantee there was no attack', 'To avoid documenting decisions'], answer: 1, explanation: 'Logs can support timelines and investigations. Deleting or changing them may remove important evidence.' }
    },
    ctf_basics: {
      title: 'Beginner CTF and lab practice',
      intro: 'Capture the Flag (CTF) challenges turn security concepts into small, structured problems. The aim is to learn by forming hypotheses, testing them safely, and documenting findings.',
      sections: [
        { heading: 'Read the challenge carefully', body: 'Identify the goal, available files, rules, and allowed tools. Small clues in the description can help narrow down what to investigate.' },
        { heading: 'Work methodically', body: 'Record observations, form one hypothesis at a time, and test it. If a result does not fit, revisit the evidence instead of blindly repeating commands.' },
        { heading: 'Stay in scope', body: 'Only interact with the challenge environment you are authorized to use. A CTF flag is a learning objective, not permission to attack unrelated systems.' }
      ],
      takeaways: ['Turn the prompt into a clear question.', 'Use evidence and document each step.', 'Keep all testing within the authorized environment.'],
      quiz: { question: 'A CTF challenge gives you a downloadable file. What is the best first step?', options: ['Run every tool you know at once', 'Read the prompt and inspect the file safely', 'Attack the organizer’s website', 'Ignore the challenge rules'], answer: 1, explanation: 'Start by understanding the goal and safely inspecting the provided material. Stay within the challenge scope.' }
    },
    readiness_review: {
      title: 'Review and readiness checkpoint',
      intro: 'This lesson helps connect the topics you studied. The goal is not memorization alone: explain the ideas in your own words and identify what still feels unclear.',
      sections: [
        { heading: 'Recall without notes', body: 'Choose two topics and write down the main idea, one example, and one security reason the topic matters. Then compare with your notes.' },
        { heading: 'Connect the concepts', body: 'Describe how a client uses networking, transport protocols, and application protocols to communicate. Add the security controls that help protect the exchange.' },
        { heading: 'Plan what comes next', body: 'List questions you want to ask when the course begins. If a foundation is still weak, revisit that lesson rather than adding unrelated advanced topics.' }
      ],
      takeaways: ['Explain ideas without relying entirely on notes.', 'Connect foundations to a real workflow.', 'Record questions and revisit weak areas.'],
      quiz: { question: 'What is the best way to use a readiness review?', options: ['Memorize topic names without examples', 'Skip every topic that felt difficult', 'Explain concepts and identify gaps to revisit', 'Start advanced tools without the foundations'], answer: 2, explanation: 'A readiness review is for checking understanding, connecting ideas, and identifying gaps to revisit.' }
    }
  };

  // Guided exercises turn a topic summary into an active study session.
  // Activities are safe, offline-friendly, and can be completed by beginners.
  // Every built-in lesson gets three additional focused questions beyond its lead question.
  // This keeps knowledge checks at four questions while staying aligned to the lesson topic.
  const LESSON_CHECK_BANK = {
    computer_basics: [
      { question: 'What is a process?', options: ['A program that is currently running', 'A folder containing only images', 'A network cable standard', 'A permanent backup copy'], answer: 0, explanation: 'A process is an instance of a program that is running and using system resources.' },
      { question: 'Why should an account have only the permissions it needs?', options: ['It makes every program run faster', 'It limits damage if the account or program is misused', 'It removes the need for updates', 'It hides all files from administrators'], answer: 1, explanation: 'Least privilege limits what an account or program can access, reducing the impact of mistakes or compromise.' },
      { question: 'Which example is a directory?', options: ['A container used to organize files', 'A program currently running in memory', 'An IP address', 'A password hash algorithm'], answer: 0, explanation: 'Directories (folders) organize files and other directories into a navigable structure.' }
    ],
    linux: [
      { question: 'What does `pwd` show?', options: ['The current working directory', 'All running processes', 'The current password', 'The IP address of every device'], answer: 0, explanation: '`pwd` prints the full path of the directory the terminal is currently in.' },
      { question: 'Which command creates a directory?', options: ['grep', 'mkdir', 'whoami', 'pwd'], answer: 1, explanation: '`mkdir` creates a new directory; `grep` searches text and `whoami` prints the current user.' },
      { question: 'Why should you inspect a command before using `sudo`?', options: ['It automatically deletes the command history', 'Elevated permissions can make system-wide changes', 'It guarantees the command is safe', 'It prevents files from being written'], answer: 1, explanation: '`sudo` can run commands with elevated privileges, so a mistaken command can affect important system files or settings.' }
    ],
    networking: [
      { question: 'What does a router mainly do?', options: ['Forward traffic between networks', 'Store every website password', 'Encrypt every file on a computer', 'Replace the operating system'], answer: 0, explanation: 'Routers forward packets between networks using addressing and routing information.' },
      { question: 'What is a subnet used for?', options: ['Dividing an IP network into smaller logical networks', 'Making a password impossible to guess', 'Compressing a video', 'Listing local files'], answer: 0, explanation: 'Subnetting divides an IP address space into smaller networks for routing and organization.' },
      { question: 'If a packet is sent to a different IP network, what device commonly forwards it onward?', options: ['A router or Layer 3 device', 'A keyboard', 'A text editor', 'A file permission bit'], answer: 0, explanation: 'A router or other Layer 3 device forwards IP packets between networks.' }
    ],
    tcp_udp: [
      { question: 'Which protocol is usually better when an application needs reliable, ordered delivery?', options: ['TCP', 'UDP', 'ARP', 'DNS'], answer: 0, explanation: 'TCP tracks delivery and ordering, and retransmits lost data when appropriate.' },
      { question: 'What is a port number used for at the transport layer?', options: ['Identifying an application endpoint on a host', 'Identifying a person’s physical location', 'Encrypting every packet', 'Replacing the destination IP address'], answer: 0, explanation: 'Transport-layer port numbers help deliver traffic to the correct application or service on a host.' },
      { question: 'Why might a live voice or game application choose UDP?', options: ['It has lower overhead and can favor timeliness over retransmission', 'It guarantees every packet arrives in order', 'It encrypts all data automatically', 'It resolves domain names'], answer: 0, explanation: 'Some real-time applications prefer timely delivery and can tolerate occasional loss, so they use UDP and handle reliability at the application layer if needed.' }
    ],
    dns_http: [
      { question: 'What commonly happens after a browser needs the IP address for a domain?', options: ['It queries DNS or uses a cached DNS result', 'It asks the firewall to write source code', 'It converts the domain into a password', 'It deletes the web page'], answer: 0, explanation: 'DNS provides records associated with a domain, often including an address the browser can connect to.' },
      { question: 'What does HTTPS add to HTTP?', options: ['Protection using TLS for the connection', 'A guarantee the website is honest', 'A way to avoid all DNS lookups', 'A promise that the server has no vulnerabilities'], answer: 0, explanation: 'HTTPS uses TLS to protect data in transit and authenticate the server, but it does not guarantee that the site itself is trustworthy or bug-free.' },
      { question: 'In a basic web exchange, what does an HTTP response usually contain?', options: ['A status code and response headers, often with a body', 'Only the computer’s local file permissions', 'The Wi-Fi password in plain text', 'A guaranteed list of every router on the internet'], answer: 0, explanation: 'HTTP responses include a status code and headers and often contain a body such as HTML or JSON.' }
    ],
    programming: [
      { question: 'What does a Boolean condition usually evaluate to?', options: ['True or false', 'A folder path only', 'A network cable type', 'A random image file'], answer: 0, explanation: 'A Boolean condition evaluates to true or false and can control the flow of a program.' },
      { question: 'What is a variable used for?', options: ['Naming a value that a program can use', 'Guaranteeing a program has no bugs', 'Encrypting a network automatically', 'Replacing all functions'], answer: 0, explanation: 'A variable provides a name for a value that code can read or update.' },
      { question: 'When a program gives an unexpected result, what is a useful first debugging step?', options: ['Reproduce the issue and inspect inputs and outputs', 'Delete the entire project immediately', 'Assume the operating system is broken', 'Change many unrelated lines at once'], answer: 0, explanation: 'Reproducing the issue and checking the inputs, outputs, and relevant steps helps isolate the cause.' }
    ],
    security_fundamentals: [
      { question: 'Which example is mainly an integrity problem?', options: ['An attacker changes a grade without permission', 'An authorized student reads a public timetable', 'A backup server stays available', 'A monitor is turned off'], answer: 0, explanation: 'Integrity concerns unauthorized or improper changes to information.' },
      { question: 'Which example is mainly an availability problem?', options: ['A service is knocked offline and users cannot access it', 'A private record is shown to an unauthorized person', 'A record is silently changed', 'A password is hashed'], answer: 0, explanation: 'Availability means systems and information are accessible when needed by authorized users.' },
      { question: 'What is defense in depth?', options: ['Using multiple complementary layers of security', 'Relying on one control to stop every threat', 'Disabling monitoring to reduce alerts', 'Giving every user full administrator access'], answer: 0, explanation: 'Multiple layers help prevent a single failed control from becoming a complete failure of security.' }
    ],
    firewalls: [
      { question: 'A firewall rule should generally allow which traffic?', options: ['Traffic required for an approved purpose', 'All traffic from everywhere by default', 'Only traffic with large packets', 'Every inbound connection regardless of need'], answer: 0, explanation: 'Rules should be based on the required service, direction, source, destination, and port, following least privilege.' },
      { question: 'What should you do before changing a production firewall rule?', options: ['Understand the intended traffic, impact, and rollback plan', 'Disable all logging permanently', 'Copy a random rule from the internet', 'Remove every existing rule'], answer: 0, explanation: 'Reviewing requirements, impact, authorization, and rollback steps helps prevent outages and unintended exposure.' },
      { question: 'Does a firewall by itself guarantee that a computer is secure?', options: ['No; it is one layer among several controls', 'Yes, against every possible attack', 'Yes, if the computer has a browser', 'Only if all logs are deleted'], answer: 0, explanation: 'Firewalls filter traffic but do not replace patching, secure configuration, authentication, monitoring, and user awareness.' }
    ],
    packet_analysis: [
      { question: 'What does a Wireshark display filter do?', options: ['Controls which captured packets are shown in the packet list', 'Permanently deletes hidden packets from the capture', 'Decrypts all encrypted traffic automatically', 'Proves a connection is harmless'], answer: 0, explanation: 'Display filters change what is shown, not the underlying capture file, and they do not certify whether traffic is safe.' },
      { question: 'Why may HTTPS application data be unreadable in a packet capture?', options: ['The payload is encrypted by TLS', 'IP addresses are never included in packets', 'Wireshark removes every payload by design', 'TCP cannot carry web traffic'], answer: 0, explanation: 'TLS encrypts application data in transit. A capture may still reveal metadata such as addresses, ports, timing, and packet sizes.' },
      { question: 'What is a good first step when investigating an unfamiliar packet capture?', options: ['Check the capture context, endpoints, protocols, and timing', 'Assume every packet is malicious', 'Delete packets that look unfamiliar', 'Run an exploit against the source address'], answer: 0, explanation: 'Understand where and when the capture was taken, then inspect endpoints, protocol patterns, and relevant details within authorized scope.' }
    ],
    cryptography: [
      { question: 'What is a cryptographic hash mainly designed to produce?', options: ['A fixed-size digest useful for integrity checking', 'A reversible copy of the original file', 'A network route', 'An operating-system user account'], answer: 0, explanation: 'A hash produces a digest; it is not encryption and is not designed to recover the original input.' },
      { question: 'In symmetric encryption, what is generally used to encrypt and decrypt data?', options: ['The same secret key', 'A public key and no secret key', 'A DNS record', 'A firewall port number'], answer: 0, explanation: 'Symmetric algorithms use the same secret key for encryption and decryption, so the key must be protected.' },
      { question: 'Why should passwords usually be stored using a password-hashing scheme rather than reversible encryption?', options: ['Verification can be done without storing a recoverable password', 'It allows administrators to read every password', 'It makes password reuse safe', 'It removes the need for account security'], answer: 0, explanation: 'A password-hashing scheme stores a one-way verifier, typically with a unique salt and a slow password hashing algorithm, rather than a recoverable password.' }
    ],
    web_security: [
      { question: 'Where should a beginner practice web security testing?', options: ['A dedicated lab or system with explicit permission', 'Any website that responds to requests', 'A stranger’s account', 'A university system without approval'], answer: 0, explanation: 'Security testing should only occur in environments you own or have clear authorization to test.' },
      { question: 'What is a common defense against SQL injection?', options: ['Parameterized queries and safe input handling', 'Putting every user input directly into SQL text', 'Disabling database backups', 'Hiding error messages while keeping unsafe SQL unchanged'], answer: 0, explanation: 'Parameterized queries separate data from SQL instructions and are a primary defense against SQL injection.' },
      { question: 'Why is server-side authorization needed even if a button is hidden in the webpage?', options: ['A user can bypass client-side interface restrictions', 'Hidden buttons encrypt the database', 'Browsers cannot send direct requests', 'It prevents all phishing attacks'], answer: 0, explanation: 'Client-side controls can be changed or bypassed; the server must verify permissions for each protected action.' }
    ],
    logs_siem: [
      { question: 'What is a SIEM commonly used to do?', options: ['Collect and correlate security events from multiple sources', 'Replace all endpoint protection tools', 'Guarantee every alert is correct', 'Automatically prove a person’s intent'], answer: 0, explanation: 'A SIEM centralizes and correlates logs to help analysts investigate patterns and alerts.' },
      { question: 'Why are consistent timestamps important when reviewing logs?', options: ['They help build a reliable sequence of events', 'They automatically stop intrusions', 'They encrypt each event', 'They prove every alert is a false positive'], answer: 0, explanation: 'Time alignment helps analysts correlate events across systems and reconstruct a timeline.' },
      { question: 'What is a sensible response to a suspicious SIEM alert?', options: ['Review related events and evidence before deciding', 'Delete the alert without recording why', 'Assume an attack is confirmed without checking', 'Disable all future alerts'], answer: 0, explanation: 'Alerts are signals for investigation; context and supporting evidence are needed to assess what happened.' }
    ],
    incident_response: [
      { question: 'Why preserve relevant logs and evidence during an incident?', options: ['They support timelines, analysis, and later review', 'They automatically repair every system', 'They make containment unnecessary', 'They should be deleted before reporting'], answer: 0, explanation: 'Preserving evidence helps responders understand scope, make defensible decisions, and support follow-up investigations.' },
      { question: 'What does containment try to achieve?', options: ['Limit ongoing harm while investigation and recovery continue', 'Erase every trace of the event', 'Prove the first alert was correct', 'Replace the need for documentation'], answer: 0, explanation: 'Containment aims to limit spread or impact while preserving the ability to investigate and recover safely.' },
      { question: 'After recovery, why conduct a lessons-learned review?', options: ['Identify causes and improve controls and procedures', 'Assign blame without evidence', 'Delete the incident record', 'Guarantee no incident can ever happen again'], answer: 0, explanation: 'A review identifies what worked, what failed, and practical improvements that may reduce future risk.' }
    ],
    ctf_basics: [
      { question: 'What is the safest first step when starting a CTF challenge?', options: ['Read the prompt and rules to understand the goal and scope', 'Scan unrelated public systems', 'Use every tool before inspecting the files', 'Ignore the challenge boundaries'], answer: 0, explanation: 'The prompt and rules define what is provided, what is allowed, and what successful completion means.' },
      { question: 'Why record hypotheses and results while solving a challenge?', options: ['It helps explain reasoning and avoid repeating failed attempts', 'It replaces the need to understand the task', 'It guarantees the first idea is correct', 'It makes unauthorized testing acceptable'], answer: 0, explanation: 'Notes make your process reproducible and reveal which ideas have already been tested.' },
      { question: 'What should you do if a challenge seems to require testing a target outside the listed scope?', options: ['Stop and ask the organizer or use the authorized environment', 'Continue because it is probably allowed', 'Try someone else’s account', 'Hide the activity from the organizer'], answer: 0, explanation: 'Stay within the explicitly authorized scope and get clarification rather than testing an unrelated target.' }
    ],
    readiness_review: [
      { question: 'Which study method best tests whether you can recall a concept without copying?', options: ['Close the notes and explain it from memory', 'Reread the heading repeatedly only', 'Highlight every sentence', 'Skip every practice question'], answer: 0, explanation: 'Active recall asks you to retrieve ideas without looking, making gaps in understanding easier to notice.' },
      { question: 'How can you check whether you understand a technical concept?', options: ['Explain it, give an example, and state its limits', 'Memorize one sentence without context', 'Only recognize the word when shown', 'Avoid questions about it'], answer: 0, explanation: 'Explaining, applying, and recognizing limits provides stronger evidence of understanding than recognition alone.' },
      { question: 'What is a useful next step after missing a knowledge-check question?', options: ['Read the explanation, correct your notes, then retry later', 'Ignore the explanation and keep guessing', 'Assume the whole course is impossible', 'Memorize only the letter of the answer'], answer: 0, explanation: 'Use the feedback to fix the misunderstanding, then revisit the question or a similar example after a short interval.' }
    ]
  };

  const LESSON_WORKSHOPS = {
    computer_basics: {
      example: 'Imagine you are asked to protect a class report. The report is a file; its folder is a directory; the document editor is an application; the editor while running is a process; your school login is a user account; and the file permissions decide who may view or change it. These are different parts of one workflow.',
      steps: [
        'Open your computer’s file manager and create a folder named AheadPath-Practice in a location you control.',
        'Inside it, create a text file named report.txt. Write one sentence in it, save it, close it, and reopen it.',
        'Open Task Manager on Windows or System Monitor on Linux/macOS. Find three running applications or processes and write down their names. Do not end any process.',
        'Inspect the file or folder properties and look for owner, sharing, or permissions information. Observe only—do not change system or school-managed settings.',
        'Make a small table with four columns: object, who needs access, what access they need, and what access would be unnecessary.'
      ],
      reflection: 'If a classmate only needs to read the report, why is giving them permission to edit or delete it unnecessary?'
    },
    linux: {
      example: 'A terminal opens in a current working directory. `pwd` tells you where you are, `ls` shows what is there, and `cd` changes location. Using these in sequence lets you navigate deliberately instead of guessing paths.',
      steps: ['Open a terminal in a Linux VM or another system you are allowed to use.', 'Run `pwd` and write down the current path.', 'Run `ls` and identify two entries. Use `ls -l` to observe permissions and ownership.', 'Create a practice directory with `mkdir aheadpath-practice`, then enter it with `cd aheadpath-practice`.', 'Use `printf "hello study\\n" > notes.txt` to create a file, `cat notes.txt` to read it, and `grep "study" notes.txt` to search it.', 'For each command, write what it reads or changes. Do not use `sudo` for this exercise.'],
      reflection: 'What could go wrong if you ran a command before checking your current directory and understanding the command’s effect?'
    },
    networking: {
      example: 'When a laptop opens a webpage, it sends traffic through a local network and a router toward a destination. IP addresses help identify endpoints; routers forward packets; ports help the destination computer deliver transport traffic to the correct service.',
      steps: ['Draw a simple path: laptop → Wi-Fi router → internet → website server.', 'Label where a private local IP address might be used and where a public destination address might appear.', 'Choose a familiar service such as a website, video call, or online game. Explain what each device on your drawing contributes.', 'On your own device, view network details using system settings. Record your own IP address type (private/public) only; do not share it publicly.', 'Explain why an IP address alone does not tell you which application on a host should receive the traffic.'],
      reflection: 'If you know a server’s IP address, what additional information can help identify the service you want to reach?'
    },
    tcp_udp: {
      example: 'A file download usually benefits from reliable, ordered delivery: missing pieces can be retransmitted. A live voice call may prioritize timeliness: late audio can be less useful than a small amount of lost audio. This is one reason applications choose different transport behaviors.',
      steps: ['Write one situation where receiving every byte in order matters and one where low delay matters more.', 'For each situation, choose TCP or UDP as a starting point and explain the trade-off.', 'Look up three familiar services and note their protocol/port only from a reputable reference; remember that services can use different transports or ports in different configurations.', 'Explain the difference between an IP address, a port number, and a transport protocol.', 'Correct this statement: “UDP is always faster and TCP is always secure.”'],
      reflection: 'Why is it inaccurate to say that TCP or UDP alone makes an application secure?'
    },
    dns_http: {
      example: 'When you enter a domain in a browser, the device may use DNS to find a destination address, then the browser sends an HTTP request. HTTPS protects the HTTP exchange with TLS. DNS lookup, connecting to the server, and requesting a page are related but separate steps.',
      steps: ['Choose a website you use and write its domain name without the path or page title.', 'Draw a sequence: DNS lookup → connection setup → HTTP request → response. Add TLS to the HTTPS connection.', 'Explain what a status code such as 200 or 404 tells the browser at a high level.', 'Compare HTTP and HTTPS from a network observer’s perspective. Note that encryption does not guarantee the site itself is trustworthy.', 'Use your diagram to explain why resolving a domain name does not mean the webpage has already loaded.'],
      reflection: 'What can HTTPS protect, and what kinds of problems does it not automatically solve?'
    },
    programming: {
      example: 'A script can read a value, test a condition, and choose an action. If `attempts` is greater than or equal to three, a program could display a warning; otherwise, it can allow another practice attempt. This is decision logic, not magic—the result follows from the condition.',
      steps: ['Write a plain-language algorithm that asks for a number and reports whether it is positive, zero, or negative.', 'Identify the input, the condition or conditions, and the output before writing code.', 'Write pseudocode using `IF`, `ELSE IF`, and `ELSE`.', 'Test your logic manually with -2, 0, and 5. Make a small table showing input and expected output.', 'Add one edge case and explain how you would check that the program handles it.'],
      reflection: 'Why should you test boundary values such as zero instead of checking only one ordinary example?'
    },
    security_fundamentals: {
      example: 'A student portal stores grades. Confidentiality means only authorized people can view them; integrity means grades cannot be changed improperly; availability means students and instructors can access the portal when needed. One incident can affect more than one goal.',
      steps: ['Choose an asset such as a student account, grade file, or campus service.', 'List one possible threat and one vulnerability. Keep the distinction clear: a threat can cause harm; a vulnerability is a weakness.', 'Describe one possible impact if the weakness is exploited.', 'Choose a practical control and explain which risk it reduces.', 'Label your example as primarily confidentiality, integrity, or availability—or explain why it affects more than one.'],
      reflection: 'Why does installing a security tool not remove the need for updates, safe configuration, and user awareness?'
    },
    firewalls: {
      example: 'Imagine a practice server that needs web traffic from users but should not accept remote administration from every internet address. A firewall rule can permit the intended web traffic while restricting administrative access to approved sources.',
      steps: ['Create a table with columns: source, destination, service/port, action, and reason.', 'Add a rule that permits intended web traffic to a fictional server.', 'Add a rule that restricts administrative access to a trusted management network.', 'Add a default-deny example and identify the legitimate traffic it could accidentally block.', 'Review every rule for least privilege. Do not change your real device or campus firewall.'],
      reflection: 'Why should a firewall rule specify the narrowest practical source, destination, and service rather than allow everything?'
    },
    packet_analysis: {
      example: 'A packet capture may show source and destination addresses, ports, protocol, timestamps, and sometimes payload data. A display filter narrows what you see; it does not block traffic or prove that a packet is malicious. Encrypted payloads generally remain unreadable without appropriate keys or endpoint context.',
      steps: ['Use a supplied training capture or an authorized lab capture—do not capture other people’s traffic.', 'Find one packet and record its timestamp, source, destination, protocol, and ports if present.', 'Find a second packet that uses a different protocol or endpoint.', 'Apply a display filter such as `dns` or `tcp` and explain how the visible list changes.', 'Write one observation, one hypothesis, and one limitation of your evidence.'],
      reflection: 'Why is one packet rarely enough to prove that a host has been compromised?'
    },
    cryptography: {
      example: 'Encryption is designed to make data unreadable without the necessary key; hashing creates a digest useful for integrity checks; digital signatures help verify origin and detect changes. These tools solve different problems and are not interchangeable.',
      steps: ['Create a three-column comparison: encryption, hashing, digital signatures.', 'For each, write the main purpose and a common use case.', 'Explain why a hash is not normally “decrypted” back into the original input.', 'Describe how a file’s hash could be compared with a trusted published hash to check integrity.', 'Name one thing a correct hash match cannot prove, such as whether the file is safe or from a trustworthy publisher.'],
      reflection: 'If you need to keep a message secret, why is storing only its hash not a replacement for encryption?'
    },
    web_security: {
      example: 'A website that places user input directly into a database query can expose itself to injection risks. Defensive design includes parameterized queries, server-side validation, safe error handling, and testing in an authorized environment.',
      steps: ['Choose an example web feature: login, search box, comment form, or profile update.', 'Identify what input the user controls and what sensitive action or data is involved.', 'Name one risk caused by trusting input without proper handling.', 'Suggest a defensive control such as parameterized queries, output encoding, or server-side authorization checks.', 'Practice testing only in an intentionally vulnerable lab or system where you have explicit permission.'],
      reflection: 'Why should authorization be checked on the server rather than relying only on hiding a button in the browser?'
    },
    logs_siem: {
      example: 'A login log may record time, account, source address, result, and device. A SIEM correlates events from multiple systems to highlight patterns, but an alert is a lead for investigation rather than automatic proof of an attack.',
      steps: ['Create three fictional login events with timestamps, account names, source labels, and success/failure results.', 'Mark which event looks unusual and state why, without assuming it proves compromise.', 'List two additional pieces of context that could confirm or disprove your hypothesis.', 'Put the events in time order and write a two-sentence incident note.', 'Avoid including real account names, passwords, or sensitive organization logs in your exercise.'],
      reflection: 'What additional evidence would you want before escalating an unusual-login alert as a confirmed incident?'
    },
    incident_response: {
      example: 'If a school account appears compromised, responders should assess available evidence, limit further harm using approved procedures, preserve relevant logs, restore access safely, and record lessons. Randomly deleting logs or wiping a device too early can destroy useful evidence.',
      steps: ['Write a fictional timeline of three events leading to a suspected account compromise.', 'List which account, device, or information could be affected.', 'Choose a containment action and state who should authorize it.', 'List evidence that should be preserved and where it may exist.', 'Write a short recovery check and one improvement that might prevent recurrence.'],
      reflection: 'Why is evidence preservation important while responders are trying to contain an incident?'
    },
    ctf_basics: {
      example: 'A CTF challenge gives a goal, a file or service, and a set of rules. A good solver first reads the prompt, inspects the provided material, makes a hypothesis, tests it, and records the result while staying inside the authorized scope.',
      steps: ['Choose an entry-level challenge from a reputable training platform or event you are authorized to use.', 'Rewrite the challenge goal as one clear question.', 'Record the files, clues, or outputs supplied before using tools.', 'Try one small hypothesis at a time and keep notes on what each result means.', 'Write a short solution summary that explains the reasoning, not only the final flag.'],
      reflection: 'How does documenting a failed attempt help you solve a challenge more efficiently?'
    },
    readiness_review: {
      example: 'A readiness review is useful when you can connect ideas, not just recognize their names. For example, explain how a browser uses DNS, establishes a protected connection, makes a request, and receives a response—and name at least one limitation of the security involved.',
      steps: ['Choose two lessons that felt challenging and summarize each from memory.', 'For each lesson, write one example and one reason it matters.', 'Connect two topics into a short workflow or diagram.', 'Check your notes and mark any statement you need to correct.', 'Write three specific questions to investigate next.'],
      reflection: 'Which concept can you explain confidently, and which one needs another practice session?'
    }
  };

  const LESSON_SLIDE_DETAILS = {
    computer_basics: {
      sections: [
        ['A path identifies where a file or folder sits in the directory tree.', 'Read, write, and execute are different permissions; a user may be able to read a file without being allowed to change it.'],
        ['A program becomes a process while it is running; multiple processes can use the same application.', 'The operating system separates user identity from the actions a process is allowed to perform.'],
        ['Least privilege reduces the damage a compromised account or application can cause.', 'Review both who can access a resource and whether that access is actually needed.']
      ],
      mistake: 'Having an account does not mean every file or system action should be available to it.',
      scenario: 'A classmate needs to read a report but should not edit or delete it. Give read access only, and confirm that the original file remains protected.'
    },
    linux: {
      sections: [
        ['pwd prints your current working directory; ls shows directory entries; cd changes directories.', 'Relative paths are interpreted from the current directory, while absolute paths start from the filesystem root.'],
        ['cat reads text, grep searches matching lines, and mkdir creates a directory.', 'Before executing a command, inspect its target path and options. Redirection symbols can create or overwrite files.'],
        ['sudo can run a command with elevated privileges, increasing the impact of mistakes.', 'Practice inside a directory or virtual machine you control, and prefer ordinary permissions when they are enough.']
      ],
      mistake: 'Do not assume a command is harmless because it is short. Check its options, target, and privilege level.',
      scenario: 'Before creating a file, run pwd and ls. Explain where the file will be saved and what each command changed.'
    },
    networking: {
      sections: [
        ['IPv4 addresses are commonly written as four decimal numbers; IPv6 uses a longer hexadecimal form.', 'An address may be private or public. A private address is normally used inside local networks and is not directly routed across the public internet.'],
        ['Routers examine destination information and forwarding tables to select a next hop.', 'The path can cross several networks; the route and delay can vary rather than following one permanent physical path.'],
        ['An IP address identifies a network interface or destination; a port identifies an application endpoint at the transport layer.', 'A service is typically described using a protocol plus a port, such as TCP/443, rather than a port alone.']
      ],
      mistake: 'An IP address does not identify a person with certainty, encrypt traffic, or prove that a host is trustworthy.',
      scenario: 'For a browser connection, identify the destination IP, the transport protocol, and the destination port as three different pieces of information.'
    },
    tcp_udp: {
      sections: [
        ['TCP numbers bytes and acknowledges received data; missing data can be retransmitted.', 'Its connection setup and control mechanisms add overhead but help applications receive an ordered stream.'],
        ['UDP provides a small datagram transport without built-in delivery or ordering guarantees.', 'Real-time voice, games, and DNS can use UDP, but an application must decide how to handle loss or add its own reliability.'],
        ['Ports help the operating system deliver traffic to the right application endpoint.', 'A port number does not encrypt the communication; security depends on the application and protections such as TLS.']
      ],
      mistake: 'TCP is not automatically secure, and UDP is not automatically faster or better. Choose based on application needs.',
      scenario: 'Compare a file transfer with a live voice call. Which needs complete ordered delivery, and which may prefer timeliness over retransmitting late data?'
    },
    dns_http: {
      sections: [
        ['A DNS resolver can use cache or query DNS servers to find records for a name.', 'A domain can have several records, and the answer may change over time; DNS lookup is not the same as loading content.'],
        ['An HTTP request includes a method, target, headers, and sometimes a body.', 'The response includes a status code, headers, and potentially content; a 404 indicates a resource was not found at that URL.'],
        ['TLS helps protect data in transit and authenticate the server according to the certificate and trust checks.', 'HTTPS does not prove that the business is honest, that the content is accurate, or that the web application has no vulnerabilities.']
      ],
      mistake: 'A padlock indicates a protected connection to a named site, not a guarantee that the site itself is safe or legitimate.',
      scenario: 'Trace a visit: resolve the domain, connect to the server, perform the protected HTTP exchange, and interpret the response.'
    },
    programming: {
      sections: [
        ['A variable names a value; a condition evaluates to true or false and selects a branch.', 'Boundary values such as zero often expose logic errors that ordinary positive examples do not reveal.'],
        ['Loops repeat a block; functions package reusable logic and can accept inputs and return results.', 'A loop should have a clear stopping condition, while a function should have a focused purpose.'],
        ['Trace the input, each operation, the branch taken, and the output.', 'Test ordinary, boundary, invalid, and unexpected inputs; do not assume a script behaves correctly after one successful run.']
      ],
      mistake: 'Code that runs without crashing is not necessarily correct; test its result against expected behavior.',
      scenario: 'For an algorithm that classifies numbers as negative, zero, or positive, test -2, 0, 5, and a non-number input.'
    },
    security_fundamentals: {
      sections: [
        ['Confidentiality limits disclosure, integrity protects against improper changes, and availability keeps services usable.', 'One event can affect several goals—for example, ransomware may alter files and prevent people from using them.'],
        ['A threat is a potential cause of harm; a vulnerability is a weakness; risk combines likelihood and impact.', 'A risk statement becomes clearer when it names an asset, a possible event, a weakness, and the consequence.'],
        ['Defense in depth uses complementary controls instead of trusting one product or setting.', 'Prevention, detection, response, backups, user training, and secure configuration support different parts of the security lifecycle.']
      ],
      mistake: 'A vulnerability is not the same as an attack, and installing one security tool does not eliminate risk.',
      scenario: 'For a student portal, identify one asset, one threat, one vulnerability, one possible impact, and one control that reduces the risk.'
    },
    firewalls: {
      sections: [
        ['A firewall evaluates traffic against ordered rules that may consider source, destination, port, protocol, and direction.', 'The default action matters: an explicit default-deny policy blocks traffic that was not intentionally allowed.'],
        ['Rules should match the narrowest practical source, destination, and service.', 'A broad allow rule can expose a service; an overly strict rule can also disrupt legitimate work if not tested.'],
        ['Firewall rules are one control layer, not a replacement for patching, authentication, endpoint protection, or monitoring.', 'Logging and periodic rule reviews help identify unexpected traffic and stale exceptions.']
      ],
      mistake: 'Opening a port does not make a service secure, and a firewall cannot fix application vulnerabilities by itself.',
      scenario: 'A web server needs web traffic from users but administration only from a management network. Write the narrow rules that meet both needs.'
    },
    packet_analysis: {
      sections: [
        ['A packet capture can include timestamps, addresses, ports, protocol fields, and payload bytes.', 'What is visible depends on the capture point, capture permissions, network setup, and whether traffic is encrypted.'],
        ['A display filter changes which captured packets are shown; it does not change the packets on the network.', 'Filters such as dns or tcp help narrow the evidence, but the analyst still needs to interpret context.'],
        ['A useful analysis records observations separately from hypotheses and conclusions.', 'One unusual packet is rarely enough to prove compromise; look at patterns, endpoints, time, and corroborating logs.']
      ],
      mistake: 'A packet capture is evidence, not an automatic verdict. Encrypted payloads usually cannot be read simply by opening the capture.',
      scenario: 'Record a packet timestamp, source, destination, protocol, and ports where available. Then state one observation and one unanswered question.'
    },
    cryptography: {
      sections: [
        ['Encryption uses a key to transform readable data into ciphertext and supports confidentiality.', 'The security depends on suitable algorithms, key management, and correct use—not on keeping the algorithm secret.'],
        ['A cryptographic hash maps data to a fixed-size digest and is designed to be one-way.', 'Compare a file hash with a trusted reference to detect changes; a matching hash alone does not prove that a file is safe.'],
        ['A digital signature can support integrity and origin verification when the signing key and trust process are reliable.', 'Signatures are not the same as encryption: a signed message can still be readable by anyone.']
      ],
      mistake: 'Encryption, hashing, and digital signatures solve different problems and should not be used interchangeably.',
      scenario: 'Choose the right tool for three goals: keep a message secret, detect a file change, and verify who signed a release.'
    },
    web_security: {
      sections: [
        ['Input can arrive from forms, URLs, cookies, APIs, or uploaded files and should be treated as untrusted.', 'Validation checks whether input meets expected rules; output encoding and parameterized queries address different injection risks.'],
        ['Parameterized queries keep data separate from SQL query structure.', 'Authorization checks should happen on the server for each sensitive action, even if the interface hides a button.'],
        ['Use layered defenses: server-side validation, safe output handling, authentication, authorization, secure sessions, and logging.', 'Practice testing only in a lab or environment where you have explicit authorization.']
      ],
      mistake: 'Client-side checks can improve usability but are not a security boundary; attackers can send requests without using the page interface.',
      scenario: 'For a search box, explain how user input could reach a database and identify a defensive control that prevents data from being treated as query syntax.'
    },
    logs_siem: {
      sections: [
        ['Logs may record timestamps, identity, source, action, result, device, and related event details.', 'Consistent time settings and context across systems improve the quality of a timeline.'],
        ['A SIEM collects and correlates events to highlight patterns that may warrant investigation.', 'Alerts may be false positives or expected behavior; triage checks the context before declaring an incident.'],
        ['A good analyst records the observed facts, hypothesis, evidence checked, and next action.', 'Preserve relevant records and avoid placing secrets or unnecessary personal data in notes.']
      ],
      mistake: 'An alert is not proof of compromise. Confirm the signal using related events, user or device context, and other evidence.',
      scenario: 'Three failed logins followed by a success may be suspicious. Identify two sources of context you would review before concluding the account was compromised.'
    },
    incident_response: {
      sections: [
        ['Responders first establish what is known, what may be affected, and whether immediate harm is continuing.', 'Use the organization’s approved response procedures and decision authority rather than improvising destructive changes.'],
        ['Containment aims to limit further damage; evidence preservation supports later analysis.', 'Actions such as wiping a device or deleting logs too early can remove information needed to understand what happened.'],
        ['Recovery verifies that systems are safe to return to service and that access is restored appropriately.', 'A post-incident review turns findings into improvements such as better monitoring, safer configuration, or updated procedures.']
      ],
      mistake: 'Fast action is not always good action: preserve evidence and follow approved procedures while reducing active harm.',
      scenario: 'A school account may be compromised. List an immediate containment action, two types of evidence to preserve, and one recovery check.'
    },
    ctf_basics: {
      sections: [
        ['The prompt defines the goal, the provided evidence, and often the permitted environment.', 'Read the rules first and keep all testing inside the scope authorized by the organizer.'],
        ['A hypothesis should be small enough to test and should predict an observable result.', 'Inspect files and outputs before choosing tools; record what each action changes or reveals.'],
        ['A good write-up explains the reasoning, evidence, and final result.', 'Notes about failed attempts are useful because they prevent repeating the same test and help another learner reproduce the solution.']
      ],
      mistake: 'A CTF invitation is not permission to scan unrelated public hosts; scope only covers the targets and actions the rules authorize.',
      scenario: 'Before using a tool, write the challenge goal, the evidence you have, one hypothesis, and the result that would support or reject it.'
    },
    readiness_review: {
      sections: [
        ['Recall requires producing the explanation without seeing it first.', 'A short self-explanation helps reveal which steps are missing or confused.'],
        ['Connecting two topics shows whether the relationship is understood, not just each definition separately.', 'Diagrams and worked examples can make sequence, dependencies, and cause-and-effect easier to inspect.'],
        ['Mistakes are most useful when you identify the specific misconception and correct it.', 'Space a second review after a delay rather than relying only on immediate rereading.']
      ],
      mistake: 'Recognizing a familiar sentence is not the same as being able to explain or apply the idea without it.',
      scenario: 'Choose two course concepts and explain how the output of one becomes the input or requirement for the other.'
    }
  };

  function makeSlidePoint(title, text) {
    return { title: String(title || ''), text: String(text || '') };
  }

  function splitUsefulSentences(text, limit = 3) {
    const normalized = String(text || '').replace(/\s+/g, ' ').trim();
    if (!normalized) return [];
    const matches = normalized.match(/[^.!?]+[.!?]?/g) || [normalized];
    return matches.map(item => item.trim()).filter(Boolean).slice(0, limit);
  }

  function buildLectureSlides(task, lesson, workshop) {
    const isSyllabusLecture = Boolean(task.custom_lesson);
    const extra = isSyllabusLecture ? {
      sections: [],
      mistake: (lesson.common_misconceptions || [])[0] || 'Check whether your interpretation is supported by the evidence and the assumptions in the problem.',
      scenario: lesson.case_study?.scenario || 'Use the case study in this lecture to test the limits of the main concepts.'
    } : (LESSON_SLIDE_DETAILS[task.module_id] || LESSON_SLIDE_DETAILS.readiness_review);
    const objectives = (Array.isArray(task.objectives) ? task.objectives : task.objectives ? [task.objectives] : [])
      .map(value => String(value).trim()).filter(Boolean).slice(0, 4);
    const goalPoints = (objectives.length ? objectives : lesson.sections.slice(0, 3).map(section => `Explain ${section.heading.toLowerCase()} and how it relates to ${lesson.title.toLowerCase()}.`))
      .map((item, index) => makeSlidePoint(`Learning outcome ${index + 1}`, item));
    const slides = [
      {
        kicker: `WEEK ${task.weekNumber || '—'} · ${task.category || 'COURSE LECTURE'}`,
        type: 'LECTURE OPENING', title: lesson.title || task.title,
        lead: lesson.intro,
        points: goalPoints,
        callout: { label: 'How to use this deck', text: 'Move through the slides in order. Pause to explain the idea in your own words, then compare your understanding with the worked example and case study.' },
        footer: 'Start with the big idea; details will build on it.'
      },
      {
        kicker: 'THE BIG PICTURE', type: 'CONCEPT MAP', title: 'How the key ideas fit together',
        lead: `This lesson connects ${lesson.sections.map(section => section.heading.toLowerCase()).join(', ')}. Learn each part, then explain how the parts work together rather than memorizing them as separate definitions.`,
        points: lesson.sections.map((section, index) => makeSlidePoint(`0${index + 1} · ${section.heading}`, splitUsefulSentences(section.body, 1)[0] || section.body)),
        callout: { label: 'Study question', text: `How does understanding ${lesson.sections[0]?.heading.toLowerCase() || 'the first concept'} help you make sense of ${lesson.sections[1]?.heading.toLowerCase() || 'the next concept'}?` },
        footer: 'Concepts become more useful when you can connect them.'
      }
    ];

    lesson.sections.forEach((section, index) => {
      const topicDetails = extra.sections[index] || [
        'Identify the main term, what it does, and what information it depends on.',
        'Apply the idea to a small example and explain what would count as evidence that it worked.'
      ];
      const sentences = splitUsefulSentences(section.body, 4);
      const points = [];
      if (sentences.length > 1) points.push(makeSlidePoint('Break it down', sentences.slice(1).join(' ')));
      topicDetails.forEach((detail, detailIndex) => points.push(makeSlidePoint(detailIndex === 0 ? 'Important detail' : 'Application detail', detail)));
      slides.push({
        kicker: `CORE IDEA ${index + 1} OF ${lesson.sections.length}`,
        type: 'EXPLAIN THE CONCEPT', title: section.heading,
        lead: section.body,
        points: points.slice(0, 4),
        callout: { label: index === 0 ? 'Why this matters' : 'Put it into context', text: index === 0
          ? (task.why || `This idea is a foundation for ${lesson.title.toLowerCase()} and helps you interpret the later examples.`)
          : `Connect this idea to the earlier slide and use it to explain a real situation involving ${task.title.toLowerCase()}.` },
        footer: 'Pause and state the concept without reading the slide.'
      });
    });

    const worked = lesson.worked_example || {};
    const workedSteps = isSyllabusLecture
      ? (worked.solution_steps || []).slice(0, 5)
      : (workshop.steps || []).slice(0, 3);
    slides.push({
      kicker: 'WORKED EXAMPLE', type: 'FOLLOW THE REASONING', title: worked.title || 'See the concept in action',
      lead: worked.scenario || workshop.example || task.practice || `Apply ${task.title} to a realistic example.`,
      points: workedSteps.map((step, index) => makeSlidePoint(`Reasoning ${index + 1}`, step)),
      callout: { label: isSyllabusLecture ? 'Interpretation' : 'Before you reveal the solution', text: isSyllabusLecture
        ? (worked.conclusion || 'Explain what the result shows and identify any assumptions or limitations.')
        : 'Predict the first step and explain why it is appropriate. Then compare your answer with the worked example.' },
      footer: 'Focus on why each step follows from the evidence.'
    });

    const caseStudy = lesson.case_study || {};
    if (isSyllabusLecture) {
      slides.push({
        kicker: 'APPLY YOUR KNOWLEDGE', type: 'CASE STUDY CHALLENGE', title: caseStudy.title || 'Test the concepts in context',
        lead: caseStudy.scenario || 'Use the case study in the lecture notes to apply the module concepts.',
        points: (caseStudy.discussion_questions || []).slice(0, 4).map((question, index) => makeSlidePoint(`Discussion ${index + 1}`, question)),
        callout: { label: 'Before reading the analysis', text: 'Form your own explanation first. Identify which concepts from this lecture are relevant and what evidence you would need.' },
        footer: 'Compare your reasoning with the case analysis later in the deck.'
      });
    } else {
      const practiceSteps = (workshop.steps || []).slice(3, 6);
      slides.push({
        kicker: 'APPLY YOUR KNOWLEDGE', type: 'PRACTICE', title: 'Try it yourself',
        lead: task.practice || `Apply ${task.title} using a small example you can explain and verify.`,
        points: (practiceSteps.length ? practiceSteps : (workshop.steps || []).slice(0, 3)).map((step, index) => makeSlidePoint(`Task ${index + 1}`, step)),
        callout: { label: 'What a strong answer includes', text: 'State your goal, show the reasoning, give the result, and mention one limitation or check. Use only systems and data you are authorized to use.' },
        footer: 'Use the worked example and case study to evaluate whether you can apply the concept.'
      });
      slides.push({
        kicker: 'COMMON PITFALLS', type: 'CHECK YOUR REASONING', title: 'What this concept does not mean',
        lead: extra.mistake,
        points: [
          makeSlidePoint('Check the limits', `Explain one situation where ${lesson.title.toLowerCase()} cannot by itself guarantee the desired result.`),
          makeSlidePoint('Use evidence', 'Separate what you directly observed from what you think it means. State which additional detail would confirm your conclusion.'),
          makeSlidePoint('Be precise', 'Use the terms from this lesson accurately; related terms are not automatically interchangeable.')
        ],
        callout: { label: 'Scenario to think through', text: extra.scenario },
        footer: 'Knowing a concept’s limits is part of understanding it.'
      });
    }

    if (lesson.key_terms?.length) {
      slides.push({
        kicker: 'KEY TERMINOLOGY', type: 'ACADEMIC VOCABULARY', title: 'Terms you should use precisely',
        lead: 'Use the vocabulary accurately: these terms describe distinct ideas, mechanisms, or roles in the subject.',
        points: lesson.key_terms.slice(0, 8).map(term => makeSlidePoint(term.term, term.definition)),
        callout: { label: 'Check your understanding', text: 'Choose two terms that are easy to confuse. Explain the difference and give an example of each.' },
        footer: 'Precise terminology supports precise reasoning.'
      });
    }
    if (lesson.case_study?.scenario) {
      slides.push({
        kicker: 'CASE STUDY', type: 'APPLY THE THEORY', title: caseStudy.title || 'Analyze a realistic case',
        lead: caseStudy.scenario,
        points: (caseStudy.analysis || []).slice(0, 5).map((point, index) => makeSlidePoint(`Analysis ${index + 1}`, point)),
        callout: { label: 'Discussion', text: (caseStudy.discussion_questions || [])[0] || 'Which evidence supports your interpretation, and what additional information would you need?' },
        footer: 'This is an illustrative teaching case unless the source says otherwise.'
      });
    }
    if (lesson.common_misconceptions?.length) {
      slides.push({
        kicker: 'COMMON MISCONCEPTIONS', type: 'REFINE YOUR UNDERSTANDING', title: 'Where students often go wrong',
        lead: 'A strong understanding includes knowing which tempting explanations are incomplete or incorrect.',
        points: lesson.common_misconceptions.slice(0, 5).map((point, index) => makeSlidePoint(`Misconception ${index + 1}`, point)),
        callout: { label: 'Self-check', text: 'Explain why one of these misconceptions sounds plausible, then identify the precise correction.' },
        footer: 'Understanding includes being able to correct a misconception.'
      });
    }

    slides.push({
      kicker: 'REVIEW AND RETRIEVAL', type: 'KEY TAKEAWAYS', title: 'What you should remember',
      lead: `You should now be able to explain the main ideas in ${lesson.title.toLowerCase()} and apply them to a simple example.`,
      points: lesson.takeaways.map((item, index) => makeSlidePoint(`Takeaway ${index + 1}`, item)),
      callout: { label: 'Final recall prompt', text: workshop.reflection || `Teach ${lesson.title.toLowerCase()} to a friend in 60 seconds. Include one example and one limitation.` },
      footer: 'Next: complete the knowledge check and review its explanations.'
    });
    return slides;
  }

  function renderLectureSlide(index, { scroll = false, fromSpeech = false } = {}) {
    if (!activeLessonSlides.length) return;
    if (!fromSpeech && (speechPlaybackState === 'playing' || speechPlaybackState === 'paused')) {
      resetAudioPlayer();
      const status = $('#audioStatus');
      if (status) status.textContent = 'Slide changed. Narration stopped; press Listen to start from this slide.';
    }
    activeSlideIndex = Math.max(0, Math.min(activeLessonSlides.length - 1, Number(index) || 0));
    const slide = activeLessonSlides[activeSlideIndex];
    $('#slideKicker').textContent = slide.kicker;
    $('#slideTypeLabel').textContent = slide.type;
    $('#slideTitle').textContent = slide.title;
    $('#slideLead').textContent = slide.lead || '';
    $('#slidePoints').innerHTML = (slide.points || []).map((point, pointIndex) => `
      <div class="slide-point-card"><span class="slide-point-number">${String(pointIndex + 1).padStart(2, '0')}</span><div><strong>${escapeHtml(point.title)}</strong><p>${escapeHtml(point.text)}</p></div></div>`).join('');
    const callout = $('#slideCallout');
    if (slide.callout?.text) {
      callout.classList.remove('hidden');
      $('#slideCalloutLabel').textContent = slide.callout.label || 'Remember';
      $('#slideCalloutText').textContent = slide.callout.text;
    } else callout.classList.add('hidden');
    $('#slideFooter').textContent = slide.footer || '';
    $('#slideCounter').textContent = `${activeSlideIndex + 1} / ${activeLessonSlides.length}`;
    $('#slideProgressTrack').setAttribute('aria-valuemax', String(activeLessonSlides.length));
    $('#slideProgressTrack').setAttribute('aria-valuenow', String(activeSlideIndex + 1));
    $('#slideProgressFill').style.width = `${((activeSlideIndex + 1) / activeLessonSlides.length) * 100}%`;
    $('#previousSlideButton').disabled = activeSlideIndex === 0;
    $('#nextSlideButton').disabled = activeSlideIndex === activeLessonSlides.length - 1;
    $('#previousSlideButton').textContent = activeSlideIndex === 0 ? '← First slide' : '← Previous slide';
    $('#nextSlideButton').textContent = activeSlideIndex === activeLessonSlides.length - 1 ? 'End of lecture ✓' : 'Next slide →';
    $('#slideDots').innerHTML = activeLessonSlides.map((item, dotIndex) => `<button type="button" class="slide-dot ${dotIndex === activeSlideIndex ? 'is-active' : ''}" data-slide-go="${dotIndex}" aria-label="Go to slide ${dotIndex + 1}: ${escapeHtml(item.title)}" aria-current="${dotIndex === activeSlideIndex ? 'step' : 'false'}"><span>${dotIndex + 1}</span></button>`).join('');
    if (scroll) $('#lessonSlideDeck').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function downloadLectureSlides() {
    if (!activeLessonSlides.length || !activeTaskId) return;
    const task = findTask(activeTaskId);
    const title = activeLessonContext?.lesson?.title || task?.title || 'lecture-slides';
    const deckSlides = activeLessonSlides.map((slide, index) => `
      <article class="slide ${index === 0 ? 'active' : ''}" data-slide="${index}" aria-hidden="${index !== 0}">
        <div class="kicker">${escapeHtml(slide.kicker)} · ${escapeHtml(slide.type)}</div>
        <h2>${escapeHtml(slide.title)}</h2>
        <p class="lead">${escapeHtml(slide.lead || '')}</p>
        <div class="points">${(slide.points || []).map((point, pointIndex) => `<section class="point"><span>${String(pointIndex + 1).padStart(2, '0')}</span><div><h3>${escapeHtml(point.title)}</h3><p>${escapeHtml(point.text)}</p></div></section>`).join('')}</div>
        ${slide.callout?.text ? `<aside class="callout"><strong>${escapeHtml(slide.callout.label || 'Remember')}</strong><p>${escapeHtml(slide.callout.text)}</p></aside>` : ''}
        <footer>${escapeHtml(slide.footer || '')} <span>Slide ${index + 1} / ${activeLessonSlides.length}</span></footer>
      </article>`).join('');
    const safeCourseTitle = escapeHtml(currentRoadmap?.course_title || 'AheadPath course');
    const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)} — Lecture slides</title>
<style>
:root{font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;color:#18243b;background:#f3f5fb;font-synthesis:none}*{box-sizing:border-box}body{margin:0;padding:24px;background:linear-gradient(135deg,#f7f6ff,#f3f7fd);min-height:100vh}.deck{max-width:1080px;margin:0 auto}.deck-head{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:18px}.eyebrow{font-size:11px;font-weight:850;letter-spacing:1.3px;text-transform:uppercase;color:#6254d6}.course{font-size:13px;color:#64718a;margin-top:5px}.counter{font-weight:800;color:#6558d7;white-space:nowrap}.rail{height:7px;background:#e1e5f0;border-radius:100px;overflow:hidden;margin-bottom:17px}.rail span{display:block;height:100%;width:0;background:linear-gradient(90deg,#6254d6,#9b8cf8);transition:width .2s}.slide{display:none;min-height:min(72vh,750px);padding:clamp(24px,5vw,54px);border:1px solid #e1e5ef;border-radius:24px;background:white;box-shadow:0 20px 70px #24315b12}.slide.active{display:block}.kicker{font-size:11px;font-weight:850;letter-spacing:1.2px;color:#6558d7}.slide h2{font-size:clamp(29px,4vw,45px);line-height:1.14;letter-spacing:-1px;margin:18px 0;color:#18243b}.lead{font-size:clamp(16px,1.8vw,19px);line-height:1.85;color:#43536c;max-width:900px}.points{display:grid;grid-template-columns:repeat(auto-fit,minmax(235px,1fr));gap:13px;margin:27px 0}.point{display:grid;grid-template-columns:30px 1fr;gap:11px;padding:16px;border-radius:14px;border:1px solid #e3e7f1;background:#fbfcff}.point>span{display:grid;place-items:center;width:29px;height:29px;border-radius:9px;background:#efedff;color:#5d4fd1;font-size:11px;font-weight:850}.point h3{font-size:15px;margin:3px 0 7px;color:#202d45}.point p{margin:0;font-size:14px;line-height:1.75;color:#5b6880}.callout{padding:17px 19px;background:#f4f2ff;border-left:4px solid #7164e8;border-radius:0 13px 13px 0;margin-top:20px}.callout strong{color:#4f42c6;font-size:12px;text-transform:uppercase;letter-spacing:.6px}.callout p{font-size:14px;line-height:1.75;color:#3e4a65;margin:6px 0 0}.slide footer{display:flex;justify-content:space-between;gap:14px;margin-top:28px;padding-top:15px;border-top:1px solid #edf0f6;color:#7a8498;font-size:12px}.nav{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:17px}.nav button{border:1px solid #d9dfee;border-radius:10px;background:white;color:#293650;padding:11px 16px;font:inherit;font-size:13px;font-weight:750;cursor:pointer}.nav button:disabled{opacity:.4;cursor:not-allowed}.hint{text-align:center;color:#778198;font-size:12px;margin:14px 0}.nav .navlabel{font-size:12px;color:#656f84}.slide[aria-hidden="true"]{display:none}@media(max-width:600px){body{padding:10px}.deck-head{align-items:flex-start;flex-direction:column}.slide{padding:20px;border-radius:16px;min-height:65vh}.points{grid-template-columns:1fr}.nav button{padding:10px}.slide footer{flex-direction:column}}@media print{body{padding:0;background:white}.deck-head,.rail,.nav,.hint{display:none!important}.slide,.slide[aria-hidden="true"]{display:block!important;page-break-after:always;min-height:0;border:0;border-radius:0;box-shadow:none}.slide:last-child{page-break-after:auto}.slide h2{font-size:30pt}.lead{font-size:15pt}.point p,.callout p{font-size:12pt}}
</style></head><body><main class="deck"><header class="deck-head"><div><div class="eyebrow">AheadPath · ${safeCourseTitle}</div><div class="course">${escapeHtml(task?.title || title)}</div></div><strong class="counter" id="counter">1 / ${activeLessonSlides.length}</strong></header><div class="rail"><span id="railFill"></span></div><section id="slides">${deckSlides}</section><nav class="nav"><button type="button" id="prev" disabled>← Previous slide</button><span class="navlabel">Use ← and → arrow keys to navigate · Print to save as PDF</span><button type="button" id="next">Next slide →</button></nav><p class="hint">Download created by AheadPath. Use your browser's Print command to print the slides or save them as a PDF.</p></main>
<script>(()=>{const slides=[...document.querySelectorAll('.slide')];let i=0;const counter=document.getElementById('counter'),fill=document.getElementById('railFill'),prev=document.getElementById('prev'),next=document.getElementById('next');function show(n){i=Math.max(0,Math.min(slides.length-1,n));slides.forEach((s,j)=>{s.classList.toggle('active',j===i);s.setAttribute('aria-hidden',j===i?'false':'true')});counter.textContent=(i+1)+' / '+slides.length;fill.style.width=((i+1)/slides.length*100)+'%';prev.disabled=i===0;next.disabled=i===slides.length-1;next.textContent=i===slides.length-1?'End of lecture ✓':'Next slide →'}prev.addEventListener('click',()=>show(i-1));next.addEventListener('click',()=>show(i+1));document.addEventListener('keydown',e=>{if(e.key==='ArrowRight')show(i+1);else if(e.key==='ArrowLeft')show(i-1)});show(0)})();</script></body></html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'lecture-slides';
    link.href = url;
    link.download = `aheadpath-${slug}-slides.html`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('Interactive slide deck downloaded. Open it in a browser or print it to PDF.');
  }

  const LESSON_TIME_PLAN = [
    { id: 'preview', ratio: 0.08, title: 'Preview', detail: 'Write what you already know before studying.' },
    { id: 'coreIdeas', ratio: 0.17, title: 'Learn the core ideas', detail: 'Explain one idea in your own words and compare it with the lecture.' },
    { id: 'workedExample', ratio: 0.20, title: 'Study the worked example', detail: 'Predict a solution, then reveal and follow the steps one at a time.' },
    { id: 'handsOn', ratio: 0.35, title: 'Hands-on practice', detail: 'Complete the guided activity and explain your decisions.' },
    { id: 'recall', ratio: 0.10, title: 'Recall from memory', detail: 'Hide the notes and teach the topic back from memory.' },
    { id: 'knowledgeCheck', ratio: 0.10, title: 'Knowledge check', detail: 'Answer the quiz and review the explanations.' }
  ];

  function getLessonTimePlan(hours) {
    const totalMinutes = Math.max(15, Math.round((Number(hours) || 1) * 60));
    let allocated = 0;
    return LESSON_TIME_PLAN.map((step, index) => {
      const minutes = index === LESSON_TIME_PLAN.length - 1
        ? totalMinutes - allocated
        : Math.max(1, Math.round(totalMinutes * step.ratio));
      allocated += minutes;
      return { ...step, minutes };
    });
  }

  const STUDY_ACTIVITY_IDS = ['preview', 'coreIdeas', 'workedExample', 'handsOn', 'recall', 'knowledgeCheck'];
  const STUDY_ACTIVITY_TARGETS = {
    preview: '#previewActivity', coreIdeas: '#coreIdeasActivity', workedExample: '#workedExampleActivity',
    handsOn: '#handsOnActivity', recall: '#recallActivity', knowledgeCheck: '#knowledgeCheckActivity'
  };
  let activeStudyState = null;
  let activeWorkedExampleSteps = [];

  function createDefaultStudyState() {
    return {
      responses: { preview: '', coreIdea: '', workedPrediction: '', practice: [], recall: '' },
      completed: { preview: false, coreIdeas: false, workedExample: false, handsOn: false, recall: false, knowledgeCheck: false },
      coreConceptIndex: '0', workedExampleStep: 0, workedPredictionSubmitted: false,
      recallHiddenOnce: false, recallNotesHidden: false
    };
  }

  function studyStateStorageKey(taskId) {
    return `aheadpath-study-activities-${currentCourseId || currentRoadmap?.roadmap_id || 'course'}-${taskId}`;
  }

  function loadStudyState(taskId) {
    const defaults = createDefaultStudyState();
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(studyStateStorageKey(taskId)) || 'null'); } catch (_) { saved = null; }
    activeStudyState = {
      ...defaults, ...(saved || {}),
      responses: { ...defaults.responses, ...(saved?.responses || {}), practice: Array.isArray(saved?.responses?.practice) ? saved.responses.practice : [] },
      completed: { ...defaults.completed, ...(saved?.completed || {}) }
    };
    if (completedTasks[taskId]) STUDY_ACTIVITY_IDS.forEach(id => { activeStudyState.completed[id] = true; });
    activeStudyState.workedExampleStep = Math.max(0, Math.min(4, Number(activeStudyState.workedExampleStep) || 0));
    activeStudyState.coreConceptIndex = String(activeStudyState.coreConceptIndex ?? '0');
    return activeStudyState;
  }

  function persistStudyState() {
    if (!activeTaskId || !activeStudyState) return;
    try { localStorage.setItem(studyStateStorageKey(activeTaskId), JSON.stringify(activeStudyState)); } catch (_) { /* The activity still works if browser storage is unavailable. */ }
  }

  function studyActivityDone(id) {
    return Boolean(completedTasks[activeTaskId] || activeStudyState?.completed?.[id]);
  }

  function allStudyActivitiesDone() {
    return Boolean(lessonAnswerCorrect || activeStudyState?.completed?.knowledgeCheck);
  }

  function refreshStudyActivityUI() {
    if (!activeStudyState) return;
    let doneCount = 0;
    $$('#lessonTimePlan .lesson-time-step').forEach(card => {
      const id = card.dataset.step;
      const complete = studyActivityDone(id);
      const hasWork = id === 'preview' ? Boolean(activeStudyState.responses.preview.trim())
        : id === 'coreIdeas' ? Boolean(activeStudyState.responses.coreIdea.trim())
          : id === 'workedExample' ? Boolean(activeStudyState.responses.workedPrediction.trim() || activeStudyState.workedExampleStep)
            : id === 'handsOn' ? activeStudyState.responses.practice.some(value => String(value || '').trim())
              : id === 'recall' ? Boolean(activeStudyState.responses.recall.trim()) : false;
      card.classList.toggle('is-complete', complete);
      const number = $('.lesson-time-index', card);
      if (number) number.textContent = complete ? '✓' : card.dataset.stepNumber;
      const status = $('[data-step-status]', card);
      if (status) status.textContent = complete ? 'Completed' : hasWork ? 'In progress' : 'Not started';
      const action = $('[data-study-jump]', card);
      if (action) action.textContent = complete ? 'Review activity ↗' : 'Start activity →';
      if (complete) doneCount += 1;
    });
    const progress = $('#lessonStepProgress');
    if (progress) progress.textContent = `${doneCount} of ${STUDY_ACTIVITY_IDS.length} activities complete`;
    const message = $('#studyStepGuidance');
    if (message) message.textContent = doneCount === STUDY_ACTIVITY_IDS.length
      ? 'All activities completed. You can continue to the next lesson.'
      : `Complete ${STUDY_ACTIVITY_IDS.length - doneCount} more ${STUDY_ACTIVITY_IDS.length - doneCount === 1 ? 'activity' : 'activities'} to unlock the next lesson.`;
  }

  function renderStudyPlan(task) {
    $('#lessonTimePlan').innerHTML = getLessonTimePlan(task.hours).map((step, index) => {
      const complete = studyActivityDone(step.id);
      const minutes = step.minutes;
      return `<div class="lesson-time-step ${complete ? 'is-complete' : ''}" data-step="${step.id}" data-step-number="${String(index + 1).padStart(2, '0')}">
        <span class="lesson-time-index">${complete ? '✓' : String(index + 1).padStart(2, '0')}</span>
        <div class="lesson-time-step-copy"><strong>${escapeHtml(step.title)}</strong><p>${escapeHtml(step.detail)}</p><span data-step-status class="lesson-step-status">${complete ? 'Completed' : 'Not started'}</span></div>
        <span class="lesson-time-minutes">${minutes} min</span>
        <button type="button" class="lesson-step-start" data-study-jump="${step.id}">${complete ? 'Review activity ↗' : 'Start activity →'}</button>
      </div>`;
    }).join('');
    refreshStudyActivityUI();
  }

  function completeStudyActivity(id) {
    if (!activeStudyState || !STUDY_ACTIVITY_IDS.includes(id)) return;
    activeStudyState.completed[id] = true;
    persistStudyState();
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function renderWorkedExampleWalkthrough() {
    const output = $('#workedExampleWalkthrough');
    if (!output) return;
    const revealed = activeStudyState?.workedExampleStep || 0;
    output.innerHTML = activeWorkedExampleSteps.slice(0, revealed).map((step, index) =>
      `<article class="worked-solution-step"><span>${index + 1}</span><div><strong>${escapeHtml(step.title)}</strong><p>${escapeHtml(step.body)}</p></div></article>`
    ).join('');
    const next = $('#nextWorkedExampleStepButton');
    if (next) {
      next.classList.toggle('hidden', revealed === 0 || revealed >= activeWorkedExampleSteps.length);
      next.textContent = revealed >= activeWorkedExampleSteps.length - 1 ? 'Finish walkthrough ✓' : 'Reveal next step →';
    }
  }

  function showSavedActivityFeedback() {
    if (!activeStudyState) return;
    const c = activeStudyState.completed;
    if (c.preview) $('#previewFeedback').textContent = 'First thoughts saved. Compare them with what you can explain after the lesson.';
    if (c.coreIdeas) {
      $('#coreIdeaFeedback').textContent = 'Explanation reviewed. Compare the model explanation below with your own words.';
      renderCoreIdeaModel();
    }
    if (c.workedExample) $('#workedExampleFeedback').textContent = 'Walkthrough complete. Try to explain why each step follows from the previous one.';
    if (c.handsOn) $('#handsOnFeedback').textContent = 'Practice saved. Revisit any step where your reasoning feels uncertain.';
    if (c.recall) $('#recallFeedback').textContent = 'Recall completed. Compare your response with the key ideas below.';
    if (c.knowledgeCheck) $('#lessonQuizFeedback').textContent = 'Knowledge check previously passed. You can answer again to review your understanding.';
    const model = $('#recallModel');
    if (c.recall && model && activeLessonContext?.lesson) {
      model.classList.remove('hidden');
      model.innerHTML = `<strong>Compare with these key ideas</strong><ul>${activeLessonContext.lesson.takeaways.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`;
      $('#lessonSlideDeck').classList.remove('recall-hidden');
      $('#toggleRecallNotesButton').textContent = 'Hide lecture slides for recall';
    }
  }
  let activeLessonContext = null;

  const FINAL_ASSESSMENT = [
    { id: 'f1', question: 'Which transport protocol provides a reliable, ordered byte stream?', options: ['UDP', 'TCP', 'DNS', 'IP'], answer: 1, explanation: 'TCP provides reliable, ordered byte-stream delivery while the connection is functioning.' },
    { id: 'f2', question: 'What is DNS commonly used to look up?', options: ['The process owner of a local file', 'The encryption key for HTTPS', 'Records associated with a domain name, often including IP addresses', 'The firewall rules on a router'], answer: 2, explanation: 'DNS resolves names to records, commonly IP addresses. It does not manage local files, keys, or firewall policy.' },
    { id: 'f3', question: 'What does least privilege mean?', options: ['Give every user administrator access', 'Grant only the access needed for a task', 'Disable access logs', 'Allow every network port'], answer: 1, explanation: 'Least privilege reduces unnecessary access by granting only what is needed.' },
    { id: 'f4', question: 'Which security goal focuses on preventing unauthorized disclosure?', options: ['Confidentiality', 'Availability', 'Routing', 'Compression'], answer: 0, explanation: 'Confidentiality protects information from unauthorized disclosure.' },
    { id: 'f5', question: 'What is the main purpose of a cryptographic hash?', options: ['Route a packet to another network', 'Reverse ciphertext into readable text', 'Create a digest useful for integrity checks', 'Guarantee a website is safe'], answer: 2, explanation: 'A cryptographic hash produces a digest that can help check data integrity; it is not reversible encryption.' },
    { id: 'f6', question: 'What does a Wireshark display filter do?', options: ['Automatically block suspicious traffic', 'Limit which captured packets are displayed', 'Encrypt network packets', 'Confirm every displayed packet is safe'], answer: 1, explanation: 'A display filter narrows the packet list shown to the analyst. It does not block, encrypt, or certify traffic.' },
    { id: 'f7', question: 'A security alert appears for an unfamiliar login. What is a good next step?', options: ['Delete the logs immediately', 'Assume the account is definitely compromised', 'Ignore the alert', 'Review related events and supporting evidence'], answer: 3, explanation: 'An alert should be investigated in context. Related events and evidence help determine whether an incident occurred.' },
    { id: 'f8', question: 'Why are incident notes and evidence preservation important?', options: ['They help reconstruct events and support investigation', 'They replace technical investigation', 'They prove every alert is malicious', 'They allow responders to skip recovery checks'], answer: 0, explanation: 'Accurate notes and preserved evidence support timelines, analysis, and clear decisions.' }
  ];
  let activeFinalAssessmentQuestions = [...FINAL_ASSESSMENT];

  function selectFinalAssessmentQuestions() {
    const tasks = getAllTasks();
    const fromSyllabus = tasks.map(task => (task.custom_lesson?.quizQuestions || []).map(question => ({
      question: question.question,
      options: question.options,
      answer: question.answer,
      explanation: question.explanation
    }))).filter(group => group.length);
    if (!fromSyllabus.length) return [...FINAL_ASSESSMENT];
    const selected = [];
    const seen = new Set();
    // Take one question from each module first, so the final test samples the whole syllabus.
    for (let round = 0; round < 8; round += 1) {
      for (const group of fromSyllabus) {
        const question = group[round];
        if (!question) continue;
        const key = String(question.question || '').toLowerCase();
        if (!key || seen.has(key)) continue;
        seen.add(key);
        selected.push({ ...question, id: `syllabus-final-${selected.length + 1}` });
        if (selected.length >= 8) return selected;
      }
    }
    return selected.length >= 4 ? selected : [...FINAL_ASSESSMENT];
  }

  let currentRoadmap = null;
  let currentCourseId = null;
  let currentUsername = null;
  let progressSaveChain = Promise.resolve();
  let progressKey = '';
  let completedTasks = {};
  let quizScored = false;
  let activeTaskId = null;
  let lessonAnswerCorrect = false;
  let activeLessonCheckQuestions = [];
  let activeLessonSlides = [];
  let activeSlideIndex = 0;
  let activeSpeechChunks = [];
  let activeSpeechChunkIndex = 0;
  let activeSpeechUtterance = null;
  let speechPlaybackState = 'idle';
  let speechSessionId = 0;
  let speechVoices = [];
  let activeNarratorVoice = null;
  let finalAssessmentResult = null;
  let finalAssessmentScored = false;
  let toastTimer = null;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }

  function formatHours(value) {
    const n = Number(value || 0);
    return `${Number.isInteger(n) ? n : n.toFixed(1)} ${n === 1 ? 'hour' : 'hours'}`;
  }

  function prettyDate(iso) {
    if (!iso) return 'Not set';
    const date = new Date(`${iso}T12:00:00`);
    if (Number.isNaN(date.getTime())) return iso;
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  }

  function showToast(message) {
    const el = $('#toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
  }

  function setDefaultDate() {
    const date = new Date();
    date.setDate(date.getDate() + 28);
    const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    $('#startDate').value = localDate;
    $('#startDate').min = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  }

  function useSampleSyllabus() {
    $('#courseTitle').value = 'Introduction to Network Security';
    $('#syllabusText').value = SAMPLE_SYLLABUS;
    if (!$('#startDate').value) setDefaultDate();
    $('#hoursPerWeek').value = '4';
    $('#hoursValue').textContent = '4';
    ['computer', 'linux', 'networking', 'programming', 'web', 'security'].forEach(key => { const field = $(`#skill${key[0].toUpperCase()}${key.slice(1)}`); if (field) field.value = 'new'; });
    updateRelevantSkillFields();
    $('#uploadStatus').textContent = 'Sample syllabus loaded. You can edit it before generating your plan.';
    $('#formError').classList.add('hidden');
    showToast('Sample syllabus loaded. Generate your roadmap when ready.');
  }

  const SKILL_MATCH_RULES = {
    computer: /operating system|computer basics|file system|process|computer literacy/i,
    linux: /linux|bash|shell|command line|terminal|grep|permissions|ssh/i,
    networking: /network|tcp|udp|ip address|subnet|dns|packet|firewall|wireshark|port|routing|protocol/i,
    programming: /programming|python|java|javascript|c language|scripting|algorithm|variables|functions|loops/i,
    web: /http|https|web application|web security|browser|web server|tls|sql injection|cross.site scripting/i,
    security: /cybersecurity|network security|threat|vulnerability|cryptograph|encryption|firewall|incident|siem|malware|confidentiality|integrity|availability|ctf|ethical hacking/i
  };
  const GOAL_SKILLS = {
    network_security: ['networking', 'security', 'web'],
    ethical_hacking: ['linux', 'networking', 'web', 'security'],
    soc_analyst: ['networking', 'linux', 'security'],
    cybersecurity_foundations: ['computer', 'linux', 'networking', 'security']
  };
  function updateRelevantSkillFields() {
    const syllabus = $('#syllabusText').value || '';
    const relevant = new Set();
    Object.entries(SKILL_MATCH_RULES).forEach(([skill, pattern]) => { if (pattern.test(syllabus)) relevant.add(skill); });
    if (relevant.size === 0) ['computer', 'networking', 'security'].forEach(skill => relevant.add(skill));
    document.querySelectorAll('[data-skill-field]').forEach(field => {
      const visible = relevant.has(field.dataset.skillField);
      field.classList.toggle('hidden', !visible);
      const select = $('select', field);
      if (select && !visible) select.value = 'new';
    });
    const helper = $('#skillsHelp');
    if (helper) helper.textContent = syllabus.trim().length >= 25
      ? 'Shown skills are matched from words and topics in your syllabus. These are estimates; check the labels before generating.'
      : 'Add your syllabus to show the most relevant starting skills.';
  }

  function formPayload() {
    return {
      course_title: $('#courseTitle').value.trim(),
      goal: 'custom',
      syllabus_text: $('#syllabusText').value.trim(),
      start_date: $('#startDate').value,
      hours_per_week: Number($('#hoursPerWeek').value),
      skills: {
        computer: $('#skillComputer').value,
        linux: $('#skillLinux').value,
        networking: $('#skillNetworking').value,
        programming: $('#skillProgramming').value,
        web: $('#skillWeb').value,
        security: $('#skillSecurity').value
      },
      use_ai: Boolean($('#useAi')?.checked)
    };
  }

  async function checkHealth() {
    try {
      const response = await fetch('/api/health');
      const data = await response.json();
      if (data.ai_available) {
        $('#aiOptionWrap').classList.remove('hidden');
        if ($('#useAi')) $('#useAi').checked = true;
        $('#aiGenerationHint').textContent = `Gemini API is configured (${data.ai_model}). AheadPath will build syllabus-specific modules, detailed explanations, worked examples, case studies, and assessments in the cloud. Free-tier quotas apply.`;
        $('#modeBadge').innerHTML = '<span class="status-dot"></span> Gemini API ready';
      } else if (data.ai_course_generation) {
        $('#aiOptionWrap').classList.remove('hidden');
        if ($('#useAi')) $('#useAi').checked = true;
        $('#aiGenerationHint').textContent = data.ai_message || 'Gemini API setup needs attention. Check the API key and SDK installation.';
        $('#modeBadge').innerHTML = '<span class="status-dot"></span> Gemini setup needed';
      } else {
        $('#aiGenerationHint').textContent = 'Full syllabus-specific generation is disabled. Add a Gemini API key to GEMINI_API_KEY in your server .env file.';
        $('#modeBadge').innerHTML = '<span class="status-dot"></span> Gemini API not configured';
      }
    } catch (_err) {
      $('#modeBadge').innerHTML = '<span class="status-dot"></span> Local app';
    }
  }

  async function uploadSyllabus(file) {
    if (!file) return;
    $('#uploadStatus').textContent = `Reading ${file.name}…`;
    $('#formError').classList.add('hidden');
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await fetch('/api/extract', { method: 'POST', body: formData });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Unable to read this file.');
      $('#syllabusText').value = data.text;
      updateRelevantSkillFields();
      $('#uploadStatus').textContent = `Loaded ${data.filename} · ${data.characters.toLocaleString()} characters extracted.`;
      showToast('Syllabus text extracted successfully.');
    } catch (error) {
      $('#uploadStatus').textContent = '';
      showFormError(error.message || 'Unable to read this file.');
    } finally {
      $('#syllabusFile').value = '';
    }
  }

  function showFormError(message) {
    const el = $('#formError');
    el.textContent = message;
    el.classList.remove('hidden');
  }

  function makeProgressKey(plan) {
    // Keep progress separate when a student builds a different course with the same title.
    const source = [plan.course_title, plan.goal, plan.start_date, plan.weeks_count, plan.hours_per_week, $('#syllabusText').value.trim(), $('#skillLinux').value, $('#skillNetworking').value, $('#skillProgramming').value, $('#skillWeb').value].join('|');
    let hash = 2166136261;
    for (let index = 0; index < source.length; index += 1) {
      hash ^= source.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    const course = (plan.course_title || 'course').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 45);
    return `aheadpath-progress:${course}:${plan.start_date}:${(hash >>> 0).toString(16)}`;
  }

  function loadProgress(plan, progress = {}) {
    currentCourseId = plan.course_id || currentCourseId;
    completedTasks = progress && progress.completed_tasks && typeof progress.completed_tasks === 'object'
      ? progress.completed_tasks : {};
    finalAssessmentResult = progress && progress.final_assessment && typeof progress.final_assessment === 'object'
      ? progress.final_assessment : null;
    finalAssessmentScored = Boolean(finalAssessmentResult && finalAssessmentResult.scored);
  }

  function saveProgress() {
    if (!currentCourseId) return Promise.resolve();
    const snapshot = {
      completed_tasks: { ...completedTasks },
      final_assessment: finalAssessmentResult ? JSON.parse(JSON.stringify(finalAssessmentResult)) : null
    };
    // Keep writes ordered so a slower earlier request cannot overwrite newer progress.
    progressSaveChain = progressSaveChain.catch(() => {}).then(async () => {
      const response = await fetch(`/api/courses/${encodeURIComponent(currentCourseId)}/progress`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(snapshot)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not save your progress.');
      await refreshSavedCourses(false);
      return data;
    }).catch(error => {
      console.error('AheadPath progress sync failed:', error);
      showToast('Progress could not sync. Check your connection and try again.');
    });
    return progressSaveChain;
  }

  async function generateRoadmap(event) {
    if (event) event.preventDefault();
    const payload = formPayload();
    if (!payload.syllabus_text || payload.syllabus_text.length < 25) {
      showFormError('Add at least a short course outline, or click “Try a sample syllabus” to see how AheadPath works.');
      $('#syllabusText').focus();
      return;
    }
    if (!payload.start_date) {
      showFormError('Choose the date your semester starts.');
      $('#startDate').focus();
      return;
    }
    const button = $('#generateButton');
    const oldContent = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span class="loading-spinner"></span> Building your plan…';
    $('#formError').classList.add('hidden');
    try {
      const response = await fetch('/api/generate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not generate your course.');
      currentCourseId = data.course_id;
      currentRoadmap = data.plan;
      loadProgress(currentRoadmap, data.progress);
      renderRoadmap(currentRoadmap);
      $('#resultsSection').classList.remove('hidden');
      await refreshSavedCourses(false);
      $('#resultsSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
      showToast('Course saved to My courses.');
      return true;
    } catch (error) {
      showFormError(error.message || 'Could not generate your roadmap. Check that the server is running.');
      return false;
    } finally {
      button.disabled = false;
      button.innerHTML = oldContent;
    }
  }

  function renderMetrics(plan) {
    const metrics = [
      { label: 'Time until class', value: `${plan.weeks_count} ${plan.weeks_count === 1 ? 'week' : 'weeks'}`, detail: `Semester starts ${prettyDate(plan.start_date)}`, icon: '◷', color: 'purple' },
      { label: 'Study rhythm', value: `${plan.hours_per_week} hrs`, detail: 'Your weekly learning budget', icon: '◴', color: 'blue' },
      { label: 'Time planned', value: `${plan.planned_hours} hrs`, detail: `Of ${plan.total_budget_hours} hours available`, icon: '↗', color: 'green' },
      { label: 'Topics in plan', value: `${plan.planned_topic_count}`, detail: `${plan.remaining_topic_count} reserved for later`, icon: '◇', color: 'amber' }
    ];
    $('#metricsGrid').innerHTML = metrics.map(metric => `
      <div class="metric-card"><div class="metric-top"><span>${escapeHtml(metric.label)}</span><span class="metric-icon ${metric.color}">${metric.icon}</span></div><strong>${escapeHtml(metric.value)}</strong><small>${escapeHtml(metric.detail)}</small></div>
    `).join('');
  }

  function renderTopics(plan) {
    const host = $('#detectedTopics');
    const topics = plan.detected_topics || [];
    host.innerHTML = topics.length ? topics.map(topic => `<span class="topic-chip" title="Keyword score: ${Number(topic.score || 0)}">${escapeHtml(topic.title)}</span>`).join('') : '<span class="topic-chip secondary">No clear topic keywords found</span>';
    const outcomes = plan.learning_outcomes || [];
    $('#outcomesWrap').classList.toggle('hidden', outcomes.length === 0);
    $('#outcomesList').innerHTML = outcomes.map(outcome => `<li>${escapeHtml(outcome)}</li>`).join('');
  }

  function renderWarnings(plan) {
    const warnings = plan.uncertainties || [];
    const el = $('#uncertaintyBox');
    if (!warnings.length) { el.classList.add('hidden'); el.innerHTML = ''; return; }
    el.classList.remove('hidden');
    el.innerHTML = `<strong>Review these notes before relying on the plan</strong><ul>${warnings.map(w => `<li>${escapeHtml(w)}</li>`).join('')}</ul>`;
  }

  function renderWeeks(plan) {
    const weeks = plan.weeks || [];
    const taskCount = weeks.reduce((sum, week) => sum + (week.tasks || []).length, 0);
    $('#weeksContainer').innerHTML = weeks.map(week => {
      const tasksHtml = week.tasks.length ? week.tasks.map(task => {
        const checked = Boolean(completedTasks[task.task_id]);
        const detailId = `details-${task.task_id}`;
        const objectiveChips = (task.objectives || []).slice(0, 2).map(objective => `<span class="objective-chip">${escapeHtml(objective)}</span>`).join('');
        const compressedTag = task.compressed ? '<span class="task-level">Short intro</span>' : '';
        const statusMark = checked ? '✓' : '▶';
        return `<article class="task-row ${checked ? 'completed' : ''}" data-task-row="${escapeHtml(task.task_id)}">
          <span class="task-status-icon ${checked ? 'is-complete' : ''}" aria-hidden="true">${statusMark}</span>
          <div class="task-body"><div class="task-meta"><span class="task-category">${escapeHtml(task.category)}</span><span class="task-level">${escapeHtml(task.level)}</span>${compressedTag}</div><div class="task-title">${escapeHtml(task.title)}</div><div class="task-description">${escapeHtml(task.description)}</div><div class="task-objectives">${objectiveChips}</div></div>
          <div class="task-side"><span class="task-duration">${formatHours(task.hours)}</span><button type="button" class="lesson-start-button ${checked ? 'is-review' : ''}" data-open-lesson="${escapeHtml(task.task_id)}">${checked ? 'Review lesson' : 'Start lesson'} <span aria-hidden="true">→</span></button><button type="button" class="task-expand" aria-expanded="false" aria-controls="${detailId}" data-detail-toggle="${detailId}">Details</button></div>
          <div class="task-detail hidden" id="${detailId}"><p><strong>Why:</strong> ${escapeHtml(task.why)}</p><p class="practice-text"><strong>Practice:</strong> ${escapeHtml(task.practice)}</p><a class="resource-link" href="${escapeHtml(task.resource_url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(task.resource_title)} ↗</a></div>
        </article>`;
      }).join('') : '<p class="empty-week">No lessons this week. Increase study time or move the semester date.</p>';
      const weekTitle = week.number === 1 ? 'Start here' : week.number === weeks.length ? 'Review and apply' : 'Build your skills';
      return `<section class="week-card"><header class="week-card-header"><div><span class="week-kicker">WEEK ${week.number}</span><h4>${weekTitle}</h4></div><span class="week-hours"><strong>${week.hours}h</strong> / ${plan.hours_per_week}h</span></header><div class="week-tasks">${tasksHtml}</div></section>`;
    }).join('');
    $('#courseTaskCount').textContent = `${taskCount} lessons`;
  }

  function renderPostponed(plan) {
    const list = plan.postponed_topics || [];
    $('#postponedSection').classList.toggle('hidden', list.length === 0);
    $('#postponedList').innerHTML = list.map(topic => `<div class="postponed-card"><strong>${escapeHtml(topic.title)}</strong><p>${escapeHtml(topic.description)}</p><a href="${escapeHtml(topic.resource_url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(topic.resource_title)} ↗</a></div>`).join('');
  }

  function renderRoadmap(plan) {
    $('#resultTitle').textContent = plan.course_title;
    $('#resultSubtitle').textContent = `${plan.goal_label} · ${plan.weeks_count} weeks · ${plan.planned_topic_count} syllabus modules · Open a lesson to begin.`;
    $('#analysisMode').textContent = plan.source_mode;
    $('#courseSummary').textContent = plan.course_overview
      ? `${plan.summary}\n\n${plan.course_overview}` : plan.summary;
    $('#reviewBadge').textContent = plan.course_content_mode === 'ai_generated_lecture'
      ? 'Full syllabus-based lectures' : 'Review coverage before studying';
    const coverage = plan.syllabus_coverage || [];
    $('#syllabusCoverageWrap').classList.toggle('hidden', coverage.length === 0);
    $('#syllabusCoverageList').innerHTML = coverage.map(item => `<li>${escapeHtml(item.syllabus_item)} <span aria-hidden="true">→</span> <strong>${escapeHtml(item.module_title)}</strong>${item.matched ? '' : ' <em>Review mapping</em>'}</li>`).join('');
    renderMetrics(plan);
    renderWarnings(plan);
    renderTopics(plan);
    renderWeeks(plan);
    renderPostponed(plan);
    renderQuiz();
    renderFinalAssessment();
    $('#learningPlayer').classList.add('hidden');
    activeTaskId = null;
    updateProgressUI();
    $('#readinessSection').classList.add('hidden');
  }

  function getAllTasks() {
    if (!currentRoadmap) return [];
    return (currentRoadmap.weeks || []).flatMap(week => (week.tasks || []).map(task => ({ ...task, weekNumber: week.number })));
  }

  function updateProgressUI() {
    if (!currentRoadmap) return;
    const allTasks = getAllTasks();
    const doneCount = allTasks.filter(task => Boolean(completedTasks[task.task_id])).length;
    const totalCount = allTasks.length;
    const percent = totalCount ? Math.round(doneCount / totalCount * 100) : 0;
    $('#progressPercent').textContent = `${percent}%`;
    $('#overallProgressBar').style.width = `${percent}%`;
    $('#completionCount').textContent = `${doneCount}/${totalCount}`;
    $('#completionRing').style.background = `conic-gradient(var(--purple) ${percent * 3.6}deg, #eeeefa 0deg)`;
    $('#completionHeading').textContent = totalCount && doneCount === totalCount ? 'All lessons complete' : 'Course progress';
    $('#completionText').textContent = doneCount === 0 ? 'Start the first lesson to begin.' : doneCount === totalCount ? 'You have finished every lesson. The final test is ready.' : `${doneCount} of ${totalCount} lessons complete.`;
    $$('[data-task-row]').forEach(row => {
      const id = row.getAttribute('data-task-row');
      const isDone = Boolean(completedTasks[id]);
      row.classList.toggle('completed', isDone);
      const statusIcon = $('.task-status-icon', row);
      if (statusIcon) {
        statusIcon.textContent = isDone ? '✓' : '▶';
        statusIcon.classList.toggle('is-complete', isDone);
      }
      const startButton = $('[data-open-lesson]', row);
      if (startButton) {
        startButton.textContent = isDone ? 'Review lesson →' : 'Start lesson →';
        startButton.classList.toggle('is-review', isDone);
      }
    });
    const allComplete = totalCount > 0 && doneCount === totalCount;
    $('#launchFinalAssessmentButton').disabled = !allComplete;
    $('#finalTestStatus').textContent = !allComplete
      ? `Complete ${totalCount - doneCount} more lesson${totalCount - doneCount === 1 ? '' : 's'} to unlock the final test.`
      : finalAssessmentResult && finalAssessmentResult.passed
        ? `Passed with ${finalAssessmentResult.score}/${activeFinalAssessmentQuestions.length}. You can review your answers.`
        : finalAssessmentResult
          ? `Score: ${finalAssessmentResult.score}/${activeFinalAssessmentQuestions.length}. Review and try again.`
          : 'All lessons complete. Take the test to check what you learned.';
    $('#launchFinalAssessmentButton').textContent = finalAssessmentResult ? 'Review results' : 'Start test';
    if (activeTaskId) updateCoursePlayerProgress();
  }

  function findTask(taskId) {
    return getAllTasks().find(task => task.task_id === taskId) || null;
  }

  
  function renderLectureParagraphs(value) {
    return String(value || '').split(/\n\s*\n/).map(part => part.trim()).filter(Boolean)
      .map(part => `<p>${escapeHtml(part).replace(/\n/g, '<br>')}</p>`).join('');
  }

  function lessonForTask(task) {
    // Older saved courses or partially generated lessons may not include every lesson field.
    // Always provide a real written mini-lecture so audio never becomes the only way to learn.
    const objectives = Array.isArray(task.objectives)
      ? task.objectives.filter(Boolean)
      : (task.objectives ? [String(task.objectives)] : []);
    const fallback = {
      title: task.title || 'Course lesson',
      intro: task.description || `In this lesson, you will learn the core idea behind ${task.title || 'this topic'}, why it matters, and how to apply it. Read each section, then test your understanding with the activity and quick check.`,
      sections: [
        { heading: 'Understand the concept', body: task.description || `Start by defining ${task.title || 'the topic'} in your own words. Identify the key terms, the problem this concept solves, and how it connects to earlier topics in the syllabus.` },
        { heading: 'Why it matters', body: task.why || `This topic gives you a foundation for the course. Understanding it helps you explain later concepts instead of memorizing isolated terms.` },
        { heading: 'Apply the idea', body: task.practice || `Create a small, realistic example of ${task.title || 'this topic'}. Explain each step and how you would check whether your result is correct.` },
        ...(objectives.length ? [{ heading: 'Connect to the course outcomes', body: objectives.join(' ' ) }] : [])
      ],
      takeaways: objectives.length ? objectives : [
        `Explain ${task.title || 'the topic'} in your own words.`,
        'Give one practical example and explain why it fits.',
        'Check your understanding before moving to a harder topic.'
      ],
      quiz: {
        question: `Which approach best shows that you understand ${task.title || 'this topic'}?`,
        options: ['Memorize the heading only', 'Explain the concept, give an example, and check the result', 'Skip the example and practice', 'Move to an advanced topic without reviewing'],
        answer: 1,
        explanation: 'Understanding means you can explain the idea, apply it to an example, and check whether your reasoning makes sense.'
      }
    };
    const provided = task.custom_lesson || LESSONS[task.module_id] || {};
    const merged = { ...fallback, ...provided };
    merged.title = String(merged.title || fallback.title);
    merged.intro = String(merged.intro || fallback.intro);
    merged.sections = Array.isArray(merged.sections) && merged.sections.length
      ? merged.sections.filter(section => section && (section.heading || section.body)).map(section => ({
          heading: String(section.heading || 'Lesson concept'),
          body: String(section.body || 'Review the concept, connect it to the syllabus, and try the practical activity below.')
        }))
      : fallback.sections;
    merged.takeaways = Array.isArray(merged.takeaways) && merged.takeaways.length
      ? merged.takeaways.map(point => String(point))
      : fallback.takeaways;
    merged.key_terms = Array.isArray(merged.key_terms) ? merged.key_terms.filter(item => item && item.term && item.definition) : [];
    merged.common_misconceptions = Array.isArray(merged.common_misconceptions) ? merged.common_misconceptions.map(String) : [];
    merged.worked_example = merged.worked_example && typeof merged.worked_example === 'object' ? merged.worked_example : {};
    merged.case_study = merged.case_study && typeof merged.case_study === 'object' ? merged.case_study : {};
    merged.quizQuestions = Array.isArray(merged.quizQuestions) ? merged.quizQuestions : [];
    merged.source_topics = Array.isArray(task.source_topics) ? task.source_topics : [];
    const quiz = { ...fallback.quiz, ...(merged.quiz || {}) };
    if (!Array.isArray(quiz.options) || quiz.options.length < 2) quiz.options = fallback.quiz.options;
    if (!Number.isInteger(quiz.answer) || quiz.answer < 0 || quiz.answer >= quiz.options.length) quiz.answer = fallback.quiz.answer;
    merged.quiz = quiz;
    return merged;
  }

  function getLessonCheckQuestions(task, lesson) {
    const topicQuestions = LESSON_CHECK_BANK[task.module_id] || LESSON_CHECK_BANK.readiness_review;
    const candidates = [
      lesson.quiz,
      ...(Array.isArray(lesson.quizQuestions) ? lesson.quizQuestions : []),
      ...topicQuestions
    ];
    const used = new Set();
    const questions = [];
    for (const item of candidates) {
      if (!item || !item.question || !Array.isArray(item.options) || item.options.length < 2) continue;
      const questionText = String(item.question).trim();
      const key = questionText.toLocaleLowerCase();
      if (!questionText || used.has(key)) continue;
      const options = item.options.map(option => String(option));
      const answer = Number(item.answer);
      if (!Number.isInteger(answer) || answer < 0 || answer >= options.length) continue;
      used.add(key);
      questions.push({
        id: `lesson-check-${questions.length + 1}`,
        question: questionText,
        options,
        answer,
        explanation: String(item.explanation || 'Review the lesson explanation and try applying the concept to a practical example.')
      });
      if (questions.length >= 4) break;
    }
    while (questions.length < 4) {
      questions.push({
        id: `lesson-check-${questions.length + 1}`,
        question: `Which approach best shows that you understand ${task.title || 'this topic'}?`,
        options: ['Memorize the heading only', 'Explain the concept, give an example, and check the result', 'Skip the example and practice', 'Move to an advanced topic without reviewing'],
        answer: 1,
        explanation: 'Understanding means you can explain an idea, apply it to an example, and check whether your reasoning makes sense.'
      });
    }
    return questions.slice(0, 5);
  }

  function clearAudioHighlights() {
    $$('#learningPlayer .is-speaking').forEach(element => element.classList.remove('is-speaking'));
  }

  function updateAudioButtons() {
    const playBtn = $('#playAudioBtn');
    const pauseBtn = $('#pauseAudioBtn');
    if (!playBtn || !pauseBtn) return;
    const supported = 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
    playBtn.disabled = !supported;
    pauseBtn.disabled = !supported || speechPlaybackState !== 'playing';
    playBtn.textContent = speechPlaybackState === 'playing' ? '🔊 Narrating slides…'
      : speechPlaybackState === 'paused' ? '▶ Resume slides'
        : speechPlaybackState === 'finished' ? '🔊 Replay slides' : '🔊 Listen to slides';
  }

  function resetAudioPlayer() {
    speechSessionId += 1;
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    speechPlaybackState = 'idle';
    activeSpeechChunks = [];
    activeSpeechChunkIndex = 0;
    activeSpeechUtterance = null;
    activeNarratorVoice = null;
    clearAudioHighlights();
    updateAudioButtons();
  }

  function populateSpeechVoicePicker() {
    const select = $('#voiceSelect');
    if (!select || !('speechSynthesis' in window)) return;
    const prior = select.value || 'auto';
    speechVoices = window.speechSynthesis.getVoices();
    const englishVoices = speechVoices.filter(voice => /^en(?:-|$)/i.test(voice.lang || ''));
    const listedVoices = englishVoices.length ? englishVoices : speechVoices;
    select.innerHTML = '<option value="auto">Best available English voice</option>' + listedVoices.map(voice =>
      `<option value="${escapeHtml(voice.voiceURI)}">${escapeHtml(voice.name)} (${escapeHtml(voice.lang || 'voice')})</option>`
    ).join('');
    let saved = prior;
    try { saved = localStorage.getItem('aheadpath-narrator-voice') || prior; } catch (_) { /* Storage can be disabled by the browser. */ }
    select.value = [...select.options].some(option => option.value === saved) ? saved : 'auto';
  }

  function chooseNarratorVoice() {
    if ('speechSynthesis' in window) speechVoices = window.speechSynthesis.getVoices() || speechVoices;
    const select = $('#voiceSelect');
    const selectedURI = select?.value || 'auto';
    if (selectedURI !== 'auto') {
      const chosen = speechVoices.find(voice => voice.voiceURI === selectedURI);
      if (chosen) return chosen;
    }
    const englishVoices = speechVoices.filter(voice => /^en(?:-|$)/i.test(voice.lang || ''));
    const candidates = englishVoices.length ? englishVoices : speechVoices;
    const scoreVoice = voice => {
      const name = `${voice.name || ''} ${voice.voiceURI || ''}`.toLowerCase();
      let score = 0;
      if (/natural|neural|enhanced|premium|online/.test(name)) score += 8;
      if (/aria|jenny|samantha|ava|zira|joanna|salli|serena|emma|olivia|michelle|allison|karen|moira/.test(name)) score += 4;
      if (/google us english|microsoft/.test(name)) score += 2;
      if (/robot|compact|eSpeak|festival/.test(name)) score -= 5;
      if (/^en-us$/i.test(voice.lang || '')) score += 2;
      return score;
    };
    return [...candidates].sort((a, b) => scoreVoice(b) - scoreVoice(a))[0] || null;
  }

  function getSpeechChunks() {
    return activeLessonSlides.map((slide, index) => ({
      element: $('#lectureSlideCanvas'),
      text: [slide.title, slide.lead, ...(slide.points || []).flatMap(point => [point.title, point.text]), slide.callout?.label, slide.callout?.text]
        .filter(Boolean).join('. ').replace(/\s+/g, ' ').trim(),
      label: `Slide ${index + 1}: ${slide.title}`,
      onStart: () => renderLectureSlide(index, { fromSpeech: true })
    })).filter(chunk => chunk.text);
  }

  function speakNextChunk() {
    if (speechPlaybackState !== 'playing') return;
    if (activeSpeechChunkIndex >= activeSpeechChunks.length) {
      speechPlaybackState = 'finished';
      activeSpeechUtterance = null;
      clearAudioHighlights();
      updateAudioButtons();
      const status = $('#audioStatus');
      if (status) status.textContent = 'Slide narration finished. Review the deck, download it, or listen again.';
      return;
    }
    const session = speechSessionId;
    const chunk = activeSpeechChunks[activeSpeechChunkIndex];
    const utterance = new SpeechSynthesisUtterance(chunk.text);
    activeSpeechUtterance = utterance;
    const voice = activeNarratorVoice || chooseNarratorVoice();
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang || 'en-US';
    } else {
      utterance.lang = 'en-US';
    }
    // A little more conversational than the default system voice, while remaining easy to follow.
    utterance.rate = 1.04;
    utterance.pitch = 1.08;
    utterance.volume = 1;
    utterance.onstart = () => {
      if (session !== speechSessionId) return;
      clearAudioHighlights();
      if (typeof chunk.onStart === 'function') chunk.onStart();
      if (chunk.element?.classList) chunk.element.classList.add('is-speaking');
      updateAudioButtons();
      const status = $('#audioStatus');
      if (status) status.textContent = `Listening: ${chunk.label}. Use Pause to stop here and Resume to continue from this point.`;
    };
    utterance.onend = () => {
      if (session !== speechSessionId) return;
      if (chunk.element?.classList) chunk.element.classList.remove('is-speaking');
      activeSpeechChunkIndex += 1;
      if (speechPlaybackState === 'paused') return;
      speakNextChunk();
    };
    utterance.onerror = event => {
      if (session !== speechSessionId || event.error === 'canceled' || event.error === 'interrupted') return;
      speechPlaybackState = 'idle';
      activeSpeechUtterance = null;
      clearAudioHighlights();
      updateAudioButtons();
      const status = $('#audioStatus');
      if (status) status.textContent = 'Audio could not continue in this browser. Your lecture slides remain available above.';
    };
    window.speechSynthesis.speak(utterance);
  }

  function startLessonAudio() {
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) {
      const status = $('#audioStatus');
      if (status) status.textContent = 'Audio is not supported in this browser. Use the lecture slide deck above.';
      return;
    }
    if (speechPlaybackState === 'paused') {
      speechPlaybackState = 'playing';
      window.speechSynthesis.resume();
      updateAudioButtons();
      const status = $('#audioStatus');
      if (status) status.textContent = 'Resuming narration from the current slide.';
      return;
    }
    if (speechPlaybackState === 'playing') {
      if (window.speechSynthesis.paused) window.speechSynthesis.resume();
      return;
    }
    if (!activeSpeechChunks.length || speechPlaybackState === 'finished' || speechPlaybackState === 'idle') {
      const wasFinished = speechPlaybackState === 'finished';
      activeSpeechChunks = getSpeechChunks();
      activeSpeechChunkIndex = wasFinished ? 0 : activeSlideIndex;
    }
    if (!activeSpeechChunks.length) return;
    activeNarratorVoice = chooseNarratorVoice();
    speechPlaybackState = 'playing';
    speakNextChunk();
    updateAudioButtons();
  }

  function pauseLessonAudio() {
    if (!('speechSynthesis' in window) || speechPlaybackState !== 'playing') return;
    window.speechSynthesis.pause();
    speechPlaybackState = 'paused';
    updateAudioButtons();
    const status = $('#audioStatus');
    if (status) status.textContent = 'Narration paused. Press Resume to continue this slide, or Start over to replay the deck.';
  }

  function restartLessonAudio() {
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) return;
    resetAudioPlayer();
    activeSpeechChunks = getSpeechChunks();
    activeSpeechChunkIndex = 0;
    if (!activeSpeechChunks.length) return;
    activeNarratorVoice = chooseNarratorVoice();
    speechPlaybackState = 'playing';
    const status = $('#audioStatus');
    if (status) status.textContent = 'Restarting narration from slide one.';
    updateAudioButtons();
    speakNextChunk();
  }

  function initializeSpeechVoicePicker() {
    if (!('speechSynthesis' in window)) {
      const select = $('#voiceSelect');
      if (select) { select.disabled = true; select.innerHTML = '<option>Audio unavailable</option>'; }
      return;
    }
    populateSpeechVoicePicker();
    if (typeof window.speechSynthesis.addEventListener === 'function') {
      window.speechSynthesis.addEventListener('voiceschanged', populateSpeechVoicePicker);
    } else {
      window.speechSynthesis.onvoiceschanged = populateSpeechVoicePicker;
    }
  }

  function renderCourseOutline() {
    if (!currentRoadmap) return;
    const tasks = getAllTasks();
    $('#courseOutlineList').innerHTML = tasks.map((task, index) => {
      const done = Boolean(completedTasks[task.task_id]);
      const active = task.task_id === activeTaskId;
      return `<button type="button" class="outline-lesson ${done ? 'is-complete' : ''} ${active ? 'is-active' : ''}" data-outline-task="${escapeHtml(task.task_id)}" aria-current="${active ? 'step' : 'false'}"><span class="outline-number">${done ? '✓' : index + 1}</span><span class="outline-lesson-copy"><strong>${escapeHtml(task.title)}</strong><small>Week ${task.weekNumber} · ${formatHours(task.hours)}</small></span></button>`;
    }).join('');
    const doneCount = tasks.filter(task => completedTasks[task.task_id]).length;
    $('#outlineProgress').textContent = `${doneCount} of ${tasks.length} lessons complete`;
  }

  function updateCoursePlayerProgress() {
    if (!activeTaskId || !currentRoadmap) return;
    const tasks = getAllTasks();
    const index = tasks.findIndex(task => task.task_id === activeTaskId);
    if (index < 0) return;
    const current = tasks[index];
    const doneCount = tasks.filter(task => completedTasks[task.task_id]).length;
    $('#playerPosition').textContent = `Lesson ${index + 1} of ${tasks.length}`;
    $('#playerProgressBar').style.width = `${tasks.length ? Math.round(doneCount / tasks.length * 100) : 0}%`;
    $('#previousLessonButton').disabled = index === 0;
    $('#outlineProgress').textContent = `${doneCount} of ${tasks.length} lessons complete`;
    const complete = Boolean(completedTasks[current.task_id]);
    const readyToComplete = allStudyActivitiesDone();
    $('#nextLessonButton').disabled = !complete && !readyToComplete;
    $('#nextLessonButton').textContent = complete
      ? (index === tasks.length - 1 ? 'Go to final test →' : 'Next lesson →')
      : readyToComplete
        ? (index === tasks.length - 1 ? 'Complete lesson & finish course →' : 'Complete lesson & continue →')
        : 'Pass the knowledge check to continue';
    refreshStudyActivityUI();
    renderCourseOutline();
  }

  function openLesson(taskId) {
    const task = findTask(taskId);
    if (!task) return;
    activeTaskId = taskId;
    loadStudyState(taskId);
    lessonAnswerCorrect = Boolean(completedTasks[taskId] || activeStudyState.completed.knowledgeCheck);
    const lesson = lessonForTask(task);
    $('#lessonCategory').textContent = `${task.unit_label ? `${task.unit_label} · ` : ''}${task.category} · Week ${task.weekNumber}`;
    $('#lessonDuration').textContent = `About ${formatHours(task.hours)}`;
    $('#lessonTitle').textContent = task.title;
    $('#lessonLectureTitle').textContent = `${lesson.title || task.title} — complete lecture notes`;
    $('#lessonIntro').textContent = lesson.intro;
    $('#lessonSections').innerHTML = lesson.sections.map((section, index) => `<section class="lesson-content-block"><span class="lesson-block-number">${String(index + 1).padStart(2, '0')}</span><div><h3>${escapeHtml(section.heading)}</h3><div class="lesson-section-body">${renderLectureParagraphs(section.body)}</div></div></section>`).join('');
    const syllabusSources = lesson.source_topics || [];
    $('#lessonSyllabusAlignment').classList.toggle('hidden', syllabusSources.length === 0);
    $('#lessonSourceTopics').innerHTML = syllabusSources.map(topic => `<li>${escapeHtml(topic)}</li>`).join('');
    const terms = lesson.key_terms || [];
    $('#lessonKeyTerms').classList.toggle('hidden', terms.length === 0);
    $('#lessonKeyTerms').innerHTML = terms.length ? `<h3>Key terminology</h3><ul class="lecture-term-list">${terms.map(term => `<li><strong>${escapeHtml(term.term)}</strong><span>${escapeHtml(term.definition)}</span></li>`).join('')}</ul>` : '';
    const example = lesson.worked_example || {};
    const exampleSteps = Array.isArray(example.solution_steps) ? example.solution_steps : [];
    const showExample = Boolean(example.scenario || exampleSteps.length || example.conclusion);
    $('#lessonWorkedExampleDetails').classList.toggle('hidden', !showExample);
    $('#lessonWorkedExampleDetails').innerHTML = showExample ? `<h3>${escapeHtml(example.title || 'Worked example')}</h3>${example.scenario ? `<p>${escapeHtml(example.scenario)}</p>` : ''}${exampleSteps.length ? `<ol class="lecture-detail-list">${exampleSteps.map(step => `<li>${escapeHtml(step)}</li>`).join('')}</ol>` : ''}${example.conclusion ? `<h4>Interpretation</h4><p>${escapeHtml(example.conclusion)}</p>` : ''}` : '';
    const studyCase = lesson.case_study || {};
    const caseAnalysis = Array.isArray(studyCase.analysis) ? studyCase.analysis : [];
    const discussion = Array.isArray(studyCase.discussion_questions) ? studyCase.discussion_questions : [];
    const showCase = Boolean(studyCase.scenario || caseAnalysis.length || discussion.length);
    $('#lessonCaseStudy').classList.toggle('hidden', !showCase);
    $('#lessonCaseStudy').innerHTML = showCase ? `<h3>${escapeHtml(studyCase.title || 'Case study')}</h3>${studyCase.scenario ? `<p>${escapeHtml(studyCase.scenario)}</p>` : ''}${caseAnalysis.length ? `<h4>Analysis</h4><ol class="lecture-detail-list">${caseAnalysis.map(point => `<li>${escapeHtml(point)}</li>`).join('')}</ol>` : ''}${discussion.length ? `<h4>Discussion questions</h4><ul class="lecture-detail-list">${discussion.map(point => `<li>${escapeHtml(point)}</li>`).join('')}</ul>` : ''}` : '';
    const misconceptions = lesson.common_misconceptions || [];
    $('#lessonMisconceptions').classList.toggle('hidden', misconceptions.length === 0);
    $('#lessonMisconceptions').innerHTML = misconceptions.length ? `<h3>Common misconceptions and corrections</h3><ul class="lecture-detail-list">${misconceptions.map(point => `<li>${escapeHtml(point)}</li>`).join('')}</ul>` : '';

    const generatedExample = lesson.worked_example || {};
    const generatedCase = lesson.case_study || {};
    const workshop = task.custom_lesson ? {
      example: [generatedExample.scenario, ...(generatedExample.solution_steps || []), generatedExample.conclusion].filter(Boolean).join('\n\n'),
      steps: [
        generatedExample.scenario || `Identify the problem in ${task.title}.`,
        ...(generatedExample.solution_steps || []).slice(0, 4),
        generatedExample.conclusion || 'Interpret the result and state any assumptions or limits.'
      ].filter(Boolean).slice(0, 6),
      reflection: (generatedCase.discussion_questions || [])[0] || `Explain how the ideas in ${task.title} connect to the original syllabus outcomes.`
    } : (LESSON_WORKSHOPS[task.module_id] || {
      example: `Apply the lesson’s main idea to a concrete situation. Start with the topic “${task.title},” identify the goal, list the relevant facts, and explain why your chosen approach fits the evidence.`,
      steps: [
        `Rewrite this lesson’s goal in your own words: ${task.description || task.title}.`,
        'Make a small example, diagram, table, or checklist that demonstrates the concept.',
        `Complete the course practice task: ${task.practice || 'Apply the concept to a realistic example.'}`,
        'Check your work against the key takeaways and correct any misunderstanding.'
      ],
      reflection: 'What is one thing you can now explain or do that you could not confidently do before this lesson?'
    });
    activeLessonContext = { task, lesson, workshop };
    activeLessonSlides = buildLectureSlides(task, lesson, workshop);
    activeSlideIndex = 0;
    renderLectureSlide(0);
    $('#previewGoalText').textContent = task.description || `By the end of this lesson, you should be able to explain ${task.title}.`;
    $('#lessonWorkedExample').textContent = workshop.example;
    $('#lessonReflectionPrompt').textContent = workshop.reflection;
    $('#lessonTakeaways').innerHTML = lesson.takeaways.map(point => `<li>${escapeHtml(point)}</li>`).join('');
    $('#lessonPractice').textContent = `Practice goal: ${task.practice || task.title}.`;
    const resource = $('#lessonResource');
    const resourceWrap = resource?.closest('.lesson-resource');
    if (resourceWrap) resourceWrap.classList.toggle('hidden', Boolean(task.custom_lesson));
    if (resource && !task.custom_lesson) {
      resource.href = task.resource_url || '#';
      resource.textContent = `${task.resource_title || 'Open learning resource'} ↗`;
    }

    $('#coreIdeaSelect').innerHTML = lesson.sections.map((section, index) => `<option value="${index}">${escapeHtml(section.heading)}</option>`).join('');
    $('#coreIdeaSelect').value = String(Math.min(Number(activeStudyState.coreConceptIndex) || 0, Math.max(0, lesson.sections.length - 1)));

    activeWorkedExampleSteps = [
      { title: 'Identify the goal', body: `The task is about ${task.title}. Start by restating the goal: ${task.description || task.title}.` },
      { title: 'Choose the relevant idea', body: lesson.sections[0] ? `${lesson.sections[0].heading}: ${lesson.sections[0].body}` : lesson.intro },
      { title: 'Apply the idea to the case', body: workshop.example },
      { title: 'Check and explain the result', body: `Compare the result with this key takeaway: ${lesson.takeaways[0] || 'Explain what the result means and why it matters.'} Then state what evidence would support your conclusion.` }
    ];

    $('#lessonActivitySteps').innerHTML = workshop.steps.map((step, index) => `
      <li>
        <div class="practice-prompt"><span class="practice-prompt-number">${index + 1}</span><p class="practice-step-prompt">${escapeHtml(step)}</p></div>
        <label for="practiceResponse${index}">Your response</label>
        <textarea id="practiceResponse${index}" data-practice-index="${index}" rows="2" placeholder="Write your reasoning or result…">${escapeHtml(activeStudyState.responses.practice[index] || '')}</textarea>
      </li>`).join('');

    $('#previewResponse').value = activeStudyState.responses.preview || '';
    $('#coreIdeaResponse').value = activeStudyState.responses.coreIdea || '';
    $('#workedExamplePrediction').value = activeStudyState.responses.workedPrediction || '';
    $('#recallResponse').value = activeStudyState.responses.recall || '';
    $('#lessonSlideDeck').classList.toggle('recall-hidden', Boolean(activeStudyState.recallNotesHidden));
    $('#toggleRecallNotesButton').textContent = activeStudyState.recallNotesHidden ? 'Show lecture slides again' : 'Hide lecture slides for recall';
    $('#coreIdeaModel').classList.add('hidden');
    $('#recallModel').classList.add('hidden');
    $('#previewFeedback').textContent = '';
    $('#coreIdeaFeedback').textContent = '';
    $('#workedExampleFeedback').textContent = '';
    $('#handsOnFeedback').textContent = '';
    $('#recallFeedback').textContent = '';
    renderWorkedExampleWalkthrough();

    activeLessonCheckQuestions = getLessonCheckQuestions(task, lesson);
    $('#lessonQuestion').textContent = `Check your understanding — ${activeLessonCheckQuestions.length} questions`;
    $('#lessonQuizForm').innerHTML = activeLessonCheckQuestions.map((question, questionIndex) => `
      <section class="lesson-check-question" data-check-question="${question.id}">
        <h4><span class="lesson-check-number">${questionIndex + 1}</span><span>${escapeHtml(question.question)}</span></h4>
        <div class="lesson-options">${question.options.map((option, optionIndex) => `<label class="lesson-option"><input type="radio" name="lesson-answer-${questionIndex}" value="${optionIndex}"><span>${escapeHtml(option)}</span></label>`).join('')}</div>
        <p class="lesson-check-feedback hidden" data-check-feedback="${question.id}" aria-live="polite"></p>
      </section>`).join('');
    $('#lessonQuizFeedback').textContent = completedTasks[taskId]
      ? 'This lesson was completed previously. You can review the lecture and take the knowledge check again.'
      : 'Pass the knowledge check to complete this lesson and continue.';
    $('#lessonQuizFeedback').className = '';

    renderStudyPlan(task);
    showSavedActivityFeedback();
    $('#nextLessonButton').disabled = !completedTasks[taskId] && !allStudyActivitiesDone();
    $('#learningPlayer').classList.remove('hidden');
    updateCoursePlayerProgress();

    $('#learningPlayer').scrollIntoView({ behavior: 'smooth', block: 'start' });
    resetAudioPlayer();
    const playBtn = $('#playAudioBtn');
    const voiceSelect = $('#voiceSelect');
    if (playBtn) playBtn.title = playBtn.disabled ? 'Audio narration is not supported by this browser.' : 'Listen, pause, and resume the lecture audio.';
    if (voiceSelect) voiceSelect.title = 'Select a more natural narrator if your browser has one available.';
    const audioStatus = $('#audioStatus');
    if (audioStatus) audioStatus.textContent = playBtn?.disabled
      ? 'Audio is not supported in this browser. The lecture slides and interactive activities are still available.'
      : 'Audio is optional. Follow the slides, then complete the interactive activities to practice and demonstrate understanding.';
  }


  function saveActivityInput(activityId, responseKey, value) {
    if (!activeStudyState) return;
    activeStudyState.responses[responseKey] = value;
    activeStudyState.completed[activityId] = false;
    persistStudyState();
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function completePreviewActivity() {
    const response = ($('#previewResponse').value || '').trim();
    activeStudyState.responses.preview = response;
    if (response.length < 15) {
      $('#previewFeedback').textContent = 'Add a little more detail: one or two sentences about what you already know or want to learn.';
      $('#previewFeedback').className = 'activity-feedback is-warning';
      return;
    }
    activeStudyState.completed.preview = true;
    persistStudyState();
    $('#previewFeedback').textContent = 'First thoughts saved. After studying, revisit this answer and see what you can now explain more accurately.';
    $('#previewFeedback').className = 'activity-feedback is-correct';
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function renderCoreIdeaModel() {
    if (!activeLessonContext || !activeStudyState) return;
    const index = Math.max(0, Math.min(Number(activeStudyState.coreConceptIndex) || 0, activeLessonContext.lesson.sections.length - 1));
    const section = activeLessonContext.lesson.sections[index];
    const model = $('#coreIdeaModel');
    if (!section || !model) return;
    model.classList.remove('hidden');
    model.innerHTML = `<strong>Compare with the lecture</strong><h4>${escapeHtml(section.heading)}</h4><p>${escapeHtml(section.body)}</p><p class="model-reflection-prompt">Can you identify (1) what the concept means, (2) why it matters, and (3) an example in your own response?</p>`;
  }

  function checkCoreIdeaActivity() {
    const response = ($('#coreIdeaResponse').value || '').trim();
    activeStudyState.responses.coreIdea = response;
    activeStudyState.coreConceptIndex = $('#coreIdeaSelect').value || '0';
    if (response.length < 30) {
      $('#coreIdeaFeedback').textContent = 'Try at least a few sentences: define the idea, say why it matters, and give an example.';
      $('#coreIdeaFeedback').className = 'activity-feedback is-warning';
      return;
    }
    renderCoreIdeaModel();
    activeStudyState.completed.coreIdeas = true;
    persistStudyState();
    $('#coreIdeaFeedback').textContent = 'Compare your explanation with the lecture. Check that you covered the meaning, importance, and an example.';
    $('#coreIdeaFeedback').className = 'activity-feedback is-correct';
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function checkWorkedExamplePrediction() {
    const prediction = ($('#workedExamplePrediction').value || '').trim();
    activeStudyState.responses.workedPrediction = prediction;
    if (prediction.length < 15) {
      $('#workedExampleFeedback').textContent = 'Make a prediction first. State what you would do and give a reason before revealing the solution.';
      $('#workedExampleFeedback').className = 'activity-feedback is-warning';
      return;
    }
    if (activeStudyState.completed.workedExample && activeStudyState.workedExampleStep >= activeWorkedExampleSteps.length) {
      $('#workedExampleFeedback').textContent = 'You already completed this walkthrough. Change your prediction to try the example again from the beginning.';
      $('#workedExampleFeedback').className = 'activity-feedback is-correct';
      renderWorkedExampleWalkthrough();
      return;
    }
    activeStudyState.workedPredictionSubmitted = true;
    activeStudyState.completed.workedExample = false;
    activeStudyState.workedExampleStep = Math.max(1, activeStudyState.workedExampleStep);
    renderWorkedExampleWalkthrough();
    persistStudyState();
    $('#workedExampleFeedback').textContent = 'Now compare your prediction with the guided solution. Reveal one step at a time and note what changes your thinking.';
    $('#workedExampleFeedback').className = 'activity-feedback';
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function revealNextWorkedExampleStep() {
    if (!activeStudyState?.workedPredictionSubmitted) {
      checkWorkedExamplePrediction();
      if (!activeStudyState?.workedPredictionSubmitted) return;
    }
    activeStudyState.workedExampleStep = Math.min(activeWorkedExampleSteps.length, activeStudyState.workedExampleStep + 1);
    if (activeStudyState.workedExampleStep >= activeWorkedExampleSteps.length) {
      activeStudyState.completed.workedExample = true;
      $('#workedExampleFeedback').textContent = 'Walkthrough complete. Make sure you can explain why each step follows from the previous one.';
      $('#workedExampleFeedback').className = 'activity-feedback is-correct';
    }
    renderWorkedExampleWalkthrough();
    persistStudyState();
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function submitHandsOnPractice() {
    const fields = $$('#lessonActivitySteps textarea[data-practice-index]');
    const responses = fields.map(field => (field.value || '').trim());
    activeStudyState.responses.practice = responses;
    const missing = responses.filter(response => response.length < 8).length;
    if (!fields.length || missing > 0) {
      activeStudyState.completed.handsOn = false;
      persistStudyState();
      $('#handsOnFeedback').textContent = `Complete each prompt with a meaningful note. ${missing} response${missing === 1 ? '' : 's'} still need more detail.`;
      $('#handsOnFeedback').className = 'activity-feedback is-warning';
      refreshStudyActivityUI();
      updateCoursePlayerProgress();
      return;
    }
    activeStudyState.completed.handsOn = true;
    persistStudyState();
    $('#handsOnFeedback').textContent = 'Practice responses saved. Compare your reasoning with the lecture and correct any step that is unclear.';
    $('#handsOnFeedback').className = 'activity-feedback is-correct';
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function toggleRecallNotes() {
    if (!activeStudyState) return;
    const deck = $('#lessonSlideDeck');
    const hide = !deck.classList.contains('recall-hidden');
    deck.classList.toggle('recall-hidden', hide);
    activeStudyState.recallNotesHidden = hide;
    if (hide) {
      activeStudyState.recallHiddenOnce = true;
      if (speechPlaybackState === 'playing') pauseLessonAudio();
    }
    $('#toggleRecallNotesButton').textContent = hide ? 'Show lecture slides again' : 'Hide lecture slides for recall';
    persistStudyState();
    if (hide) {
      $('#recallFeedback').textContent = 'Slides hidden. Explain the topic from memory, then reveal the deck and compare your answer.';
      $('#recallFeedback').className = 'activity-feedback';
    }
  }

  function completeRecallActivity() {
    const response = ($('#recallResponse').value || '').trim();
    activeStudyState.responses.recall = response;
    if (!activeStudyState.recallHiddenOnce) {
      $('#recallFeedback').textContent = 'First hide the lecture slides, then try to explain the topic from memory.';
      $('#recallFeedback').className = 'activity-feedback is-warning';
      return;
    }
    if (response.length < 30) {
      $('#recallFeedback').textContent = 'Write a fuller explanation with the main idea and at least one example before comparing.';
      $('#recallFeedback').className = 'activity-feedback is-warning';
      return;
    }
    $('#lessonSlideDeck').classList.remove('recall-hidden');
    activeStudyState.recallNotesHidden = false;
    activeStudyState.completed.recall = true;
    $('#toggleRecallNotesButton').textContent = 'Hide lecture slides for recall';
    const model = $('#recallModel');
    model.classList.remove('hidden');
    model.innerHTML = `<strong>Compare with these key ideas</strong><ul>${activeLessonContext.lesson.takeaways.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul><p>What did you remember correctly? What was missing or inaccurate? Add the missing detail to your notes.</p>`;
    persistStudyState();
    $('#recallFeedback').textContent = 'Good work. Compare your recall with the key ideas, then note one thing you forgot or explained differently.';
    $('#recallFeedback').className = 'activity-feedback is-correct';
    refreshStudyActivityUI();
    updateCoursePlayerProgress();
  }

  function jumpToStudyActivity(id) {
    const selector = STUDY_ACTIVITY_TARGETS[id];
    const target = selector ? $(selector) : null;
    if (!target) return;
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const firstControl = $('textarea, input, select, button', target);
    if (firstControl) window.setTimeout(() => firstControl.focus({ preventScroll: true }), 350);
  }

  function saveLectureNotes() {
    if (!activeTaskId) return;
    const task = findTask(activeTaskId);
    if (!task) return;
    const sectionText = $$('#lessonSections .lesson-content-block').map((block, index) => {
      const heading = block.querySelector('h3')?.innerText?.trim() || `Section ${index + 1}`;
      const body = block.querySelector('p')?.innerText?.trim() || '';
      return `${heading}\n${body}`;
    });
    const activitySteps = $$('#lessonActivitySteps li').map((item, index) => {
      const prompt = $('.practice-step-prompt', item)?.innerText?.trim() || `Practice step ${index + 1}`;
      const response = $('textarea', item)?.value?.trim() || '(No response saved)';
      return `${index + 1}. ${prompt}\n   My response: ${response}`;
    });
    const takeaways = $$('#lessonTakeaways li').map(item => `• ${item.innerText.trim()}`);
    const slideText = activeLessonSlides.map((slide, index) => [
      `SLIDE ${index + 1}: ${slide.title}`,
      `${slide.kicker} · ${slide.type}`,
      slide.lead || '',
      ...(slide.points || []).flatMap(point => [`${point.title}: ${point.text}`]),
      slide.callout?.text ? `${slide.callout.label || 'Remember'}: ${slide.callout.text}` : '',
      slide.footer || ''
    ].filter(Boolean).join('\n')).join('\n\n---\n\n');
    const notes = [
      $('#lessonTitle').innerText.trim(),
      '='.repeat(Math.min(70, $('#lessonTitle').innerText.trim().length || 10)),
      '',
      'LECTURE SLIDES',
      slideText,
      '',
      'LECTURE INTRODUCTION',
      $('#lessonIntro').innerText.trim(),
      '',
      'LECTURE SECTIONS',
      sectionText.join('\n\n'),
      '',
      'KEY TERMS',
      $('#lessonKeyTerms').innerText.trim(),
      '',
      'WORKED EXAMPLE DETAILS',
      $('#lessonWorkedExampleDetails').innerText.trim(),
      '',
      'CASE STUDY',
      $('#lessonCaseStudy').innerText.trim(),
      '',
      'COMMON MISCONCEPTIONS',
      $('#lessonMisconceptions').innerText.trim(),
      '',
      'PREVIEW — WHAT I KNEW BEFORE THE LESSON',
      ($('#previewResponse').value || '').trim() || '(Not completed)',
      '',
      'CORE IDEA — MY EXPLANATION',
      ($('#coreIdeaResponse').value || '').trim() || '(Not completed)',
      '',
      'WORKED EXAMPLE',
      $('#lessonWorkedExample').innerText.trim(),
      'My prediction: ' + ( ($('#workedExamplePrediction').value || '').trim() || '(Not completed)' ),
      '',
      'GUIDED ACTIVITY AND MY RESPONSES',
      activitySteps.join('\n'),
      '',
      'RECALL FROM MEMORY',
      ($('#recallResponse').value || '').trim() || '(Not completed)',
      '',
      'REFLECTION QUESTION',
      $('#lessonReflectionPrompt').innerText.trim(),
      '',
      'KEY TAKEAWAYS',
      takeaways.join('\n'),
      '',
      'PRACTICE TASK',
      $('#lessonPractice').innerText.trim(),
      '',
      'KNOWLEDGE CHECK — ANSWERS AND EXPLANATIONS',
      ...activeLessonCheckQuestions.flatMap((question, index) => [
        `${index + 1}. ${question.question}`,
        ...question.options.map((option, optionIndex) => `${String.fromCharCode(65 + optionIndex)}. ${option}`),
        `Correct answer: ${String.fromCharCode(65 + question.answer)}. ${question.options[question.answer]}`,
        `Explanation: ${question.explanation}`,
        ''
      ])
    ].join('\n');
    const blob = new Blob([notes], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const slug = ($('#lessonTitle').innerText || 'lecture-notes').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'lecture-notes';
    link.href = url;
    link.download = `aheadpath-${slug}-notes.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('Lecture notes saved as a text file.');
  }

  function checkLessonAnswer() {
    if (!activeTaskId || !activeLessonCheckQuestions.length) return;
    const answers = activeLessonCheckQuestions.map((question, index) => ({
      question,
      card: $(`[data-check-question="${question.id}"]`),
      feedback: $(`[data-check-feedback="${question.id}"]`),
      selected: $(`#lessonQuizForm input[name="lesson-answer-${index}"]:checked`)
    }));
    const unanswered = answers.filter(item => !item.selected);
    if (unanswered.length) {
      lessonAnswerCorrect = false;
      activeStudyState.completed.knowledgeCheck = false;
      persistStudyState();
      $('#lessonQuizFeedback').textContent = `Please answer all ${activeLessonCheckQuestions.length} questions. ${unanswered.length} still unanswered.`;
      $('#lessonQuizFeedback').className = 'is-warning';
      updateCoursePlayerProgress();
      return;
    }
    let score = 0;
    answers.forEach(({ question, card, feedback, selected }) => {
      const correct = Number(selected.value) === question.answer;
      if (correct) score += 1;
      if (card) {
        card.classList.toggle('is-correct', correct);
        card.classList.toggle('is-incorrect', !correct);
      }
      if (feedback) {
        feedback.classList.remove('hidden', 'is-correct', 'is-incorrect');
        feedback.classList.add(correct ? 'is-correct' : 'is-incorrect');
        feedback.textContent = correct
          ? `Correct. ${question.explanation}`
          : `Not quite. Correct answer: ${question.options[question.answer]}. ${question.explanation}`;
      }
    });
    const passMark = Math.ceil(activeLessonCheckQuestions.length * 0.75);
    lessonAnswerCorrect = score >= passMark;
    activeStudyState.completed.knowledgeCheck = lessonAnswerCorrect;
    persistStudyState();
    $('#lessonQuizFeedback').textContent = lessonAnswerCorrect
      ? `You scored ${score}/${activeLessonCheckQuestions.length}. You passed. You can continue to the next lesson.`
      : `You scored ${score}/${activeLessonCheckQuestions.length}. You need ${passMark} correct to pass. Review the explanations and try again.`;
    $('#lessonQuizFeedback').className = lessonAnswerCorrect ? 'is-correct' : 'is-incorrect';
    updateCoursePlayerProgress();
  }

  function completeCurrentLesson() {
    if (!activeTaskId || !allStudyActivitiesDone()) return false;
    completedTasks[activeTaskId] = true;
    saveProgress();
    updateProgressUI();
    updateCoursePlayerProgress();
    showToast('Lesson completed.');
    return true;
  }

  function continueCourse() {
    const tasks = getAllTasks();
    const index = tasks.findIndex(task => task.task_id === activeTaskId);
    if (index < 0) return;
    if (!completedTasks[activeTaskId]) {
      if (!allStudyActivitiesDone()) {
        showToast('Pass the knowledge check before continuing.');
        return;
      }
      completeCurrentLesson();
    }
    if (index < tasks.length - 1) {
      openLesson(tasks[index + 1].task_id);
      return;
    }
    if (tasks.length && tasks.every(task => completedTasks[task.task_id])) {
      $('#finalAssessmentPanel').classList.remove('hidden');
      $('#finalAssessmentSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
      showToast('Final test unlocked.');
    }
  }

  function renderFinalAssessment() {
    activeFinalAssessmentQuestions = selectFinalAssessmentQuestions();
    finalAssessmentScored = Boolean(finalAssessmentResult && finalAssessmentResult.scored);
    $('#finalAssessmentForm').innerHTML = activeFinalAssessmentQuestions.map((question, index) => `
      <section class="final-question" data-final-question="${question.id}">
        <h4><span class="final-question-number">${index + 1}</span>${escapeHtml(question.question)}</h4>
        <div class="final-options">${question.options.map((option, optionIndex) => `<label class="final-option"><input type="radio" name="${question.id}" value="${optionIndex}" ${finalAssessmentResult && finalAssessmentResult.answers && Number(finalAssessmentResult.answers[question.id]) === optionIndex ? 'checked' : ''}><span>${escapeHtml(option)}</span></label>`).join('')}</div>
        <p class="final-explanation hidden" data-final-explanation="${question.id}"></p>
      </section>`).join('');
    $('#finalTestScorePill').textContent = `${activeFinalAssessmentQuestions.length} questions`;
    $('#finalAssessmentFeedback').textContent = '';
    $('#finalAssessmentPanel').classList.add('hidden');
    $('#retakeFinalAssessmentButton').classList.add('hidden');
    $('#submitFinalAssessmentButton').disabled = false;
    if (finalAssessmentScored) {
      showFinalAssessmentResult(finalAssessmentResult);
    }
  }

  function showFinalAssessmentResult(result) {
    if (!result) return;
    activeFinalAssessmentQuestions.forEach(question => {
      const card = $(`[data-final-question="${question.id}"]`);
      if (!card) return;
      const chosenValue = result.answers ? result.answers[question.id] : undefined;
      const correct = Number(chosenValue) === question.answer;
      card.classList.toggle('correct', correct);
      card.classList.toggle('wrong', !correct);
      const explanation = $(`[data-final-explanation="${question.id}"]`);
      explanation.textContent = question.explanation;
      explanation.classList.remove('hidden');
      $$(`input[name="${question.id}"]`, card).forEach(input => { input.disabled = true; });
    });
    const passed = Boolean(result.passed);
    $('#finalAssessmentFeedback').textContent = `Score: ${result.score}/${activeFinalAssessmentQuestions.length} (${Math.round(result.score / activeFinalAssessmentQuestions.length * 100)}%). ${passed ? 'Passed — course preparation complete.' : 'Not passed yet. Review the explanations and try again.'}`;
    $('#finalAssessmentFeedback').className = passed ? 'is-correct' : 'is-incorrect';
    $('#submitFinalAssessmentButton').disabled = true;
    $('#retakeFinalAssessmentButton').classList.remove('hidden');
    $('#launchFinalAssessmentButton').textContent = 'Review final test';
  }

  function openFinalAssessment() {
    const tasks = getAllTasks();
    if (!tasks.length || !tasks.every(task => completedTasks[task.task_id])) {
      showToast('Complete every lesson first.');
      return;
    }
    $('#finalAssessmentPanel').classList.remove('hidden');
    $('#finalAssessmentSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function scoreFinalAssessment() {
    const tasks = getAllTasks();
    if (!tasks.length || !tasks.every(task => completedTasks[task.task_id])) {
      $('#finalAssessmentFeedback').textContent = 'Complete all lessons to unlock the final test.';
      return;
    }
    const answers = {};
    for (const question of activeFinalAssessmentQuestions) {
      const selected = $(`#finalAssessmentForm input[name="${question.id}"]:checked`);
      if (!selected) {
        $('#finalAssessmentFeedback').textContent = 'Answer every question before submitting.';
        $('#finalAssessmentFeedback').className = 'is-warning';
        const card = $(`[data-final-question="${question.id}"]`);
        card?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      answers[question.id] = Number(selected.value);
    }
    const score = activeFinalAssessmentQuestions.filter(question => answers[question.id] === question.answer).length;
    finalAssessmentResult = { scored: true, answers, score, passed: score >= Math.ceil(activeFinalAssessmentQuestions.length * 0.75), completedAt: new Date().toISOString() };
    finalAssessmentScored = true;
    showFinalAssessmentResult(finalAssessmentResult);
    updateProgressUI();
    saveProgress();
  }

  function resetFinalAssessment() {
    finalAssessmentResult = null;
    finalAssessmentScored = false;
    renderFinalAssessment();
    saveProgress();
    $('#finalAssessmentPanel').classList.remove('hidden');
    showToast('Test reset. Try again.');
  }

  function renderQuiz(plan = currentRoadmap) {
    quizScored = false;
    if (Array.isArray(plan?.diagnostic_questions) && plan.diagnostic_questions.length >= 3) {
      activeDiagnosticQuiz = plan.diagnostic_questions.slice(0, 4).map((question, index) => ({
        id: `syllabus-diagnostic-${index + 1}`,
        topics: [], skill: 'syllabus',
        question: question.question,
        options: question.options,
        answer: question.answer,
        explanation: question.explanation
      }));
      $('#applyDiagnosticButton').classList.add('hidden');
      $('#diagnosticFeedback').textContent = 'These questions come from the syllabus you provided. Use the explanations to identify which concepts to review first.';
      $('#diagnosticForm').innerHTML = activeDiagnosticQuiz.map((q, index) => `
        <section class="diagnostic-question" data-question-card="${q.id}">
          <h4><span class="q-num">${index + 1}</span>${escapeHtml(q.question)}</h4>
          ${q.options.map((opt, optIndex) => `<label class="diagnostic-option"><input type="radio" name="${q.id}" value="${optIndex}"><span>${escapeHtml(opt)}</span></label>`).join('')}
          <div class="quiz-explanation hidden" data-explanation="${q.id}"></div>
        </section>
      `).join('');
      $('#scoreDiagnosticButton').textContent = `Check ${activeDiagnosticQuiz.length} answers`;
      $('#applyDiagnosticButton').textContent = 'Close skills check';
      return;
    }
    const plannedIds = new Set((plan?.weeks || []).flatMap(week => (week.tasks || []).map(task => task.module_id)));
    const detectedIds = (plan?.detected_topics || []).map(topic => topic.id);
    const syllabusMatched = DIAGNOSTIC_QUESTION_BANK.filter(question => question.topics.some(id => detectedIds.includes(id)));
    const plannedMatched = DIAGNOSTIC_QUESTION_BANK.filter(question => question.topics.some(id => plannedIds.has(id)));
    const pool = syllabusMatched.length ? syllabusMatched : plannedMatched;
    activeDiagnosticQuiz = [];
    const usedSkills = new Set();
    for (const question of pool) {
      if (activeDiagnosticQuiz.length >= 4) break;
      if (!activeDiagnosticQuiz.some(existing => existing.id === question.id)) {
        activeDiagnosticQuiz.push(question);
        usedSkills.add(question.skill);
      }
    }
    // Keep four questions where possible, but avoid adding off-syllabus topics unless the syllabus matched very few topics.
    if (activeDiagnosticQuiz.length < 3) {
      for (const question of FALLBACK_DIAGNOSTIC_QUESTIONS) {
        if (activeDiagnosticQuiz.length >= 4) break;
        if (!activeDiagnosticQuiz.some(existing => existing.id === question.id)) activeDiagnosticQuiz.push(question);
      }
    }
    $('#applyDiagnosticButton').classList.add('hidden');
    $('#diagnosticFeedback').textContent = `These ${activeDiagnosticQuiz.length} questions are selected from the topics matched to this syllabus. Use the results to update your starting point.`;
    $('#diagnosticForm').innerHTML = activeDiagnosticQuiz.map((q, index) => `
      <section class="diagnostic-question" data-question-card="${q.id}">
        <h4><span class="q-num">${index + 1}</span>${escapeHtml(q.question)}</h4>
        ${q.options.map((opt, optIndex) => `<label class="diagnostic-option"><input type="radio" name="${q.id}" value="${optIndex}"><span>${escapeHtml(opt)}</span></label>`).join('')}
        <div class="quiz-explanation hidden" data-explanation="${q.id}"></div>
      </section>
    `).join('');
    $('#scoreDiagnosticButton').textContent = `Check ${activeDiagnosticQuiz.length} answers`;
  }

  function scoreDiagnostic() {
    let score = 0;
    const bySkill = {};
    const missing = [];
    activeDiagnosticQuiz.forEach(q => {
      const chosen = $(`input[name="${q.id}"]:checked`);
      const card = $(`[data-question-card="${q.id}"]`);
      const explanation = $(`[data-explanation="${q.id}"]`);
      card.classList.remove('correct', 'wrong');
      explanation.classList.remove('hidden');
      if (!chosen) {
        missing.push(q.id);
        card.classList.add('wrong');
        explanation.textContent = `Choose an answer to review this question. ${q.explanation}`;
        bySkill[q.skill] = false;
        return;
      }
      const correct = Number(chosen.value) === q.answer;
      if (correct) score += 1;
      card.classList.add(correct ? 'correct' : 'wrong');
      explanation.textContent = q.explanation;
      bySkill[q.skill] = bySkill[q.skill] !== false && correct;
    });
    quizScored = missing.length === 0;
    if (!quizScored) {
      $('#diagnosticFeedback').textContent = `You have ${missing.length} unanswered question${missing.length === 1 ? '' : 's'}. Answer all questions to update your starting point.`;
      $('#applyDiagnosticButton').classList.add('hidden');
      return;
    }
    $('#diagnosticFeedback').textContent = `You scored ${score}/${activeDiagnosticQuiz.length}. ${score >= Math.ceil(activeDiagnosticQuiz.length * 0.75) ? 'Good foundation. Your missed question can highlight what to review.' : 'The missed questions will help prioritize foundations in your updated plan.'}`;
    $('#applyDiagnosticButton').classList.remove('hidden');
    $('#applyDiagnosticButton').dataset.skillResults = JSON.stringify(bySkill);
  }

  async function applyDiagnostic() {
    if (!quizScored) return;
    if (activeDiagnosticQuiz.every(question => question.skill === 'syllabus')) {
      const disclosure = $('#readinessSection');
      if (disclosure) disclosure.open = false;
      showToast('Skills check reviewed. Start with the lesson whose concepts felt least familiar.');
      return;
    }
    let results = {};
    try { results = JSON.parse($('#applyDiagnosticButton').dataset.skillResults || '{}'); } catch (_err) { results = {}; }
    const fieldMap = { computer: '#skillComputer', linux: '#skillLinux', networking: '#skillNetworking', programming: '#skillProgramming', web: '#skillWeb', security: '#skillSecurity' };
    Object.entries(results).forEach(([skill, correct]) => {
      const field = $(fieldMap[skill]);
      if (field) field.value = correct ? 'some' : 'new';
    });
    $('#builder').scrollIntoView({ behavior: 'smooth', block: 'start' });
    const created = await generateRoadmap();
    if (created) showToast('A new course was created from your skill-check results. Your original course remains saved in My courses.');
  }

  function downloadPlan() {
    if (!currentRoadmap) return;
    const plan = currentRoadmap;
    const lines = [`# AheadPath learning roadmap: ${plan.course_title}`, '', `**Goal:** ${plan.goal_label}`, `**Semester starts:** ${prettyDate(plan.start_date)}`, `**Available time:** ${plan.hours_per_week} hours/week for ${plan.weeks_count} weeks`, `**Planned study time:** ${plan.planned_hours} of ${plan.total_budget_hours} available hours`, '', '## Course summary', plan.summary, '', '## Detected syllabus topics', ...(plan.detected_topics.length ? plan.detected_topics.map(t => `- ${t.title}`) : ['- No clear syllabus keywords detected']), '', '## Weekly plan'];
    (plan.weeks || []).forEach(week => {
      lines.push('', `### Week ${week.number} — ${week.hours} hours`);
      if (!week.tasks.length) lines.push('- No sessions assigned');
      week.tasks.forEach(task => {
        lines.push(`- [${completedTasks[task.task_id] ? 'x' : ' '}] **${task.title}** (${task.hours} h)`, `  - Why: ${task.why}`, `  - Practice: ${task.practice}`, `  - Resource: ${task.resource_title} — ${task.resource_url}`);
      });
    });
    if (plan.postponed_topics.length) {
      lines.push('', '## Topics to explore later');
      plan.postponed_topics.forEach(topic => lines.push(`- ${topic.title} — ${topic.resource_url}`));
    }
    if (plan.uncertainties.length) {
      lines.push('', '## Notes to review');
      plan.uncertainties.forEach(note => lines.push(`- ${note}`));
    }
    lines.push('', 'Generated by AheadPath. Recommendations are preparatory suggestions, not official course requirements.');
    const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AheadPath-${(plan.course_title || 'roadmap').replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase()}.md`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    showToast('Your roadmap was downloaded as a Markdown file.');
  }

  function setAuthMode(mode) {
    const isRegister = mode === 'register';
    $('#loginForm').classList.toggle('hidden', isRegister);
    $('#registerForm').classList.toggle('hidden', !isRegister);
    $('#showLoginTab').classList.toggle('is-active', !isRegister);
    $('#showRegisterTab').classList.toggle('is-active', isRegister);
    $('#showLoginTab').setAttribute('aria-selected', String(!isRegister));
    $('#showRegisterTab').setAttribute('aria-selected', String(isRegister));
    $('#authMessage').textContent = '';
    $('#authMessage').classList.remove('is-success');
    $('#authTitle').textContent = isRegister ? 'Create your learning account' : 'Your courses, on every device';
  }

  function setAuthMessage(message, success = false) {
    $('#authMessage').textContent = message;
    $('#authMessage').classList.toggle('is-success', Boolean(success));
  }

  async function submitAuth(form, endpoint) {
    const submitButton = $('button[type="submit"]', form);
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = endpoint.endsWith('/register') ? 'Creating account…' : 'Signing in…';
    setAuthMessage('');
    try {
      const username = $('input[name="username"]', form).value.trim();
      const password = $('input[name="password"]', form).value;
      const response = await fetch(endpoint, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Account request failed.');
      currentUsername = data.username;
      $('#authGate').classList.add('hidden');
      $('#accountName').textContent = currentUsername;
      $('#accountName').classList.remove('hidden');
      $('#logoutButton').classList.remove('hidden');
      $('#modeBadge').innerHTML = '<span class="status-dot"></span> Courses synced';
      await refreshSavedCourses(true);
      showToast(endpoint.endsWith('/register') ? 'Account created. Your courses will sync across devices.' : 'Welcome back. Your saved courses are ready.');
    } catch (error) {
      setAuthMessage(error.message || 'Please try again.');
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  }

  async function checkAuth() {
    try {
      const response = await fetch('/api/auth/me');
      const data = await response.json();
      if (!data.authenticated) {
        $('#authGate').classList.remove('hidden');
        return;
      }
      currentUsername = data.username;
      $('#authGate').classList.add('hidden');
      $('#accountName').textContent = currentUsername;
      $('#accountName').classList.remove('hidden');
      $('#logoutButton').classList.remove('hidden');
      $('#modeBadge').innerHTML = '<span class="status-dot"></span> Courses synced';
      await refreshSavedCourses(true);
    } catch (_error) {
      $('#authGate').classList.remove('hidden');
      setAuthMessage('Could not connect to AheadPath. Check that the server is running.');
    }
  }

  function renderSavedCourses(courses) {
    const grid = $('#savedCoursesGrid');
    if (!courses.length) {
      grid.innerHTML = `<div class="saved-courses-empty"><h3>Your library is ready</h3><p>Generate your first course. Every course you create will stay here until you delete it.</p><button id="emptyLibraryBuildButton" class="button button-primary" type="button">Build my first course</button></div>`;
      return;
    }
    grid.innerHTML = courses.map(course => {
      const passed = Boolean(course.final_assessment && course.final_assessment.passed);
      const updatedAt = course.updated_at ? new Date(course.updated_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';
      return `<article class="saved-course-card" data-course-card="${escapeHtml(course.course_id)}">
        <div class="saved-course-top"><div class="saved-course-icon" aria-hidden="true">${passed ? '✓' : '↗'}</div><span class="saved-course-updated">Saved ${escapeHtml(updatedAt)}</span></div>
        <div><h3 class="saved-course-title">${escapeHtml(course.title)}</h3><p class="saved-course-goal">${escapeHtml(course.goal.replaceAll('_', ' '))} · Starts ${escapeHtml(prettyDate(course.start_date))}</p></div>
        <div><div class="saved-progress-label"><span>${course.completed_count} of ${course.task_count} lessons</span><strong>${course.progress_percent}%</strong></div><div class="saved-progress-rail"><span style="width:${course.progress_percent}%"></span></div></div>
        <div class="saved-course-actions"><button class="button button-primary" type="button" data-load-course="${escapeHtml(course.course_id)}">${course.progress_percent ? 'Continue learning' : 'Start learning'} →</button><button class="button delete-course-button" type="button" data-delete-course="${escapeHtml(course.course_id)}" aria-label="Delete ${escapeHtml(course.title)}">Delete</button></div>
        ${passed ? '<p class="saved-course-goal">Final assessment passed</p>' : ''}
      </article>`;
    }).join('');
  }

  async function refreshSavedCourses(showSection = false) {
    try {
      const response = await fetch('/api/courses');
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not load your course library.');
      renderSavedCourses(data.courses || []);
      $('#savedCoursesSection').classList.remove('hidden');
      if (showSection) $('#savedCoursesSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
      return data.courses || [];
    } catch (error) {
      console.error('AheadPath course library error:', error);
      if (showSection) showToast(error.message || 'Could not load saved courses.');
      return [];
    }
  }

  async function openSavedCourse(courseId) {
    try {
      const response = await fetch(`/api/courses/${encodeURIComponent(courseId)}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not open this course.');
      currentCourseId = data.course_id;
      currentRoadmap = data.plan;
      loadProgress(currentRoadmap, data.progress);
      renderRoadmap(currentRoadmap);
      $('#resultsSection').classList.remove('hidden');
      $('#resultsSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
      showToast('Course loaded. Your progress is up to date.');
    } catch (error) {
      showToast(error.message || 'Could not open this course.');
    }
  }

  async function deleteSavedCourse(courseId) {
    const card = document.querySelector(`[data-course-card="${CSS.escape(courseId)}"]`);
    const courseTitle = $('.saved-course-title', card)?.textContent || 'this course';
    if (!window.confirm(`Delete “${courseTitle}” and its saved progress? This cannot be undone.`)) return;
    try {
      const response = await fetch(`/api/courses/${encodeURIComponent(courseId)}`, { method: 'DELETE' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not delete this course.');
      if (currentCourseId === courseId) {
        currentCourseId = null;
        currentRoadmap = null;
        completedTasks = {};
        finalAssessmentResult = null;
        activeTaskId = null;
        $('#resultsSection').classList.add('hidden');
        $('#learningPlayer').classList.add('hidden');
      }
      await refreshSavedCourses(false);
      showToast('Course deleted.');
    } catch (error) {
      showToast(error.message || 'Could not delete this course.');
    }
  }

  async function logout() {
    try { await fetch('/api/auth/logout', { method: 'POST' }); } catch (_error) { /* The server session may already be gone. */ }
    currentUsername = null;
    currentCourseId = null;
    currentRoadmap = null;
    completedTasks = {};
    finalAssessmentResult = null;
    $('#resultsSection').classList.add('hidden');
    $('#savedCoursesSection').classList.add('hidden');
    $('#accountName').classList.add('hidden');
    $('#logoutButton').classList.add('hidden');
    $('#authGate').classList.remove('hidden');
    setAuthMode('login');
    setAuthMessage('You have signed out.', true);
  }

  // Events
  $('#roadmapForm').addEventListener('submit', generateRoadmap);
  $('#syllabusText').addEventListener('input', updateRelevantSkillFields);
  
  $('#sampleButton').addEventListener('click', () => { useSampleSyllabus(); $('#syllabusText').focus({ preventScroll: true }); });
  $('#hoursPerWeek').addEventListener('input', event => { $('#hoursValue').textContent = event.target.value; });
  $('#uploadButton').addEventListener('click', () => $('#syllabusFile').click());
  $('#syllabusFile').addEventListener('change', event => uploadSyllabus(event.target.files?.[0]));
  $('#weeksContainer').addEventListener('click', event => {
    const startButton = event.target.closest('[data-open-lesson]');
    if (startButton) {
      openLesson(startButton.dataset.openLesson);
      return;
    }
    const button = event.target.closest('[data-detail-toggle]');
    if (!button) return;
    const detail = document.getElementById(button.dataset.detailToggle);
    const open = !detail.classList.contains('hidden');
    detail.classList.toggle('hidden', open);
    button.textContent = open ? 'Details' : 'Hide details';
    button.setAttribute('aria-expanded', String(!open));
  });
  $('#courseOutlineList').addEventListener('click', event => {
    const button = event.target.closest('[data-outline-task]');
    if (button) openLesson(button.dataset.outlineTask);
  });
  $('#backToCourseButton').addEventListener('click', () => {
    $('#learningPlayer').classList.add('hidden');
    $('#roadmapColumns')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    refreshSavedCourses(false);
  });
  $('#previousLessonButton').addEventListener('click', () => {
    const tasks = getAllTasks();
    const index = tasks.findIndex(task => task.task_id === activeTaskId);
    if (index > 0) openLesson(tasks[index - 1].task_id);
  });
  $('#lessonQuizForm').addEventListener('change', event => {
    if (activeTaskId && !completedTasks[activeTaskId]) {
      lessonAnswerCorrect = false;
      activeStudyState.completed.knowledgeCheck = false;
      persistStudyState();
      const card = event.target.closest('.lesson-check-question');
      if (card) {
        card.classList.remove('is-correct', 'is-incorrect');
        const feedback = $('.lesson-check-feedback', card);
        if (feedback) { feedback.classList.add('hidden'); feedback.classList.remove('is-correct', 'is-incorrect'); }
      }
      $('#lessonQuizFeedback').textContent = 'Your answers changed. Check all four questions to see your score and explanations.';
      $('#lessonQuizFeedback').className = '';
      updateCoursePlayerProgress();
    }
  });
  $('#lessonTimePlan').addEventListener('click', event => {
    const button = event.target.closest('[data-study-jump]');
    if (button) jumpToStudyActivity(button.dataset.studyJump);
  });
  $('#previewResponse').addEventListener('input', event => {
    if (!activeStudyState) return;
    activeStudyState.responses.preview = event.target.value;
    activeStudyState.completed.preview = false;
    persistStudyState(); refreshStudyActivityUI(); updateCoursePlayerProgress();
  });
  $('#completePreviewButton').addEventListener('click', completePreviewActivity);
  $('#coreIdeaSelect').addEventListener('change', event => {
    if (!activeStudyState) return;
    activeStudyState.coreConceptIndex = event.target.value;
    activeStudyState.completed.coreIdeas = false;
    $('#coreIdeaModel').classList.add('hidden');
    persistStudyState(); refreshStudyActivityUI(); updateCoursePlayerProgress();
  });
  $('#coreIdeaResponse').addEventListener('input', event => {
    if (!activeStudyState) return;
    activeStudyState.responses.coreIdea = event.target.value;
    activeStudyState.completed.coreIdeas = false;
    persistStudyState(); refreshStudyActivityUI(); updateCoursePlayerProgress();
  });
  $('#checkCoreIdeaButton').addEventListener('click', checkCoreIdeaActivity);
  $('#workedExamplePrediction').addEventListener('input', event => {
    if (!activeStudyState) return;
    const next = event.target.value;
    if (next !== activeStudyState.responses.workedPrediction) {
      activeStudyState.responses.workedPrediction = next;
      activeStudyState.workedPredictionSubmitted = false;
      activeStudyState.workedExampleStep = 0;
      activeStudyState.completed.workedExample = false;
      renderWorkedExampleWalkthrough();
      persistStudyState(); refreshStudyActivityUI(); updateCoursePlayerProgress();
    }
  });
  $('#checkWorkedExampleButton').addEventListener('click', checkWorkedExamplePrediction);
  $('#nextWorkedExampleStepButton').addEventListener('click', revealNextWorkedExampleStep);
  $('#lessonActivitySteps').addEventListener('input', event => {
    const field = event.target.closest('textarea[data-practice-index]');
    if (!field || !activeStudyState) return;
    const index = Number(field.dataset.practiceIndex);
    activeStudyState.responses.practice[index] = field.value;
    activeStudyState.completed.handsOn = false;
    persistStudyState(); refreshStudyActivityUI(); updateCoursePlayerProgress();
  });
  $('#submitHandsOnButton').addEventListener('click', submitHandsOnPractice);
  $('#toggleRecallNotesButton').addEventListener('click', toggleRecallNotes);
  $('#recallResponse').addEventListener('input', event => {
    if (!activeStudyState) return;
    activeStudyState.responses.recall = event.target.value;
    activeStudyState.completed.recall = false;
    $('#recallModel').classList.add('hidden');
    persistStudyState(); refreshStudyActivityUI(); updateCoursePlayerProgress();
  });
  $('#completeRecallButton').addEventListener('click', completeRecallActivity);
  $('#playAudioBtn').addEventListener('click', startLessonAudio);
  $('#pauseAudioBtn').addEventListener('click', pauseLessonAudio);
  $('#restartAudioBtn').addEventListener('click', restartLessonAudio);
  $('#voiceSelect').addEventListener('change', event => {
    try { localStorage.setItem('aheadpath-narrator-voice', event.target.value); } catch (_) { /* Voice selection remains usable without storage. */ }
    if (speechPlaybackState === 'playing' || speechPlaybackState === 'paused') {
      const status = $('#audioStatus');
      if (status) status.textContent = 'Narrator selection saved. Start over to hear the new voice in this lesson.';
    } else {
      const status = $('#audioStatus');
      if (status) status.textContent = 'Narrator selected. The choice will be used for the next playback.';
    }
  });
  $('#previousSlideButton').addEventListener('click', () => renderLectureSlide(activeSlideIndex - 1));
  $('#nextSlideButton').addEventListener('click', () => renderLectureSlide(activeSlideIndex + 1));
  $('#slideDots').addEventListener('click', event => {
    const button = event.target.closest('[data-slide-go]');
    if (button) renderLectureSlide(Number(button.dataset.slideGo));
  });
  $('#downloadSlidesButton').addEventListener('click', downloadLectureSlides);
  $('#saveLectureNotesButton').addEventListener('click', saveLectureNotes);
  document.addEventListener('keydown', event => {
    if (!activeTaskId || event.altKey || event.ctrlKey || event.metaKey) return;
    const target = event.target;
    if (target && /^(INPUT|TEXTAREA|SELECT|BUTTON)$/.test(target.tagName)) return;
    if (event.key === 'ArrowRight') renderLectureSlide(activeSlideIndex + 1);
    else if (event.key === 'ArrowLeft') renderLectureSlide(activeSlideIndex - 1);
  });
  $('#checkLessonAnswerButton').addEventListener('click', checkLessonAnswer);
  $('#nextLessonButton').addEventListener('click', continueCourse);
  $('#launchFinalAssessmentButton').addEventListener('click', openFinalAssessment);
  $('#submitFinalAssessmentButton').addEventListener('click', scoreFinalAssessment);
  $('#retakeFinalAssessmentButton').addEventListener('click', resetFinalAssessment);
  $('#resetProgressButton').addEventListener('click', () => {
    if (!currentRoadmap) return;
    if (!window.confirm('Reset all lesson progress and the final test result for this course?')) return;
    completedTasks = {};
    finalAssessmentResult = null;
    finalAssessmentScored = false;
    saveProgress();
    renderFinalAssessment();
    saveProgress();
    $('#finalAssessmentPanel').classList.add('hidden');
    $('#learningPlayer').classList.add('hidden');
    activeTaskId = null;
    updateProgressUI();
    showToast('Course progress reset.');
  });
  $('#downloadButton').addEventListener('click', downloadPlan);
  $('#editPlanButton').addEventListener('click', () => $('#builder').scrollIntoView({ behavior: 'smooth', block: 'start' }));
  $('#scoreDiagnosticButton').addEventListener('click', scoreDiagnostic);
  $('#applyDiagnosticButton').addEventListener('click', applyDiagnostic);

  $('#showLoginTab').addEventListener('click', () => setAuthMode('login'));
  $('#showRegisterTab').addEventListener('click', () => setAuthMode('register'));
  $('#loginForm').addEventListener('submit', event => { event.preventDefault(); submitAuth(event.currentTarget, '/api/auth/login'); });
  $('#registerForm').addEventListener('submit', event => { event.preventDefault(); submitAuth(event.currentTarget, '/api/auth/register'); });
  $('#logoutButton').addEventListener('click', logout);
  $('#savedCoursesGrid').addEventListener('click', event => {
    const loadButton = event.target.closest('[data-load-course]');
    if (loadButton) { openSavedCourse(loadButton.dataset.loadCourse); return; }
    const deleteButton = event.target.closest('[data-delete-course]');
    if (deleteButton) { deleteSavedCourse(deleteButton.dataset.deleteCourse); return; }
    if (event.target.closest('#emptyLibraryBuildButton')) $('#builder').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  $('#startNewCourseButton').addEventListener('click', () => $('#builder').scrollIntoView({ behavior: 'smooth', block: 'start' }));

  initializeSpeechVoicePicker();
  setDefaultDate();
  updateRelevantSkillFields();
  checkHealth();
  checkAuth();
})();
