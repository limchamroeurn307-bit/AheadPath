# AheadPath — Gemini API quick start (Windows)

You do **not** need Ollama or a local AI model download. AheadPath sends generation requests to Google's Gemini API.

## 1. Get your API key

1. Open https://aistudio.google.com/app/apikey
2. Sign in and create an API key.
3. Copy the key. Keep it private.

## 2. Install AheadPath's Python packages

1. Extract the AheadPath ZIP.
2. Open the `AheadPath` folder.
3. Click the folder address bar, type `powershell`, and press Enter.
4. Run these commands one at a time:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If PowerShell blocks activation, run this and activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

## 3. Add the key

Open the `.env` file using Notepad. Replace the blank value with your key:

```dotenv
AI_PROVIDER=gemini
GEMINI_API_KEY=PASTE_YOUR_KEY_HERE
GEMINI_MODEL=gemini-3.8-flash
HOST=0.0.0.0
PORT=5000
COOKIE_SECURE=false
```

Save the file. Do not share it or upload it to GitHub.

## 4. Run AheadPath

In the same PowerShell window, run:

```powershell
python app.py
```

Open http://127.0.0.1:5000 in your browser.

## Free-tier note

Google currently provides free input/output usage for eligible Gemini API models and projects, but there are request and token limits. Check https://ai.google.dev/gemini-api/docs/pricing and https://aistudio.google.com/ for current availability and usage. Free-tier content may be used by Google to improve its products. Avoid uploading confidential or restricted information.

The API key is only used by the AheadPath server. It is not sent to the browser. You do not need to install an AI model on other devices.
